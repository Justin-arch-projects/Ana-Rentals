// Sheets — bottom sheets for detail / add / edit flows
const { useState: useStateS, useEffect: useEffectS, useMemo: useMemoS } = React;

// ─────────────────────────────────────────────────────────────
// Property detail sheet
// ─────────────────────────────────────────────────────────────
function PropertyDetailSheet({ id, data, theme, openSheet, closeSheet }) {
  const p = data.properties.find(x => x.id === id);
  if (!p) return null;
  const propBookings = data.bookings.filter(b => b.property_id === id);
  const propExp = data.expenses.filter(e => e.property_id === id);
  const propTasks = data.tasks.filter(t => t.property_id === id && !t.done);
  const inc = Number(p.rev || 0);
  const exp = propExp.reduce((s, e) => s + Number(e.amount || 0), 0);
  const net = inc - exp;

  return (
    <div style={{ paddingBottom: 24 }}>
      {/* Hero */}
      <div style={{
        height: 140, background: heroGrad(p, data.properties.indexOf(p)),
        margin: '4px 16px 0', borderRadius: 14,
        display: 'flex', alignItems: 'flex-end', padding: 16,
      }}>
        <div style={{ fontSize: 56, lineHeight: 1, filter: 'drop-shadow(0 2px 12px rgba(0,0,0,0.25))' }}>{p.emoji || '🏡'}</div>
      </div>

      <div style={{ padding: '14px 20px 0' }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 22, fontWeight: 700, color: theme.t1, letterSpacing: -0.5 }}>{p.name}</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 4, color: theme.t2, fontSize: 14 }}>
              <Icon name="location" size={13} color={theme.t2} />
              {p.addr}
            </div>
          </div>
          <StatusPill status={p.status} theme={theme} />
        </div>
      </div>

      {/* Stats grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, padding: '16px 16px 0' }}>
        <BigStat label="Income" value={fmtMoney(inc, { compact: true })} color={theme.t1} theme={theme} />
        <BigStat label="Expenses" value={fmtMoney(exp, { compact: true })} color={theme.t1} theme={theme} />
        <BigStat label="Net" value={fmtMoney(net, { compact: true })} color={net >= 0 ? theme.green : theme.red} theme={theme} />
      </div>

      {/* Quick actions */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, padding: '12px 16px 0' }}>
        <Pressable onClick={() => openSheet({ kind: 'newBooking', propertyId: id })}>
          <div style={{
            background: theme.accent, color: 'white', padding: '12px 14px',
            borderRadius: 12, fontSize: 15, fontWeight: 600, textAlign: 'center',
            letterSpacing: -0.2,
          }}>+ Booking</div>
        </Pressable>
        <Pressable onClick={() => openSheet({ kind: 'newTask', propertyId: id })}>
          <div style={{
            background: theme.fillTertiary, color: theme.t1, padding: '12px 14px',
            borderRadius: 12, fontSize: 15, fontWeight: 600, textAlign: 'center',
            letterSpacing: -0.2,
          }}>+ Task</div>
        </Pressable>
      </div>

      {/* Bookings */}
      {propBookings.length > 0 && (
        <>
          <div style={{ padding: '20px 20px 8px', fontSize: 13, fontWeight: 500, color: theme.t2, textTransform: 'uppercase', letterSpacing: 0.4 }}>Bookings</div>
          <Card theme={theme}>
            {propBookings.map((b, i) => (
              <div key={b.id} style={{
                padding: '12px 16px',
                borderBottom: i < propBookings.length - 1 ? `0.5px solid ${theme.sep}` : 'none',
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: 15, fontWeight: 500, color: theme.t1 }}>{b.guest}</span>
                  <span style={{ fontSize: 14, fontWeight: 600, color: theme.green }}>
                    {fmtMoney((b.rate || 0) * nights(b.check_in, b.check_out))}
                  </span>
                </div>
                <div style={{ fontSize: 13, color: theme.t2, marginTop: 3 }}>
                  {fmtDate(b.check_in)} – {fmtDate(b.check_out)} · {nights(b.check_in, b.check_out)} nights
                </div>
                {b.notes && (
                  <div style={{ fontSize: 12, color: theme.t3, marginTop: 4, fontStyle: 'italic' }}>{b.notes}</div>
                )}
              </div>
            ))}
          </Card>
        </>
      )}

      {/* Open tasks */}
      {propTasks.length > 0 && (
        <>
          <div style={{ padding: '20px 20px 8px', fontSize: 13, fontWeight: 500, color: theme.t2, textTransform: 'uppercase', letterSpacing: 0.4 }}>Open Tasks</div>
          <Card theme={theme}>
            {propTasks.map((t, i) => {
              const lab = dueLabel(t.due, theme);
              return (
                <div key={t.id} style={{
                  padding: '12px 16px',
                  borderBottom: i < propTasks.length - 1 ? `0.5px solid ${theme.sep}` : 'none',
                  display: 'flex', alignItems: 'center', gap: 10,
                }}>
                  <div style={{ width: 6, height: 6, borderRadius: 3, background: theme[(PRIO_META[t.priority || 'med']).color] }} />
                  <span style={{ flex: 1, fontSize: 14, color: theme.t1 }}>{t.text}</span>
                  <span style={{ fontSize: 12, color: lab.color, fontWeight: 600 }}>{lab.text}</span>
                </div>
              );
            })}
          </Card>
        </>
      )}

      {/* Expenses preview */}
      {propExp.length > 0 && (
        <>
          <div style={{ padding: '20px 20px 8px', fontSize: 13, fontWeight: 500, color: theme.t2, textTransform: 'uppercase', letterSpacing: 0.4 }}>Recent Expenses</div>
          <Card theme={theme}>
            {propExp.slice(0, 4).map((e, i, arr) => (
              <div key={e.id} style={{
                padding: '12px 16px',
                borderBottom: i < arr.length - 1 ? `0.5px solid ${theme.sep}` : 'none',
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              }}>
                <div>
                  <div style={{ fontSize: 14, color: theme.t1 }}>{e.desc}</div>
                  <div style={{ fontSize: 12, color: theme.t2, marginTop: 2 }}>{(CAT_META[e.category] || CAT_META.other).l} · {fmtDate(e.date)}</div>
                </div>
                <span style={{ fontSize: 14, fontWeight: 600, color: theme.t1 }}>−{fmtMoney(e.amount)}</span>
              </div>
            ))}
          </Card>
        </>
      )}

      <div style={{ padding: '20px 16px 0' }}>
        <Pressable onClick={() => {}}>
          <div style={{
            background: theme.fillTertiary, color: theme.red, padding: '14px',
            borderRadius: 12, fontSize: 15, fontWeight: 500, textAlign: 'center',
          }}>Delete property</div>
        </Pressable>
      </div>
    </div>
  );
}

function heroGrad(p, idx) {
  const colors = [
    'linear-gradient(135deg, #5B8DEE 0%, #355FCC 100%)',
    'linear-gradient(135deg, #FFB05A 0%, #E8722C 100%)',
    'linear-gradient(135deg, #6EBE8C 0%, #2F8C5F 100%)',
    'linear-gradient(135deg, #B07CE8 0%, #7C4DCC 100%)',
    'linear-gradient(135deg, #F08CB0 0%, #D85686 100%)',
  ];
  return colors[idx % colors.length];
}

function BigStat({ label, value, color, theme }) {
  return (
    <div style={{
      background: theme.card, borderRadius: 12, padding: '12px 10px',
      textAlign: 'center', border: `0.5px solid ${theme.sepThin}`,
    }}>
      <div style={{ fontSize: 11, color: theme.t2, textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 4 }}>{label}</div>
      <div style={{ fontSize: 19, fontWeight: 700, color, letterSpacing: -0.4 }}>{value}</div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Form fields (iOS style)
// ─────────────────────────────────────────────────────────────
function Field({ label, children, theme, last }) {
  return (
    <div style={{
      padding: '11px 16px',
      borderBottom: last ? 'none' : `0.5px solid ${theme.sep}`,
      display: 'flex', alignItems: 'center', gap: 10,
    }}>
      <div style={{ fontSize: 15, color: theme.t1, minWidth: 100, fontWeight: 400 }}>{label}</div>
      <div style={{ flex: 1, textAlign: 'right' }}>{children}</div>
    </div>
  );
}

function TextInput({ value, onChange, placeholder, theme, type = 'text' }) {
  return (
    <input
      type={type}
      value={value || ''}
      onChange={e => onChange(e.target.value)}
      placeholder={placeholder}
      style={{
        background: 'transparent', border: 'none', outline: 'none',
        fontSize: 15, color: theme.t1, textAlign: 'right',
        width: '100%', fontFamily: 'inherit', letterSpacing: -0.2,
      }}
    />
  );
}

function Select({ value, onChange, options, theme }) {
  return (
    <select
      value={value || ''}
      onChange={e => onChange(e.target.value)}
      style={{
        background: 'transparent', border: 'none', outline: 'none',
        fontSize: 15, color: theme.t1, textAlign: 'right',
        fontFamily: 'inherit', appearance: 'none', WebkitAppearance: 'none',
        paddingRight: 14,
        backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='14' viewBox='0 0 10 14'><path d='M5 1l3 3M5 13l3-3' stroke='%23999' stroke-width='1.5' fill='none' stroke-linecap='round'/></svg>")`,
        backgroundRepeat: 'no-repeat', backgroundPosition: 'right center',
      }}
    >
      {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  );
}

// ─────────────────────────────────────────────────────────────
// Add/Edit Property sheet
// ─────────────────────────────────────────────────────────────
function NewPropertySheet({ data, theme, mutate, closeSheet }) {
  const [name, setName] = useStateS('');
  const [addr, setAddr] = useStateS('');
  const [emoji, setEmoji] = useStateS('🏡');
  const [rev, setRev] = useStateS('');
  const [status, setStatus] = useStateS('vacant');

  const emojis = ['🏡','🏠','🏖️','🏔️','🌴','🏙️','🏘️','⛰️','🛖','🌅','🚐','⛺'];

  const save = () => {
    if (!name) return;
    mutate.addProperty({ name, addr, emoji, rev: Number(rev) || 0, status });
    closeSheet();
  };

  return (
    <div style={{ padding: '8px 0 24px' }}>
      <Card theme={theme}>
        <Field label="Name" theme={theme}>
          <TextInput value={name} onChange={setName} placeholder="Lakeside Cabin" theme={theme} />
        </Field>
        <Field label="Address" theme={theme}>
          <TextInput value={addr} onChange={setAddr} placeholder="123 Main St" theme={theme} />
        </Field>
        <Field label="Status" theme={theme}>
          <Select value={status} onChange={setStatus} theme={theme} options={[
            { value: 'vacant', label: 'Available' },
            { value: 'booked', label: 'Booked' },
            { value: 'maint', label: 'Maintenance' },
            { value: 'prep', label: 'Preparing' },
          ]} />
        </Field>
        <Field label="Income / mo" theme={theme} last>
          <TextInput value={rev} onChange={setRev} placeholder="2000" type="number" theme={theme} />
        </Field>
      </Card>

      <div style={{ padding: '20px 20px 8px', fontSize: 13, fontWeight: 500, color: theme.t2, textTransform: 'uppercase', letterSpacing: 0.4 }}>Icon</div>
      <Card theme={theme}>
        <div style={{ padding: 14, display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 8 }}>
          {emojis.map(e => (
            <Pressable key={e} onClick={() => setEmoji(e)} scale={0.85}>
              <div style={{
                fontSize: 24, padding: 6, borderRadius: 10, textAlign: 'center',
                background: emoji === e ? theme.accentSoft : 'transparent',
                border: emoji === e ? `1.5px solid ${theme.accent}` : '1.5px solid transparent',
              }}>{e}</div>
            </Pressable>
          ))}
        </div>
      </Card>

      <div style={{ padding: '20px 16px 0' }}>
        <Pressable onClick={save}>
          <div style={{
            background: theme.accent, color: 'white', padding: '14px',
            borderRadius: 14, fontSize: 16, fontWeight: 600, textAlign: 'center',
            letterSpacing: -0.2,
          }}>Save Property</div>
        </Pressable>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// New booking sheet
// ─────────────────────────────────────────────────────────────
function NewBookingSheet({ propertyId, data, theme, mutate, closeSheet }) {
  const [pid, setPid] = useStateS(propertyId || (data.properties[0] && data.properties[0].id));
  const [guest, setGuest] = useStateS('');
  const [ci, setCi] = useStateS('');
  const [co, setCo] = useStateS('');
  const [rate, setRate] = useStateS('');
  const [notes, setNotes] = useStateS('');

  const save = () => {
    if (!guest || !ci || !co) return;
    mutate.addBooking({ property_id: pid, guest, check_in: ci, check_out: co, rate: Number(rate) || 0, notes });
    closeSheet();
  };

  const total = ci && co && rate ? nights(ci, co) * Number(rate) : 0;

  return (
    <div style={{ padding: '8px 0 24px' }}>
      <Card theme={theme}>
        <Field label="Property" theme={theme}>
          <Select value={pid} onChange={setPid} theme={theme}
            options={data.properties.map(p => ({ value: p.id, label: p.name }))} />
        </Field>
        <Field label="Guest" theme={theme}>
          <TextInput value={guest} onChange={setGuest} placeholder="Smith Family" theme={theme} />
        </Field>
        <Field label="Check-in" theme={theme}>
          <TextInput value={ci} onChange={setCi} placeholder="2026-05-10" type="date" theme={theme} />
        </Field>
        <Field label="Check-out" theme={theme}>
          <TextInput value={co} onChange={setCo} placeholder="2026-05-15" type="date" theme={theme} />
        </Field>
        <Field label="Rate / night" theme={theme}>
          <TextInput value={rate} onChange={setRate} placeholder="250" type="number" theme={theme} />
        </Field>
        <Field label="Notes" theme={theme} last>
          <TextInput value={notes} onChange={setNotes} placeholder="Optional" theme={theme} />
        </Field>
      </Card>

      {total > 0 && (
        <div style={{ padding: '14px 20px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ fontSize: 14, color: theme.t2 }}>{nights(ci, co)} nights total</span>
          <span style={{ fontSize: 22, fontWeight: 700, color: theme.green, letterSpacing: -0.4 }}>{fmtMoney(total)}</span>
        </div>
      )}

      <div style={{ padding: '20px 16px 0' }}>
        <Pressable onClick={save}>
          <div style={{
            background: theme.accent, color: 'white', padding: '14px',
            borderRadius: 14, fontSize: 16, fontWeight: 600, textAlign: 'center',
          }}>Confirm Booking</div>
        </Pressable>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// New task sheet
// ─────────────────────────────────────────────────────────────
function NewTaskSheet({ propertyId, data, theme, mutate, closeSheet }) {
  const [text, setText] = useStateS('');
  const [pid, setPid] = useStateS(propertyId || (data.properties[0] && data.properties[0].id));
  const [priority, setPriority] = useStateS('med');
  const [due, setDue] = useStateS('today');
  const [assignees, setAssignees] = useStateS([]);

  const allAssignees = useMemoS(() => {
    const s = new Set(['Justin', 'Jay', 'Plumber', 'Cleaner', 'Electrician', 'Landscaper']);
    data.tasks.forEach(t => (t.assignees || []).forEach(a => s.add(a)));
    return Array.from(s);
  }, [data.tasks]);

  const save = () => {
    if (!text) return;
    mutate.addTask({ text, property_id: pid, priority, due, assignees, done: false });
    closeSheet();
  };

  return (
    <div style={{ padding: '8px 0 24px' }}>
      <Card theme={theme}>
        <div style={{ padding: '14px 16px' }}>
          <textarea
            value={text}
            onChange={e => setText(e.target.value)}
            placeholder="What needs to be done?"
            style={{
              width: '100%', minHeight: 60, background: 'transparent',
              border: 'none', outline: 'none', resize: 'none',
              fontSize: 17, color: theme.t1, fontFamily: 'inherit',
              letterSpacing: -0.3, lineHeight: 1.4,
            }}
          />
        </div>
      </Card>

      <div style={{ marginTop: 16 }}>
        <Card theme={theme}>
          <Field label="Property" theme={theme}>
            <Select value={pid} onChange={setPid} theme={theme}
              options={data.properties.map(p => ({ value: p.id, label: p.name }))} />
          </Field>
          <Field label="Priority" theme={theme}>
            <Select value={priority} onChange={setPriority} theme={theme}
              options={Object.entries(PRIO_META).map(([k, v]) => ({ value: k, label: v.label }))} />
          </Field>
          <Field label="Due" theme={theme} last>
            <TextInput value={due} onChange={setDue} placeholder="today, May 10..." theme={theme} />
          </Field>
        </Card>
      </div>

      <div style={{ padding: '20px 20px 8px', fontSize: 13, fontWeight: 500, color: theme.t2, textTransform: 'uppercase', letterSpacing: 0.4 }}>Assign To</div>
      <Card theme={theme}>
        <div style={{ padding: 12, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {allAssignees.map(a => {
            const on = assignees.includes(a);
            return (
              <Pressable key={a} scale={0.92} onClick={() => {
                setAssignees(on ? assignees.filter(x => x !== a) : [...assignees, a]);
              }}>
                <div style={{
                  padding: '6px 12px', borderRadius: 20, fontSize: 13, fontWeight: 500,
                  background: on ? theme.accent : theme.fillTertiary,
                  color: on ? 'white' : theme.t1,
                }}>{a}</div>
              </Pressable>
            );
          })}
        </div>
      </Card>

      <div style={{ padding: '20px 16px 0' }}>
        <Pressable onClick={save}>
          <div style={{
            background: theme.accent, color: 'white', padding: '14px',
            borderRadius: 14, fontSize: 16, fontWeight: 600, textAlign: 'center',
          }}>Add Task</div>
        </Pressable>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Task detail sheet
// ─────────────────────────────────────────────────────────────
function TaskDetailSheet({ id, data, theme, mutate, closeSheet }) {
  const t = data.tasks.find(x => x.id === id);
  if (!t) return null;
  const p = data.properties.find(x => x.id === t.property_id);
  const lab = dueLabel(t.due, theme);

  return (
    <div style={{ padding: '8px 0 24px' }}>
      <div style={{ padding: '12px 20px 18px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
          <PriorityDot priority={t.priority} theme={theme} />
          {!t.done && (
            <span style={{ fontSize: 12, fontWeight: 600, color: lab.color, padding: '2px 8px', borderRadius: 12, background: lab.bg }}>{lab.text}</span>
          )}
        </div>
        <div style={{ fontSize: 22, fontWeight: 600, color: theme.t1, lineHeight: 1.25, letterSpacing: -0.4 }}>{t.text}</div>
        {p && <div style={{ fontSize: 14, color: theme.t2, marginTop: 6 }}>{p.emoji} {p.name}</div>}
      </div>

      <Card theme={theme}>
        <Pressable onClick={() => mutate.toggleTask(id)}>
          <div style={{
            display: 'flex', alignItems: 'center', gap: 12, padding: '14px 16px',
            borderBottom: `0.5px solid ${theme.sep}`,
          }}>
            <div style={{
              width: 26, height: 26, borderRadius: 13,
              border: `1.5px solid ${t.done ? theme.green : theme.t3}`,
              background: t.done ? theme.green : 'transparent',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              {t.done && <Icon name="check" size={14} color="white" />}
            </div>
            <span style={{ fontSize: 16, color: theme.t1 }}>Mark as {t.done ? 'incomplete' : 'complete'}</span>
          </div>
        </Pressable>
        {t.assignees && t.assignees.length > 0 && (
          <div style={{ padding: '12px 16px', borderBottom: `0.5px solid ${theme.sep}` }}>
            <div style={{ fontSize: 12, color: theme.t2, marginBottom: 6 }}>Assigned to</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
              {t.assignees.map(a => (
                <div key={a} style={{
                  display: 'flex', alignItems: 'center', gap: 6,
                  padding: '4px 10px', borderRadius: 16,
                  background: theme.fillTertiary, fontSize: 13, color: theme.t1,
                }}>
                  <div style={{
                    width: 18, height: 18, borderRadius: 9, background: avatarColor(a),
                    color: 'white', fontSize: 10, fontWeight: 700,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>{initials(a)}</div>
                  {a}
                </div>
              ))}
            </div>
          </div>
        )}
        {t.notes && (
          <div style={{ padding: '12px 16px' }}>
            <div style={{ fontSize: 12, color: theme.t2, marginBottom: 4 }}>Notes</div>
            <div style={{ fontSize: 14, color: theme.t1, lineHeight: 1.45 }}>{t.notes}</div>
          </div>
        )}
      </Card>

      <div style={{ padding: '20px 16px 0' }}>
        <Pressable onClick={() => { mutate.deleteTask(id); closeSheet(); }}>
          <div style={{
            background: theme.fillTertiary, color: theme.red, padding: '14px',
            borderRadius: 14, fontSize: 15, fontWeight: 500, textAlign: 'center',
          }}>Delete Task</div>
        </Pressable>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Guest detail sheet
// ─────────────────────────────────────────────────────────────
function GuestDetailSheet({ name, data, theme }) {
  const bks = data.bookings.filter(b => b.guest === name);
  const sts = (data.stays || []).filter(s => s.guest_name === name);
  const total = bks.reduce((s, b) => s + (b.rate || 0) * nights(b.check_in, b.check_out), 0)
              + sts.reduce((s, st) => s + Number(st.amount || 0), 0);
  const visits = bks.length + sts.length;

  return (
    <div style={{ padding: '0 0 24px' }}>
      <div style={{ padding: '8px 20px 20px', textAlign: 'center' }}>
        <div style={{
          width: 88, height: 88, borderRadius: 44, background: avatarColor(name),
          color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 32, fontWeight: 600, margin: '0 auto 12px',
        }}>{initials(name)}</div>
        <div style={{ fontSize: 24, fontWeight: 700, color: theme.t1, letterSpacing: -0.5 }}>{name}</div>
        <div style={{ fontSize: 14, color: theme.t2, marginTop: 4 }}>
          {visits} visit{visits !== 1 ? 's' : ''} · {fmtMoney(total)} lifetime
        </div>
      </div>

      {bks.length > 0 && (
        <>
          <div style={{ padding: '4px 20px 8px', fontSize: 13, fontWeight: 500, color: theme.t2, textTransform: 'uppercase', letterSpacing: 0.4 }}>Upcoming & Active</div>
          <Card theme={theme}>
            {bks.map((b, i) => {
              const p = data.properties.find(x => x.id === b.property_id);
              return (
                <div key={b.id} style={{
                  padding: '12px 16px',
                  borderBottom: i < bks.length - 1 ? `0.5px solid ${theme.sep}` : 'none',
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ fontSize: 15, color: theme.t1, fontWeight: 500 }}>{p?.name}</span>
                    <span style={{ fontSize: 14, color: theme.green, fontWeight: 600 }}>
                      {fmtMoney((b.rate || 0) * nights(b.check_in, b.check_out))}
                    </span>
                  </div>
                  <div style={{ fontSize: 13, color: theme.t2, marginTop: 3 }}>
                    {fmtDate(b.check_in)} – {fmtDate(b.check_out)} · {nights(b.check_in, b.check_out)} nights
                  </div>
                </div>
              );
            })}
          </Card>
        </>
      )}

      {sts.length > 0 && (
        <>
          <div style={{ padding: '20px 20px 8px', fontSize: 13, fontWeight: 500, color: theme.t2, textTransform: 'uppercase', letterSpacing: 0.4 }}>Past Stays</div>
          <Card theme={theme}>
            {sts.map((s, i) => {
              const p = data.properties.find(x => x.id === s.property_id);
              return (
                <div key={s.id} style={{
                  padding: '12px 16px',
                  borderBottom: i < sts.length - 1 ? `0.5px solid ${theme.sep}` : 'none',
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ fontSize: 15, color: theme.t1, fontWeight: 500 }}>{p?.name || 'Unknown property'}</span>
                    <span style={{ fontSize: 14, color: theme.t1, fontWeight: 600 }}>{fmtMoney(s.amount)}</span>
                  </div>
                  <div style={{ fontSize: 13, color: theme.t2, marginTop: 3 }}>
                    {fmtDate(s.check_in)} – {fmtDate(s.check_out)}
                  </div>
                  {s.note && <div style={{ fontSize: 12, color: theme.t3, marginTop: 4, fontStyle: 'italic' }}>{s.note}</div>}
                </div>
              );
            })}
          </Card>
        </>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// New expense sheet
// ─────────────────────────────────────────────────────────────
function NewExpenseSheet({ data, theme, mutate, closeSheet }) {
  const [pid, setPid] = useStateS(data.properties[0] && data.properties[0].id);
  const [cat, setCat] = useStateS('cleaning');
  const [desc, setDesc] = useStateS('');
  const [amt, setAmt] = useStateS('');
  const [date, setDate] = useStateS('2026-05-07');

  const save = () => {
    if (!desc || !amt) return;
    mutate.addExpense({ property_id: pid, category: cat, desc, amount: Number(amt), date });
    closeSheet();
  };

  return (
    <div style={{ padding: '8px 0 24px' }}>
      <Card theme={theme}>
        <Field label="Property" theme={theme}>
          <Select value={pid} onChange={setPid} theme={theme}
            options={data.properties.map(p => ({ value: p.id, label: p.name }))} />
        </Field>
        <Field label="Category" theme={theme}>
          <Select value={cat} onChange={setCat} theme={theme}
            options={Object.entries(CAT_META).map(([k, v]) => ({ value: k, label: v.l }))} />
        </Field>
        <Field label="Description" theme={theme}>
          <TextInput value={desc} onChange={setDesc} placeholder="What was it for?" theme={theme} />
        </Field>
        <Field label="Amount" theme={theme}>
          <TextInput value={amt} onChange={setAmt} placeholder="0" type="number" theme={theme} />
        </Field>
        <Field label="Date" theme={theme} last>
          <TextInput value={date} onChange={setDate} type="date" theme={theme} />
        </Field>
      </Card>

      <div style={{ padding: '20px 16px 0' }}>
        <Pressable onClick={save}>
          <div style={{
            background: theme.accent, color: 'white', padding: '14px',
            borderRadius: 14, fontSize: 16, fontWeight: 600, textAlign: 'center',
          }}>Save Expense</div>
        </Pressable>
      </div>
    </div>
  );
}

Object.assign(window, {
  PropertyDetailSheet, NewPropertySheet, NewBookingSheet,
  NewTaskSheet, TaskDetailSheet, GuestDetailSheet, NewExpenseSheet,
  Field, TextInput, Select, BigStat, heroGrad,
});
