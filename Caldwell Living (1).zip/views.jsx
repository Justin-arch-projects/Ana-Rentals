// Views — Caldwell Living
// Each view is a self-contained component. Mounted by App.

const { useState: useStateV, useEffect: useEffectV, useMemo: useMemoV, useRef: useRefV } = React;

// ─────────────────────────────────────────────────────────────
// Greeting (top of every view)
// ─────────────────────────────────────────────────────────────
function HeaderTitle({ title, subtitle, theme }) {
  return (
    <div style={{ padding: '6px 20px 18px' }}>
      <div style={{
        fontSize: 34, fontWeight: 700, letterSpacing: -0.8,
        color: theme.t1, lineHeight: 1.1,
      }}>{title}</div>
      {subtitle && (
        <div style={{ fontSize: 15, color: theme.t2, marginTop: 4, letterSpacing: -0.2 }}>{subtitle}</div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Section header
// ─────────────────────────────────────────────────────────────
function SectionHeader({ title, action, theme }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between',
      padding: '20px 20px 10px',
    }}>
      <div style={{ fontSize: 22, fontWeight: 700, color: theme.t1, letterSpacing: -0.5 }}>{title}</div>
      {action && (
        <Pressable onClick={action.onClick}>
          <span style={{ fontSize: 15, color: theme.accent, fontWeight: 400 }}>{action.label}</span>
        </Pressable>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Card (insetGrouped style)
// ─────────────────────────────────────────────────────────────
function Card({ children, theme, style, padding = 0 }) {
  return (
    <div style={{
      background: theme.card, borderRadius: 14, overflow: 'hidden',
      margin: '0 16px', padding,
      ...style,
    }}>{children}</div>
  );
}

// Status pill
function StatusPill({ status, theme }) {
  const m = STATUS_META[status] || STATUS_META.vacant;
  const c = theme[m.color];
  return (
    <span style={{
      fontSize: 12, fontWeight: 600, letterSpacing: -0.1,
      padding: '3px 10px', borderRadius: 20,
      background: c + '22', color: c,
    }}>{m.label}</span>
  );
}

// ─────────────────────────────────────────────────────────────
// PROPERTIES VIEW
// ─────────────────────────────────────────────────────────────
function PropertiesView({ data, setData, theme, openSheet, mutate }) {
  const { properties, bookings, tasks: alltasks, expenses } = data;

  const todayActive = useMemoV(() => {
    return properties.map(p => {
      const cur = bookings.find(b => b.property_id === p.id && b.check_in <= '2026-05-07' && b.check_out >= '2026-05-07');
      return { p, cur };
    });
  }, [properties, bookings]);

  const totalNet = useMemoV(() => {
    return properties.reduce((s, p) => {
      const inc = Number(p.rev || 0);
      const exp = expenses.filter(e => e.property_id === p.id).reduce((a, e) => a + Number(e.amount || 0), 0);
      return s + (inc - exp);
    }, 0);
  }, [properties, expenses]);

  const dueToday = alltasks.filter(t => !t.done && parseDue(t.due) && parseDue(t.due).getTime() === TODAY.getTime()).length;
  const upcomingThisWeek = bookings.filter(b => {
    const d = new Date(b.check_in + 'T00:00:00');
    const diff = (d - TODAY) / 86400000;
    return diff >= 0 && diff <= 7;
  }).length;

  return (
    <>
      <HeaderTitle title="Properties" subtitle={`${properties.length} units · May 7, 2026`} theme={theme} />

      {/* Summary chips */}
      <div style={{ padding: '0 16px 6px', display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
        <SummaryChip label="Net income" value={fmtMoney(totalNet, { compact: true })} icon="arrowUp" color={theme.green} theme={theme} />
        <SummaryChip label="Due today" value={dueToday} icon="check" color={dueToday > 0 ? theme.red : theme.t2} theme={theme} />
        <SummaryChip label="Arrivals" value={upcomingThisWeek} icon="bed" color={theme.blue} theme={theme} />
      </div>

      <div style={{ height: 8 }} />

      {properties.map((p, i) => {
        const propBookings = bookings.filter(b => b.property_id === p.id);
        const cur = propBookings.find(b => b.check_in <= '2026-05-07' && b.check_out >= '2026-05-07');
        const next = propBookings.filter(b => b.check_in > '2026-05-07').sort((a, b) => a.check_in.localeCompare(b.check_in))[0];
        const exp = expenses.filter(e => e.property_id === p.id).reduce((s, e) => s + Number(e.amount || 0), 0);
        const inc = Number(p.rev || 0);
        const net = inc - exp;
        const propTasks = alltasks.filter(t => t.property_id === p.id && !t.done).length;

        return (
          <div key={p.id} style={{ margin: '8px 16px 0' }}>
            <Pressable
              onClick={() => openSheet({ kind: 'propertyDetail', id: p.id })}
              scale={0.98}
            >
              <div style={{
                background: theme.card, borderRadius: 18, overflow: 'hidden',
                border: `0.5px solid ${theme.sepThin}`,
              }}>
                {/* Hero strip */}
                <div style={{
                  height: 88, position: 'relative',
                  background: heroGradient(p, theme, i),
                  display: 'flex', alignItems: 'flex-end', padding: 12,
                }}>
                  <div style={{ position: 'absolute', top: 12, right: 12 }}>
                    <StatusPill status={p.status} theme={theme} />
                  </div>
                  <div style={{ fontSize: 40, lineHeight: 1, filter: 'drop-shadow(0 2px 8px rgba(0,0,0,0.2))' }}>
                    {p.emoji || '🏡'}
                  </div>
                </div>

                {/* Body */}
                <div style={{ padding: 14 }}>
                  <div style={{ fontSize: 17, fontWeight: 600, color: theme.t1, letterSpacing: -0.3 }}>{p.name}</div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 3, color: theme.t2, fontSize: 13 }}>
                    <Icon name="location" size={12} color={theme.t2} />
                    <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.addr}</span>
                  </div>

                  {/* Booking ticker */}
                  {(cur || next) && (
                    <div style={{
                      marginTop: 12, padding: '10px 12px',
                      background: theme.fillTertiary, borderRadius: 10,
                      display: 'flex', alignItems: 'center', gap: 10,
                    }}>
                      <div style={{
                        width: 6, height: 6, borderRadius: 3,
                        background: cur ? theme.green : theme.orange,
                      }} />
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontSize: 13, fontWeight: 500, color: theme.t1 }}>
                          {cur ? `${cur.guest} · staying now` : `${next.guest} arrives ${fmtDate(next.check_in)}`}
                        </div>
                        <div style={{ fontSize: 11, color: theme.t2, marginTop: 1 }}>
                          {cur
                            ? `Through ${fmtDate(cur.check_out)} · ${nights(cur.check_in, cur.check_out)} nights · ${fmtMoney(cur.rate)}/night`
                            : `Through ${fmtDate(next.check_out)} · ${nights(next.check_in, next.check_out)} nights`}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Stats row */}
                  <div style={{
                    display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr',
                    marginTop: 12, paddingTop: 12, borderTop: `0.5px solid ${theme.sepThin}`,
                    gap: 4,
                  }}>
                    <Stat label="Income" value={fmtMoney(inc, { compact: true })} color={theme.t1} theme={theme} />
                    <Stat label="Expenses" value={fmtMoney(exp, { compact: true })} color={theme.t1} theme={theme} />
                    <Stat label="Net" value={fmtMoney(net, { compact: true })} color={net >= 0 ? theme.green : theme.red} theme={theme} bold />
                    <Stat label="Tasks" value={propTasks} color={propTasks > 0 ? theme.orange : theme.t1} theme={theme} />
                  </div>
                </div>
              </div>
            </Pressable>
          </div>
        );
      })}

      {/* Add property */}
      <div style={{ margin: '14px 16px 0' }}>
        <Pressable onClick={() => openSheet({ kind: 'newProperty' })}>
          <div style={{
            background: 'transparent', border: `1.5px dashed ${theme.sep}`,
            borderRadius: 14, padding: 18, textAlign: 'center',
            color: theme.accent, fontSize: 15, fontWeight: 500,
          }}>+ Add property</div>
        </Pressable>
      </div>

      <div style={{ height: 110 }} />
    </>
  );
}

function heroGradient(p, theme, i) {
  const colors = [
    'linear-gradient(135deg, #5B8DEE 0%, #355FCC 100%)',
    'linear-gradient(135deg, #FFB05A 0%, #E8722C 100%)',
    'linear-gradient(135deg, #6EBE8C 0%, #2F8C5F 100%)',
    'linear-gradient(135deg, #B07CE8 0%, #7C4DCC 100%)',
    'linear-gradient(135deg, #F08CB0 0%, #D85686 100%)',
  ];
  return colors[i % colors.length];
}

function SummaryChip({ label, value, icon, color, theme }) {
  return (
    <div style={{
      background: theme.card, borderRadius: 14, padding: '10px 12px',
      border: `0.5px solid ${theme.sepThin}`,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginBottom: 4 }}>
        <Icon name={icon} size={12} color={color} />
        <span style={{ fontSize: 11, color: theme.t2, fontWeight: 500, letterSpacing: -0.1 }}>{label}</span>
      </div>
      <div style={{ fontSize: 19, fontWeight: 700, color, letterSpacing: -0.4 }}>{value}</div>
    </div>
  );
}

function Stat({ label, value, color, theme, bold }) {
  return (
    <div style={{ textAlign: 'center' }}>
      <div style={{ fontSize: 14, fontWeight: bold ? 700 : 600, color, letterSpacing: -0.3 }}>{value}</div>
      <div style={{ fontSize: 10, color: theme.t2, textTransform: 'uppercase', letterSpacing: 0.4, marginTop: 2 }}>{label}</div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// TASKS VIEW
// ─────────────────────────────────────────────────────────────
function TasksView({ data, setData, theme, openSheet, mutate }) {
  const [filter, setFilter] = useStateV('all');
  const { tasks, properties } = data;

  const filtered = useMemoV(() => {
    let list = tasks.slice();
    if (filter === 'today') list = list.filter(t => !t.done && parseDue(t.due) && parseDue(t.due).getTime() === TODAY.getTime());
    else if (filter === 'upcoming') list = list.filter(t => !t.done);
    else if (filter === 'done') list = list.filter(t => t.done);
    else list = list.filter(t => !t.done);
    // sort: urgent first, then by due
    list.sort((a, b) => {
      const order = ['urgent', 'high', 'med', 'low'];
      const da = order.indexOf(a.priority || 'med');
      const db = order.indexOf(b.priority || 'med');
      if (da !== db) return da - db;
      const pa = parseDue(a.due), pb = parseDue(b.due);
      if (pa && pb) return pa - pb;
      if (pa) return -1; if (pb) return 1;
      return 0;
    });
    return list;
  }, [tasks, filter]);

  const groupedByProp = useMemoV(() => {
    const g = {};
    filtered.forEach(t => {
      const p = properties.find(x => x.id === t.property_id);
      const k = p ? p.name : 'Unassigned';
      if (!g[k]) g[k] = [];
      g[k].push({ task: t, prop: p });
    });
    return g;
  }, [filtered, properties]);

  const dueTodayCount = tasks.filter(t => !t.done && parseDue(t.due) && parseDue(t.due).getTime() === TODAY.getTime()).length;

  return (
    <>
      <HeaderTitle title="Tasks" subtitle={`${dueTodayCount} due today · ${tasks.filter(t => !t.done).length} open`} theme={theme} />

      {/* Segmented control */}
      <div style={{ padding: '0 16px 16px' }}>
        <Segmented
          options={[
            { value: 'all', label: 'Open' },
            { value: 'today', label: 'Today' },
            { value: 'upcoming', label: 'Upcoming' },
            { value: 'done', label: 'Done' },
          ]}
          value={filter}
          onChange={setFilter}
          theme={theme}
        />
      </div>

      {Object.keys(groupedByProp).length === 0 && (
        <EmptyState icon="check" title={filter === 'done' ? 'Nothing completed yet' : 'All caught up'} subtitle="Tap + to add a task" theme={theme} />
      )}

      {Object.entries(groupedByProp).map(([propName, items]) => (
        <div key={propName} style={{ marginBottom: 18 }}>
          <div style={{
            padding: '0 20px 6px', fontSize: 13, fontWeight: 500,
            color: theme.t2, textTransform: 'uppercase', letterSpacing: 0.4,
          }}>{propName}</div>
          <Card theme={theme}>
            {items.map(({ task, prop }, i) => (
              <SwipeRow
                key={task.id}
                theme={theme}
                onClick={() => openSheet({ kind: 'taskDetail', id: task.id })}
                actions={[
                  { icon: 'trash', label: 'Delete', color: 'red',
                    onClick: () => mutate.deleteTask(task.id) },
                ]}
              >
                <div style={{
                  display: 'flex', alignItems: 'flex-start', gap: 12,
                  padding: '12px 16px',
                  borderBottom: i < items.length - 1 ? `0.5px solid ${theme.sep}` : 'none',
                }}>
                  <Pressable onClick={(e) => { e.stopPropagation(); mutate.toggleTask(task.id); }} scale={0.85}>
                    <div style={{
                      width: 24, height: 24, borderRadius: 12,
                      border: `1.5px solid ${task.done ? theme.green : theme.t3}`,
                      background: task.done ? theme.green : 'transparent',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      flexShrink: 0, marginTop: 2,
                    }}>
                      {task.done && <Icon name="check" size={14} color="white" />}
                    </div>
                  </Pressable>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{
                      fontSize: 15, color: task.done ? theme.t2 : theme.t1,
                      textDecoration: task.done ? 'line-through' : 'none',
                      letterSpacing: -0.2, lineHeight: 1.3,
                    }}>{task.text}</div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 5, flexWrap: 'wrap' }}>
                      <PriorityDot priority={task.priority} theme={theme} />
                      {task.assignees && task.assignees.length > 0 && (
                        <span style={{ fontSize: 12, color: theme.t2 }}>· {task.assignees.join(', ')}</span>
                      )}
                    </div>
                  </div>
                  {!task.done && (() => {
                    const lab = dueLabel(task.due, theme);
                    return (
                      <span style={{
                        fontSize: 12, fontWeight: 600,
                        color: lab.color, padding: '3px 8px',
                        borderRadius: 20, background: lab.bg, flexShrink: 0,
                      }}>{lab.text}</span>
                    );
                  })()}
                </div>
              </SwipeRow>
            ))}
          </Card>
        </div>
      ))}

      <div style={{ height: 110 }} />
    </>
  );
}

function PriorityDot({ priority, theme }) {
  const m = PRIO_META[priority || 'med'];
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
      <span style={{ width: 6, height: 6, borderRadius: 3, background: theme[m.color] }} />
      <span style={{ fontSize: 11, color: theme.t2, fontWeight: 500 }}>{m.label}</span>
    </span>
  );
}

function Segmented({ options, value, onChange, theme }) {
  const idx = options.findIndex(o => o.value === value);
  return (
    <div style={{
      position: 'relative', display: 'flex',
      background: theme.fillTertiary, borderRadius: 9,
      padding: 2, gap: 0,
    }}>
      <div style={{
        position: 'absolute', top: 2, bottom: 2,
        width: `calc(${100 / options.length}% - 2px)`,
        left: `calc(${(100 / options.length) * idx}% + 1px)`,
        background: theme.bg2, borderRadius: 7,
        boxShadow: '0 3px 8px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.04)',
        transition: 'left 280ms cubic-bezier(0.32, 0.72, 0, 1)',
      }} />
      {options.map(o => (
        <Pressable
          key={o.value}
          onClick={() => onChange(o.value)}
          scale={0.94}
          style={{ flex: 1, position: 'relative', zIndex: 1 }}
        >
          <div style={{
            padding: '6px 0', textAlign: 'center', fontSize: 13,
            fontWeight: o.value === value ? 600 : 500,
            color: o.value === value ? theme.t1 : theme.t2,
            letterSpacing: -0.1,
          }}>{o.label}</div>
        </Pressable>
      ))}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// CALENDAR VIEW
// ─────────────────────────────────────────────────────────────
function CalendarView({ data, theme, openSheet }) {
  const [month, setMonth] = useStateV(TM);
  const [year, setYear] = useStateV(TY);
  const [propFilter, setPropFilter] = useStateV(null);
  const { properties, bookings } = data;

  const monthBookings = useMemoV(() => {
    return bookings.filter(b => {
      if (propFilter && b.property_id !== propFilter) return false;
      const ci = new Date(b.check_in + 'T00:00:00');
      const co = new Date(b.check_out + 'T00:00:00');
      const start = new Date(year, month, 1);
      const end = new Date(year, month + 1, 0);
      return co >= start && ci <= end;
    });
  }, [bookings, month, year, propFilter]);

  const firstDow = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const prevMonthDays = new Date(year, month, 0).getDate();

  const cells = [];
  for (let i = 0; i < firstDow; i++) {
    cells.push({ day: prevMonthDays - firstDow + i + 1, other: true });
  }
  for (let d = 1; d <= daysInMonth; d++) cells.push({ day: d });
  while (cells.length < 42) cells.push({ day: cells.length - daysInMonth - firstDow + 1, other: true });

  const evtFor = (day) => {
    if (!day) return [];
    const ds = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    const evs = [];
    monthBookings.forEach(b => {
      const propIdx = properties.findIndex(p => p.id === b.property_id);
      const c = ['#34C759', '#FF9500', '#5856D6', '#FF2D55', '#30B0C7', '#AF52DE'][propIdx % 6];
      if (b.check_in === ds) evs.push({ kind: 'in', label: b.guest, color: c, b });
      else if (b.check_out === ds) evs.push({ kind: 'out', label: b.guest, color: c, b });
      else if (b.check_in < ds && b.check_out > ds) evs.push({ kind: 'stay', label: b.guest, color: c, b });
    });
    return evs;
  };

  const upcoming = useMemoV(() => {
    return bookings
      .filter(b => b.check_in >= '2026-05-07')
      .sort((a, b) => a.check_in.localeCompare(b.check_in))
      .slice(0, 6);
  }, [bookings]);

  return (
    <>
      <HeaderTitle title="Calendar" subtitle="Bookings across all properties" theme={theme} />

      {/* Property filter */}
      <div style={{ padding: '0 16px 14px', display: 'flex', gap: 6, overflowX: 'auto' }}>
        <Pressable onClick={() => setPropFilter(null)} scale={0.94}>
          <div style={{
            padding: '6px 14px', borderRadius: 20, fontSize: 13, fontWeight: 500,
            background: !propFilter ? theme.accent : theme.fillTertiary,
            color: !propFilter ? 'white' : theme.t1,
            whiteSpace: 'nowrap',
          }}>All</div>
        </Pressable>
        {properties.map(p => (
          <Pressable key={p.id} onClick={() => setPropFilter(p.id)} scale={0.94}>
            <div style={{
              padding: '6px 14px', borderRadius: 20, fontSize: 13, fontWeight: 500,
              background: propFilter === p.id ? theme.accent : theme.fillTertiary,
              color: propFilter === p.id ? 'white' : theme.t1,
              whiteSpace: 'nowrap',
              display: 'flex', alignItems: 'center', gap: 5,
            }}>{p.emoji}{p.name}</div>
          </Pressable>
        ))}
      </div>

      {/* Calendar */}
      <Card theme={theme} style={{ marginBottom: 0 }}>
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '12px 16px', borderBottom: `0.5px solid ${theme.sep}`,
        }}>
          <Pressable onClick={() => { if (month === 0) { setMonth(11); setYear(year - 1); } else setMonth(month - 1); }} scale={0.85}>
            <div style={{ width: 32, height: 32, borderRadius: 8, background: theme.fillTertiary, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Icon name="chevL" size={16} color={theme.t1} />
            </div>
          </Pressable>
          <div style={{ fontSize: 17, fontWeight: 600, color: theme.t1, letterSpacing: -0.3 }}>
            {MS_FULL[month]} {year}
          </div>
          <Pressable onClick={() => { if (month === 11) { setMonth(0); setYear(year + 1); } else setMonth(month + 1); }} scale={0.85}>
            <div style={{ width: 32, height: 32, borderRadius: 8, background: theme.fillTertiary, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Icon name="chevR" size={16} color={theme.t1} />
            </div>
          </Pressable>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)' }}>
          {DOWS.map((d, i) => (
            <div key={i} style={{
              padding: '8px 0', textAlign: 'center', fontSize: 11,
              fontWeight: 600, color: theme.t2,
            }}>{d}</div>
          ))}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', padding: '0 6px 8px' }}>
          {cells.map((c, i) => {
            const isToday = !c.other && c.day === TD && month === TM && year === TY;
            const evs = c.other ? [] : evtFor(c.day);
            return (
              <div key={i} style={{
                minHeight: 56, padding: 3,
                opacity: c.other ? 0.3 : 1,
              }}>
                <div style={{
                  width: 22, height: 22, borderRadius: 11,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  background: isToday ? theme.accent : 'transparent',
                  color: isToday ? 'white' : theme.t1,
                  fontSize: 13, fontWeight: isToday ? 700 : 400,
                  margin: '2px auto 1px',
                }}>{c.day}</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                  {evs.slice(0, 2).map((e, j) => (
                    <div key={j} style={{
                      fontSize: 8, fontWeight: 600,
                      padding: '1px 3px', borderRadius: 3,
                      background: e.color + '33', color: e.color,
                      whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
                      borderLeft: e.kind === 'in' ? `2px solid ${e.color}` : 'none',
                    }}>{e.label.split(' ')[0]}</div>
                  ))}
                  {evs.length > 2 && (
                    <div style={{ fontSize: 8, color: theme.t2, textAlign: 'center' }}>+{evs.length - 2}</div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </Card>

      {/* Upcoming list */}
      <SectionHeader title="Upcoming" theme={theme} />
      <Card theme={theme}>
        {upcoming.length === 0 && <div style={{ padding: 20, textAlign: 'center', color: theme.t2, fontSize: 14 }}>No upcoming bookings</div>}
        {upcoming.map((b, i) => {
          const p = properties.find(x => x.id === b.property_id);
          const propIdx = properties.findIndex(x => x.id === b.property_id);
          const c = ['#34C759', '#FF9500', '#5856D6', '#FF2D55', '#30B0C7', '#AF52DE'][propIdx % 6];
          return (
            <div key={b.id} style={{
              display: 'flex', alignItems: 'center', gap: 12, padding: '12px 16px',
              borderBottom: i < upcoming.length - 1 ? `0.5px solid ${theme.sep}` : 'none',
            }}>
              <div style={{
                width: 44, textAlign: 'center', flexShrink: 0,
                background: theme.fillTertiary, borderRadius: 10, padding: '6px 0',
              }}>
                <div style={{ fontSize: 10, color: c, fontWeight: 700, textTransform: 'uppercase' }}>{MSS[new Date(b.check_in + 'T00:00:00').getMonth()]}</div>
                <div style={{ fontSize: 18, color: theme.t1, fontWeight: 700, lineHeight: 1, marginTop: 1 }}>{new Date(b.check_in + 'T00:00:00').getDate()}</div>
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 15, color: theme.t1, fontWeight: 500 }}>{b.guest}</div>
                <div style={{ fontSize: 12, color: theme.t2, marginTop: 2 }}>
                  {p?.name} · {nights(b.check_in, b.check_out)} nights · {fmtMoney((b.rate || 0) * nights(b.check_in, b.check_out))}
                </div>
              </div>
              <Icon name="chevR" size={14} color={theme.t3} />
            </div>
          );
        })}
      </Card>

      <div style={{ height: 110 }} />
    </>
  );
}

// ─────────────────────────────────────────────────────────────
// FINANCES VIEW
// ─────────────────────────────────────────────────────────────
function FinancesView({ data, theme, openSheet }) {
  const { properties, expenses } = data;
  const [scope, setScope] = useStateV('all');

  const scoped = useMemoV(() => {
    if (scope === 'all') return { props: properties, exp: expenses };
    const p = properties.find(x => x.id === scope);
    return { props: p ? [p] : [], exp: expenses.filter(e => e.property_id === scope) };
  }, [scope, properties, expenses]);

  const totalIncome = scoped.props.reduce((s, p) => s + Number(p.rev || 0), 0);
  const totalExp = scoped.exp.reduce((s, e) => s + Number(e.amount || 0), 0);
  const net = totalIncome - totalExp;
  const margin = totalIncome > 0 ? Math.round((net / totalIncome) * 100) : 0;

  // expenses by category
  const byCat = useMemoV(() => {
    const m = {};
    scoped.exp.forEach(e => {
      m[e.category] = (m[e.category] || 0) + Number(e.amount || 0);
    });
    return Object.entries(m)
      .map(([k, v]) => ({ key: k, value: v, meta: CAT_META[k] || CAT_META.other }))
      .sort((a, b) => b.value - a.value);
  }, [scoped.exp]);

  return (
    <>
      <HeaderTitle title="Finances" subtitle="May 2026" theme={theme} />

      {/* Scope picker */}
      <div style={{ padding: '0 16px 14px', display: 'flex', gap: 6, overflowX: 'auto' }}>
        <Pressable onClick={() => setScope('all')} scale={0.94}>
          <div style={{
            padding: '6px 14px', borderRadius: 20, fontSize: 13, fontWeight: 500,
            background: scope === 'all' ? theme.accent : theme.fillTertiary,
            color: scope === 'all' ? 'white' : theme.t1, whiteSpace: 'nowrap',
          }}>All Properties</div>
        </Pressable>
        {properties.map(p => (
          <Pressable key={p.id} onClick={() => setScope(p.id)} scale={0.94}>
            <div style={{
              padding: '6px 14px', borderRadius: 20, fontSize: 13, fontWeight: 500,
              background: scope === p.id ? theme.accent : theme.fillTertiary,
              color: scope === p.id ? 'white' : theme.t1, whiteSpace: 'nowrap',
            }}>{p.name}</div>
          </Pressable>
        ))}
      </div>

      {/* Big net card */}
      <Card theme={theme} padding={20} style={{ marginBottom: 12 }}>
        <div style={{ fontSize: 13, color: theme.t2, fontWeight: 500, letterSpacing: -0.1 }}>Net Income</div>
        <div style={{ fontSize: 42, fontWeight: 700, color: net >= 0 ? theme.green : theme.red, letterSpacing: -1.4, marginTop: 2, lineHeight: 1.1 }}>
          {fmtMoney(net)}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 6 }}>
          <Icon name={net >= 0 ? 'arrowUp' : 'arrowDown'} size={12} color={net >= 0 ? theme.green : theme.red} />
          <span style={{ fontSize: 13, color: theme.t2 }}>{margin}% margin · {fmtMoney(totalIncome)} income</span>
        </div>

        {/* Income vs Expense bar */}
        <div style={{ marginTop: 18 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: theme.t2, marginBottom: 6 }}>
            <span>Income {fmtMoney(totalIncome, { compact: true })}</span>
            <span>Expenses {fmtMoney(totalExp, { compact: true })}</span>
          </div>
          <div style={{ height: 10, background: theme.fillTertiary, borderRadius: 5, overflow: 'hidden', display: 'flex' }}>
            <div style={{
              width: totalIncome > 0 ? `${(net / totalIncome) * 100}%` : '0%',
              background: theme.green, transition: 'width 600ms cubic-bezier(0.32, 0.72, 0, 1)',
            }} />
            <div style={{
              width: totalIncome > 0 ? `${(totalExp / totalIncome) * 100}%` : '0%',
              background: theme.red, opacity: 0.85,
              transition: 'width 600ms cubic-bezier(0.32, 0.72, 0, 1)',
            }} />
          </div>
        </div>
      </Card>

      {/* By category */}
      <SectionHeader title="By Category" theme={theme} />
      <Card theme={theme}>
        {byCat.length === 0 && (
          <div style={{ padding: 20, textAlign: 'center', color: theme.t2, fontSize: 14 }}>
            No expenses yet
          </div>
        )}
        {byCat.map((c, i) => {
          const pct = totalExp > 0 ? Math.round((c.value / totalExp) * 100) : 0;
          return (
            <div key={c.key} style={{
              padding: '12px 16px',
              borderBottom: i < byCat.length - 1 ? `0.5px solid ${theme.sep}` : 'none',
              display: 'flex', alignItems: 'center', gap: 12,
            }}>
              <div style={{
                width: 32, height: 32, borderRadius: 10,
                background: theme[c.meta.c] + '22',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <div style={{ width: 8, height: 8, borderRadius: 4, background: theme[c.meta.c] }} />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: 15, color: theme.t1, fontWeight: 500 }}>{c.meta.l}</span>
                  <span style={{ fontSize: 15, color: theme.t1, fontWeight: 600 }}>{fmtMoney(c.value)}</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 4 }}>
                  <div style={{ flex: 1, height: 4, background: theme.fillTertiary, borderRadius: 2, overflow: 'hidden' }}>
                    <div style={{ width: `${pct}%`, height: '100%', background: theme[c.meta.c] }} />
                  </div>
                  <span style={{ fontSize: 11, color: theme.t2, minWidth: 32, textAlign: 'right' }}>{pct}%</span>
                </div>
              </div>
            </div>
          );
        })}
      </Card>

      {/* Recent expenses */}
      <SectionHeader title="Recent" action={{ label: '+ Add', onClick: () => openSheet({ kind: 'newExpense' }) }} theme={theme} />
      <Card theme={theme}>
        {scoped.exp.slice(0, 8).map((e, i, arr) => {
          const meta = CAT_META[e.category] || CAT_META.other;
          const p = properties.find(x => x.id === e.property_id);
          return (
            <SwipeRow
              key={e.id}
              theme={theme}
              actions={[
                { icon: 'trash', label: 'Delete', color: 'red',
                  onClick: () => {} },
              ]}
            >
              <div style={{
                display: 'flex', alignItems: 'center', gap: 12, padding: '12px 16px',
                borderBottom: i < arr.length - 1 ? `0.5px solid ${theme.sep}` : 'none',
              }}>
                <div style={{
                  width: 32, height: 32, borderRadius: 10,
                  background: theme[meta.c] + '22',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  flexShrink: 0,
                }}>
                  <div style={{ width: 8, height: 8, borderRadius: 4, background: theme[meta.c] }} />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 15, color: theme.t1, fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{e.desc}</div>
                  <div style={{ fontSize: 12, color: theme.t2, marginTop: 2 }}>{p?.name} · {fmtDate(e.date)}</div>
                </div>
                <span style={{ fontSize: 15, color: theme.t1, fontWeight: 600 }}>−{fmtMoney(e.amount)}</span>
              </div>
            </SwipeRow>
          );
        })}
      </Card>

      <div style={{ height: 110 }} />
    </>
  );
}

// ─────────────────────────────────────────────────────────────
// RENTERS VIEW
// ─────────────────────────────────────────────────────────────
function RentersView({ data, theme, openSheet }) {
  const { bookings, stays, properties } = data;

  const guests = useMemoV(() => {
    const m = {};
    bookings.forEach(b => {
      if (!m[b.guest]) m[b.guest] = { name: b.guest, bookings: [], stays: [], total: 0 };
      m[b.guest].bookings.push(b);
      m[b.guest].total += Number(b.rate || 0) * nights(b.check_in, b.check_out);
    });
    (stays || []).forEach(s => {
      if (!m[s.guest_name]) m[s.guest_name] = { name: s.guest_name, bookings: [], stays: [], total: 0 };
      m[s.guest_name].stays.push(s);
      m[s.guest_name].total += Number(s.amount || 0);
    });
    return Object.values(m).sort((a, b) => b.total - a.total);
  }, [bookings, stays]);

  return (
    <>
      <HeaderTitle title="Guests" subtitle={`${guests.length} guests · ${fmtMoney(guests.reduce((s, g) => s + g.total, 0))} lifetime`} theme={theme} />

      <div style={{ padding: '0 16px 14px' }}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 8,
          background: theme.fillTertiary, borderRadius: 10, padding: '8px 12px',
        }}>
          <Icon name="search" size={16} color={theme.t2} />
          <span style={{ fontSize: 15, color: theme.t2, letterSpacing: -0.2 }}>Search guests</span>
        </div>
      </div>

      <Card theme={theme}>
        {guests.map((g, i) => {
          const allDates = [...g.bookings.map(b => b.check_in), ...g.stays.map(s => s.check_in)].sort();
          const visits = g.bookings.length + g.stays.length;
          const isRepeat = visits > 1;
          return (
            <Pressable
              key={g.name}
              onClick={() => openSheet({ kind: 'guestDetail', name: g.name })}
              scale={0.99}
            >
              <div style={{
                display: 'flex', alignItems: 'center', gap: 12, padding: '12px 16px',
                borderBottom: i < guests.length - 1 ? `0.5px solid ${theme.sep}` : 'none',
              }}>
                <div style={{
                  width: 40, height: 40, borderRadius: 20,
                  background: avatarColor(g.name), color: 'white',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 15, fontWeight: 600, flexShrink: 0,
                }}>{initials(g.name)}</div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <span style={{ fontSize: 15, color: theme.t1, fontWeight: 500 }}>{g.name}</span>
                    {isRepeat && (
                      <span style={{
                        fontSize: 10, fontWeight: 700,
                        padding: '2px 6px', borderRadius: 8,
                        background: theme.yellow + '22', color: theme.orange,
                      }}>★ REPEAT</span>
                    )}
                  </div>
                  <div style={{ fontSize: 12, color: theme.t2, marginTop: 2 }}>
                    {visits} visit{visits !== 1 ? 's' : ''} · {fmtMoney(g.total)} total
                  </div>
                </div>
                <Icon name="chevR" size={14} color={theme.t3} />
              </div>
            </Pressable>
          );
        })}
      </Card>

      <div style={{ height: 110 }} />
    </>
  );
}

function initials(name) {
  return name.split(/\s+/).slice(0, 2).map(s => s[0]).join('').toUpperCase();
}
function avatarColor(name) {
  const colors = ['#FF9500', '#34C759', '#007AFF', '#AF52DE', '#FF2D55', '#5856D6', '#30B0C7', '#FF3B30'];
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) | 0;
  return colors[Math.abs(h) % colors.length];
}

// ─────────────────────────────────────────────────────────────
// EmptyState
// ─────────────────────────────────────────────────────────────
function EmptyState({ icon, title, subtitle, theme }) {
  return (
    <div style={{ padding: '60px 20px', textAlign: 'center' }}>
      <div style={{
        width: 64, height: 64, borderRadius: 32, margin: '0 auto 14px',
        background: theme.fillTertiary, display: 'flex',
        alignItems: 'center', justifyContent: 'center',
      }}>
        <Icon name={icon} size={28} color={theme.t2} />
      </div>
      <div style={{ fontSize: 17, fontWeight: 600, color: theme.t1, marginBottom: 4 }}>{title}</div>
      <div style={{ fontSize: 14, color: theme.t2 }}>{subtitle}</div>
    </div>
  );
}

Object.assign(window, { PropertiesView, TasksView, CalendarView, FinancesView, RentersView,
  HeaderTitle, SectionHeader, Card, StatusPill, EmptyState, Segmented, Stat, SummaryChip,
  PriorityDot, initials, avatarColor });
