// Caldwell Living — iOS-native redesign
// Stock iOS look (SF Pro, system grays, blue accent), system-aware theme,
// pull-to-refresh, swipe-to-delete rows, sheet modals, spring taps, floating pill nav.

const {
  useState,
  useEffect,
  useRef,
  useMemo,
  useCallback,
  createContext,
  useContext
} = React;

// ─────────────────────────────────────────────────────────────
// Theme
// ─────────────────────────────────────────────────────────────
const ThemeCtx = createContext(null);

// Dark Luxe — black + gold, serif headlines, premium real-estate aesthetic.
// We expose both keys but force `dark` (luxe is dark-only).
const palettes = {
  light: {
    bg: '#0A0A0B',
    bg2: '#141416',
    bg3: '#1C1C1F',
    card: '#141416',
    cardHover: '#1C1C1F',
    sep: 'rgba(201,169,97,0.14)',
    sepThin: 'rgba(201,169,97,0.08)',
    t1: '#F4EFE6',
    t2: 'rgba(244,239,230,0.62)',
    t3: 'rgba(244,239,230,0.32)',
    accent: '#C9A961',
    accentSoft: 'rgba(201,169,97,0.14)',
    blue: '#7FA4C7',
    green: '#7FA88A',
    red: '#C76B5F',
    orange: '#D69A5C',
    yellow: '#D4B86A',
    purple: '#A88FB8',
    teal: '#6FA8A8',
    pink: '#C78A9C',
    indigo: '#8B85B5',
    gray: '#7A746B',
    fillTertiary: 'rgba(201,169,97,0.06)',
    fillSecondary: 'rgba(201,169,97,0.10)',
    fillPrimary: 'rgba(201,169,97,0.16)',
    gold: '#C9A961',
    goldDim: '#8F7843',
    cream: '#F4EFE6'
  },
  dark: {
    bg: '#0A0A0B',
    bg2: '#141416',
    bg3: '#1C1C1F',
    card: '#141416',
    cardHover: '#1C1C1F',
    sep: 'rgba(201,169,97,0.14)',
    sepThin: 'rgba(201,169,97,0.08)',
    t1: '#F4EFE6',
    t2: 'rgba(244,239,230,0.62)',
    t3: 'rgba(244,239,230,0.32)',
    accent: '#C9A961',
    accentSoft: 'rgba(201,169,97,0.14)',
    blue: '#7FA4C7',
    green: '#7FA88A',
    red: '#C76B5F',
    orange: '#D69A5C',
    yellow: '#D4B86A',
    purple: '#A88FB8',
    teal: '#6FA8A8',
    pink: '#C78A9C',
    indigo: '#8B85B5',
    gray: '#7A746B',
    fillTertiary: 'rgba(201,169,97,0.06)',
    fillSecondary: 'rgba(201,169,97,0.10)',
    fillPrimary: 'rgba(201,169,97,0.16)',
    gold: '#C9A961',
    goldDim: '#8F7843',
    cream: '#F4EFE6'
  }
};
const SERIF = "'Fraunces', Georgia, 'Times New Roman', serif";
function useTheme() {
  return useContext(ThemeCtx);
}

// ─────────────────────────────────────────────────────────────
// Data layer — Supabase + offline-friendly sample fallback
// ─────────────────────────────────────────────────────────────
const SUPA_URL = 'https://sfnlocmdukdtuotawqdu.supabase.co';
const SUPA_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNmbmxvY21kdWtkdHVvdGF3cWR1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzc5MDE2MjEsImV4cCI6MjA5MzQ3NzYyMX0.aTiEeZjjU83tNWWO8MZWoH5CPFnE4zJmJkL_cPGrHvQ';
let supa = null;
try {
  if (window.supabase) supa = window.supabase.createClient(SUPA_URL, SUPA_KEY);
} catch (e) {}

// Realistic sample data — used if Supabase fails or returns empty.
const SAMPLE = {
  properties: [{
    id: 'p1',
    name: 'Lakeside Cabin',
    addr: '12 Pine Ridge Dr, Blue Ridge, GA',
    emoji: '🏡',
    rev: 4200,
    status: 'booked',
    next_renter: 'The Hartleys',
    sort_order: 1
  }, {
    id: 'p2',
    name: 'Downtown Loft',
    addr: '450 Peachtree St NE, Atlanta, GA',
    emoji: '🏙️',
    rev: 3100,
    status: 'vacant',
    next_renter: null,
    sort_order: 2
  }, {
    id: 'p3',
    name: 'Mountain Retreat',
    addr: '88 Eagle Crest Way, Asheville, NC',
    emoji: '⛰️',
    rev: 5400,
    status: 'maint',
    next_renter: null,
    sort_order: 3
  }, {
    id: 'p4',
    name: 'Beachfront Bungalow',
    addr: '23 Shoreline Ave, St. Augustine, FL',
    emoji: '🌴',
    rev: 6200,
    status: 'prep',
    next_renter: 'Smith Family',
    sort_order: 4
  }],
  bookings: [{
    id: 'b1',
    property_id: 'p1',
    guest: 'The Hartleys',
    check_in: '2026-05-04',
    check_out: '2026-05-11',
    rate: 320,
    notes: 'Anniversary trip'
  }, {
    id: 'b2',
    property_id: 'p1',
    guest: 'Chen Party',
    check_in: '2026-05-15',
    check_out: '2026-05-18',
    rate: 340,
    notes: ''
  }, {
    id: 'b3',
    property_id: 'p4',
    guest: 'Smith Family',
    check_in: '2026-05-09',
    check_out: '2026-05-16',
    rate: 410,
    notes: 'Early check-in 1pm'
  }, {
    id: 'b4',
    property_id: 'p2',
    guest: 'Marcus Webb',
    check_in: '2026-05-20',
    check_out: '2026-05-23',
    rate: 280,
    notes: ''
  }],
  tasks: [{
    id: 't1',
    text: 'Replace HVAC filter',
    property_id: 'p3',
    priority: 'high',
    due: 'today',
    done: false,
    notes: 'Air handler in basement closet — 16x25x1',
    assignees: ['Jay'],
    created_at: '2026-05-06T10:00:00Z'
  }, {
    id: 't2',
    text: 'Restock coffee + soap before Hartleys arrive',
    property_id: 'p1',
    priority: 'urgent',
    due: 'today',
    done: false,
    notes: '',
    assignees: ['Cleaner'],
    created_at: '2026-05-06T11:00:00Z'
  }, {
    id: 't3',
    text: 'Quote new water heater',
    property_id: 'p3',
    priority: 'med',
    due: 'May 10',
    done: false,
    notes: 'Anode rod is shot, ~12yr old tank',
    assignees: ['Plumber'],
    created_at: '2026-05-05T14:00:00Z'
  }, {
    id: 't4',
    text: 'Renew vacation rental permit',
    property_id: 'p4',
    priority: 'high',
    due: 'May 14',
    done: false,
    notes: '',
    assignees: ['Justin'],
    created_at: '2026-05-04T09:00:00Z'
  }, {
    id: 't5',
    text: 'Mow + trim lakeside lawn',
    property_id: 'p1',
    priority: 'low',
    due: 'May 12',
    done: false,
    notes: '',
    assignees: ['Landscaper'],
    created_at: '2026-05-03T08:00:00Z'
  }, {
    id: 't6',
    text: 'Deep clean after Smith checkout',
    property_id: 'p4',
    priority: 'med',
    due: 'May 16',
    done: false,
    notes: '',
    assignees: ['Cleaner'],
    created_at: '2026-05-03T08:00:00Z'
  }, {
    id: 't7',
    text: 'Pay April mortgage',
    property_id: 'p2',
    priority: 'urgent',
    due: 'today',
    done: true,
    notes: '',
    assignees: ['Justin'],
    completed_at: '2026-05-06T08:30:00Z',
    created_at: '2026-05-01T08:00:00Z'
  }],
  expenses: [{
    id: 'e1',
    property_id: 'p1',
    category: 'cleaning',
    desc: 'Turnover clean',
    amount: 180,
    date: '2026-05-04'
  }, {
    id: 'e2',
    property_id: 'p3',
    category: 'hvac',
    desc: 'AC tune-up + freon',
    amount: 420,
    date: '2026-04-28'
  }, {
    id: 'e3',
    property_id: 'p1',
    category: 'mortgage',
    desc: 'May mortgage',
    amount: 1850,
    date: '2026-05-01'
  }, {
    id: 'e4',
    property_id: 'p2',
    category: 'mortgage',
    desc: 'May mortgage',
    amount: 1620,
    date: '2026-05-01'
  }, {
    id: 'e5',
    property_id: 'p4',
    category: 'landscaping',
    desc: 'Beach grass trim',
    amount: 95,
    date: '2026-04-25'
  }, {
    id: 'e6',
    property_id: 'p3',
    category: 'plumbing',
    desc: 'Leaky kitchen faucet',
    amount: 240,
    date: '2026-04-22'
  }, {
    id: 'e7',
    property_id: 'p2',
    category: 'electrical',
    desc: 'GFCI outlet replacement',
    amount: 130,
    date: '2026-04-18'
  }, {
    id: 'e8',
    property_id: 'p4',
    category: 'supplies',
    desc: 'Linens + towels restock',
    amount: 215,
    date: '2026-04-15'
  }],
  stays: [{
    id: 's1',
    guest_name: 'The Hartleys',
    property_id: 'p1',
    check_in: '2025-09-12',
    check_out: '2025-09-19',
    amount: 2240,
    note: 'Returning guests'
  }, {
    id: 's2',
    guest_name: 'Smith Family',
    property_id: 'p4',
    check_in: '2025-07-10',
    check_out: '2025-07-17',
    amount: 2870,
    note: 'Loved the property'
  }, {
    id: 's3',
    guest_name: 'Chen Party',
    property_id: 'p1',
    check_in: '2025-11-22',
    check_out: '2025-11-26',
    amount: 1360,
    note: 'Thanksgiving stay'
  }]
};
async function fetchAll() {
  if (!supa) return SAMPLE;
  try {
    const [pr, bk, tk, ex, st] = await Promise.all([supa.from('properties').select('*').order('sort_order', {
      ascending: true
    }), supa.from('bookings').select('*').order('check_in', {
      ascending: true
    }), supa.from('tasks').select('*').order('created_at', {
      ascending: true
    }), supa.from('expenses').select('*').order('date', {
      ascending: false
    }), supa.from('stays').select('*').order('check_in', {
      ascending: false
    })]);
    const out = {
      properties: pr.data || [],
      bookings: bk.data || [],
      tasks: tk.data || [],
      expenses: ex.data || [],
      stays: st.data || []
    };
    if (!out.properties.length) return SAMPLE;
    return out;
  } catch (e) {
    console.warn('Supabase fetch failed, using sample data', e);
    return SAMPLE;
  }
}

// ─────────────────────────────────────────────────────────────
// Utilities
// ─────────────────────────────────────────────────────────────
const MSS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MS_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const DOWS = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
const TODAY = new Date(2026, 4, 7); // May 7, 2026 — matches current date
const TY = TODAY.getFullYear(),
  TM = TODAY.getMonth(),
  TD = TODAY.getDate();
const fmtMoney = (n, opts = {}) => {
  const v = Number(n || 0);
  if (opts.compact && Math.abs(v) >= 1000) return '$' + (v / 1000).toFixed(1).replace(/\.0$/, '') + 'k';
  return '$' + v.toLocaleString();
};
const fmtDate = d => {
  if (!d) return '';
  const dt = typeof d === 'string' ? new Date(d + 'T00:00:00') : d;
  return MSS[dt.getMonth()] + ' ' + dt.getDate();
};
const fmtDateLong = d => {
  if (!d) return '';
  const dt = typeof d === 'string' ? new Date(d + 'T00:00:00') : d;
  return MSS[dt.getMonth()] + ' ' + dt.getDate() + ', ' + dt.getFullYear();
};
const nights = (a, b) => {
  const d1 = new Date(a + 'T00:00:00'),
    d2 = new Date(b + 'T00:00:00');
  return Math.round((d2 - d1) / 86400000);
};
const parseDue = s => {
  if (!s) return null;
  s = s.toLowerCase().trim();
  if (s === 'today') return TODAY;
  if (s === 'tomorrow') {
    const d = new Date(TODAY);
    d.setDate(d.getDate() + 1);
    return d;
  }
  // Try "May 10" format
  const m = s.match(/^([a-z]{3,9})\s+(\d{1,2})$/);
  if (m) {
    const idx = MS_FULL.findIndex(x => x.toLowerCase().startsWith(m[1].slice(0, 3)));
    if (idx >= 0) return new Date(TY, idx, parseInt(m[2]));
  }
  return null;
};
const dueLabel = (s, theme) => {
  const d = parseDue(s);
  if (!d) return {
    text: s || '',
    color: theme.t2,
    bg: theme.fillTertiary
  };
  const diff = Math.round((d - TODAY) / 86400000);
  if (diff < 0) return {
    text: 'Overdue',
    color: theme.red,
    bg: theme.fillTertiary
  };
  if (diff === 0) return {
    text: 'Today',
    color: theme.red,
    bg: theme.fillTertiary
  };
  if (diff === 1) return {
    text: 'Tomorrow',
    color: theme.orange,
    bg: theme.fillTertiary
  };
  if (diff < 7) return {
    text: fmtDate(d),
    color: theme.orange,
    bg: theme.fillTertiary
  };
  return {
    text: fmtDate(d),
    color: theme.t2,
    bg: theme.fillTertiary
  };
};
const STATUS_META = {
  booked: {
    label: 'Booked',
    color: 'green'
  },
  vacant: {
    label: 'Available',
    color: 'orange'
  },
  maint: {
    label: 'Maintenance',
    color: 'red'
  },
  prep: {
    label: 'Preparing',
    color: 'purple'
  }
};
const PRIO_META = {
  urgent: {
    label: 'Urgent',
    color: 'red'
  },
  high: {
    label: 'High',
    color: 'orange'
  },
  med: {
    label: 'Medium',
    color: 'blue'
  },
  low: {
    label: 'Low',
    color: 'gray'
  }
};
const CAT_META = {
  landscaping: {
    l: 'Landscaping',
    c: 'green'
  },
  plumbing: {
    l: 'Plumbing',
    c: 'blue'
  },
  electrical: {
    l: 'Electrical',
    c: 'orange'
  },
  cleaning: {
    l: 'Cleaning',
    c: 'teal'
  },
  hvac: {
    l: 'HVAC',
    c: 'blue'
  },
  appliances: {
    l: 'Appliances',
    c: 'purple'
  },
  painting: {
    l: 'Painting',
    c: 'pink'
  },
  roofing: {
    l: 'Roofing',
    c: 'gray'
  },
  pest: {
    l: 'Pest Control',
    c: 'green'
  },
  supplies: {
    l: 'Supplies',
    c: 'orange'
  },
  insurance: {
    l: 'Insurance',
    c: 'purple'
  },
  mortgage: {
    l: 'Mortgage',
    c: 'red'
  },
  taxes: {
    l: 'Property Tax',
    c: 'pink'
  },
  other: {
    l: 'Other',
    c: 'gray'
  }
};

// SF-style icon set (SVG paths inline)
const Icon = ({
  name,
  size = 22,
  color = 'currentColor'
}) => {
  const paths = {
    house: /*#__PURE__*/React.createElement("path", {
      d: "M12 3l9 8h-2v9h-5v-6h-4v6H5v-9H3l9-8z"
    }),
    check: /*#__PURE__*/React.createElement("path", {
      d: "M5 12.5l4.5 4.5L19 7",
      stroke: color,
      strokeWidth: "2.4",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      fill: "none"
    }),
    calendar: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("rect", {
      x: "3",
      y: "5",
      width: "18",
      height: "16",
      rx: "3",
      stroke: color,
      strokeWidth: "1.8",
      fill: "none"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M8 3v4M16 3v4M3 10h18",
      stroke: color,
      strokeWidth: "1.8",
      strokeLinecap: "round",
      fill: "none"
    })),
    people: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("circle", {
      cx: "9",
      cy: "9",
      r: "3.5",
      stroke: color,
      strokeWidth: "1.8",
      fill: "none"
    }), /*#__PURE__*/React.createElement("circle", {
      cx: "17",
      cy: "10",
      r: "2.8",
      stroke: color,
      strokeWidth: "1.8",
      fill: "none"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M2.5 19c.8-3.2 3.4-5 6.5-5s5.7 1.8 6.5 5M16 14c2.5 0 4.5 1.4 5.2 4",
      stroke: color,
      strokeWidth: "1.8",
      strokeLinecap: "round",
      fill: "none"
    })),
    dollar: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("circle", {
      cx: "12",
      cy: "12",
      r: "9",
      stroke: color,
      strokeWidth: "1.8",
      fill: "none"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M14.5 9.5C14 8.5 13 8 12 8s-2.5.5-2.5 2 1.5 2 2.5 2 2.5.5 2.5 2-1.5 2-2.5 2-2-.5-2.5-1.5M12 6v2M12 16v2",
      stroke: color,
      strokeWidth: "1.6",
      strokeLinecap: "round",
      fill: "none"
    })),
    chart: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("path", {
      d: "M3 21V5M3 21h18",
      stroke: color,
      strokeWidth: "1.8",
      strokeLinecap: "round",
      fill: "none"
    }), /*#__PURE__*/React.createElement("rect", {
      x: "6",
      y: "13",
      width: "3",
      height: "6",
      fill: color
    }), /*#__PURE__*/React.createElement("rect", {
      x: "11",
      y: "9",
      width: "3",
      height: "10",
      fill: color
    }), /*#__PURE__*/React.createElement("rect", {
      x: "16",
      y: "5",
      width: "3",
      height: "14",
      fill: color
    })),
    plus: /*#__PURE__*/React.createElement("path", {
      d: "M12 5v14M5 12h14",
      stroke: color,
      strokeWidth: "2.4",
      strokeLinecap: "round",
      fill: "none"
    }),
    chevR: /*#__PURE__*/React.createElement("path", {
      d: "M9 6l6 6-6 6",
      stroke: color,
      strokeWidth: "2",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      fill: "none"
    }),
    chevL: /*#__PURE__*/React.createElement("path", {
      d: "M15 6l-6 6 6 6",
      stroke: color,
      strokeWidth: "2",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      fill: "none"
    }),
    search: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("circle", {
      cx: "10.5",
      cy: "10.5",
      r: "6",
      stroke: color,
      strokeWidth: "1.8",
      fill: "none"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M15 15l5 5",
      stroke: color,
      strokeWidth: "1.8",
      strokeLinecap: "round"
    })),
    sun: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("circle", {
      cx: "12",
      cy: "12",
      r: "4",
      stroke: color,
      strokeWidth: "1.8",
      fill: "none"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2",
      stroke: color,
      strokeWidth: "1.8",
      strokeLinecap: "round"
    })),
    moon: /*#__PURE__*/React.createElement("path", {
      d: "M21 13A9 9 0 1111 3c0 5 4 9 9 9 .3 0 .7 0 1 0z",
      stroke: color,
      strokeWidth: "1.8",
      strokeLinejoin: "round",
      fill: "none"
    }),
    bell: /*#__PURE__*/React.createElement("path", {
      d: "M6 16V11a6 6 0 1112 0v5l1.5 2H4.5L6 16zM10 20a2 2 0 004 0",
      stroke: color,
      strokeWidth: "1.8",
      strokeLinejoin: "round",
      strokeLinecap: "round",
      fill: "none"
    }),
    settings: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("circle", {
      cx: "12",
      cy: "12",
      r: "3",
      stroke: color,
      strokeWidth: "1.8",
      fill: "none"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M12 2v3M12 19v3M5 5l2 2M17 17l2 2M2 12h3M19 12h3M5 19l2-2M17 7l2-2",
      stroke: color,
      strokeWidth: "1.8",
      strokeLinecap: "round"
    })),
    trash: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("path", {
      d: "M4 7h16M9 7V4h6v3M6 7l1 13a2 2 0 002 2h6a2 2 0 002-2l1-13M10 11v7M14 11v7",
      stroke: color,
      strokeWidth: "1.7",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      fill: "none"
    })),
    edit: /*#__PURE__*/React.createElement("path", {
      d: "M16 3l5 5-12 12H4v-5L16 3z",
      stroke: color,
      strokeWidth: "1.8",
      strokeLinejoin: "round",
      fill: "none"
    }),
    close: /*#__PURE__*/React.createElement("path", {
      d: "M6 6l12 12M18 6L6 18",
      stroke: color,
      strokeWidth: "2",
      strokeLinecap: "round"
    }),
    bed: /*#__PURE__*/React.createElement("path", {
      d: "M3 18v-5a3 3 0 013-3h12a3 3 0 013 3v5M3 18h18M3 18v2M21 18v2M7 10V7a2 2 0 012-2h6a2 2 0 012 2v3",
      stroke: color,
      strokeWidth: "1.7",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      fill: "none"
    }),
    cloud: /*#__PURE__*/React.createElement("path", {
      d: "M8 18a5 5 0 010-10 6 6 0 0111-2 4 4 0 011 8H8z",
      stroke: color,
      strokeWidth: "1.8",
      strokeLinejoin: "round",
      fill: "none"
    }),
    arrowUp: /*#__PURE__*/React.createElement("path", {
      d: "M12 19V5M5 12l7-7 7 7",
      stroke: color,
      strokeWidth: "2",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      fill: "none"
    }),
    arrowDown: /*#__PURE__*/React.createElement("path", {
      d: "M12 5v14M19 12l-7 7-7-7",
      stroke: color,
      strokeWidth: "2",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      fill: "none"
    }),
    location: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("path", {
      d: "M12 22s8-9 8-13a8 8 0 10-16 0c0 4 8 13 8 13z",
      stroke: color,
      strokeWidth: "1.8",
      strokeLinejoin: "round",
      fill: "none"
    }), /*#__PURE__*/React.createElement("circle", {
      cx: "12",
      cy: "9",
      r: "2.5",
      stroke: color,
      strokeWidth: "1.8",
      fill: "none"
    }))
  };
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: paths[name] && paths[name].props && paths[name].props.fill === 'none' ? 'none' : color,
    style: {
      flexShrink: 0
    }
  }, paths[name]);
};

// ─────────────────────────────────────────────────────────────
// Pressable — spring-y tap feedback
// ─────────────────────────────────────────────────────────────
function Pressable({
  onClick,
  children,
  style,
  scale = 0.96,
  disabled
}) {
  const [down, setDown] = useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onPointerDown: () => !disabled && setDown(true),
    onPointerUp: () => setDown(false),
    onPointerLeave: () => setDown(false),
    onPointerCancel: () => setDown(false),
    onClick: e => {
      if (!disabled && onClick) onClick(e);
    },
    style: {
      transform: down ? `scale(${scale})` : 'scale(1)',
      transition: 'transform 180ms cubic-bezier(0.34, 1.56, 0.64, 1), opacity 120ms',
      opacity: down ? 0.85 : 1,
      cursor: disabled ? 'default' : 'pointer',
      userSelect: 'none',
      WebkitTapHighlightColor: 'transparent',
      ...style
    }
  }, children);
}

// ─────────────────────────────────────────────────────────────
// SwipeRow — drag-left to reveal actions
// ─────────────────────────────────────────────────────────────
function SwipeRow({
  children,
  actions = [],
  theme,
  onClick
}) {
  const [x, setX] = useState(0);
  const startX = useRef(0);
  const startY = useRef(0);
  const dragging = useRef(false);
  const decided = useRef(false);
  const hSwipe = useRef(false);
  const total = actions.reduce((s, a) => s + (a.width || 76), 0);
  const onPointerDown = e => {
    startX.current = e.clientX;
    startY.current = e.clientY;
    dragging.current = true;
    decided.current = false;
    hSwipe.current = false;
  };
  const onPointerMove = e => {
    if (!dragging.current) return;
    const dx = e.clientX - startX.current;
    const dy = e.clientY - startY.current;
    if (!decided.current) {
      if (Math.abs(dx) > 6 || Math.abs(dy) > 6) {
        decided.current = true;
        hSwipe.current = Math.abs(dx) > Math.abs(dy);
      }
    }
    if (!hSwipe.current) return;
    e.preventDefault();
    const next = Math.max(-total - 40, Math.min(0, x + dx - (e.lastDx || 0)));
    // simpler: track absolute from start
    const target = x === 0 ? Math.max(-total - 30, Math.min(0, dx)) : Math.max(-total - 30, Math.min(0, x + dx));
    setX(Math.max(-total - 30, Math.min(0, dx + (x < 0 && !decided.current ? x : 0))));
  };
  const onPointerUp = e => {
    if (!dragging.current) return;
    dragging.current = false;
    if (!hSwipe.current) {
      // treat as tap
      const dx = Math.abs(e.clientX - startX.current);
      const dy = Math.abs(e.clientY - startY.current);
      if (dx < 6 && dy < 6 && x === 0 && onClick) onClick();
      return;
    }
    if (x < -total / 2) setX(-total);else setX(0);
  };

  // simpler implementation: track from last committed offset
  const offsetRef = useRef(0);
  const onDown = e => {
    startX.current = e.clientX;
    startY.current = e.clientY;
    dragging.current = true;
    decided.current = false;
    hSwipe.current = false;
    offsetRef.current = x;
  };
  const onMove = e => {
    if (!dragging.current) return;
    const dx = e.clientX - startX.current;
    const dy = e.clientY - startY.current;
    if (!decided.current) {
      if (Math.abs(dx) > 6 || Math.abs(dy) > 6) {
        decided.current = true;
        hSwipe.current = Math.abs(dx) > Math.abs(dy);
      } else return;
    }
    if (!hSwipe.current) return;
    e.preventDefault();
    let nx = offsetRef.current + dx;
    if (nx > 0) nx = nx * 0.3; // rubber band right
    if (nx < -total) nx = -total + (nx + total) * 0.3; // rubber left
    setX(nx);
  };
  const onUp = e => {
    if (!dragging.current) return;
    dragging.current = false;
    if (!hSwipe.current) {
      const dx = Math.abs(e.clientX - startX.current);
      const dy = Math.abs(e.clientY - startY.current);
      if (dx < 6 && dy < 6 && x === 0 && onClick) onClick();
      return;
    }
    if (x < -total * 0.5) setX(-total);else setX(0);
  };
  const close = () => setX(0);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      overflow: 'hidden',
      borderRadius: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 0,
      right: 0,
      bottom: 0,
      display: 'flex',
      alignItems: 'stretch',
      opacity: x < -2 ? 1 : 0,
      pointerEvents: x < -10 ? 'auto' : 'none'
    }
  }, actions.map((a, i) => /*#__PURE__*/React.createElement(Pressable, {
    key: i,
    onClick: () => {
      close();
      a.onClick && a.onClick();
    },
    style: {
      width: a.width || 76,
      background: a.color === 'red' ? theme.red : a.color === 'blue' ? theme.blue : theme.gray,
      color: 'white',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexDirection: 'column',
      gap: 4,
      fontSize: 13,
      fontWeight: 500
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: a.icon,
    size: 20,
    color: "white"
  }), /*#__PURE__*/React.createElement("span", null, a.label)))), /*#__PURE__*/React.createElement("div", {
    onPointerDown: onDown,
    onPointerMove: onMove,
    onPointerUp: onUp,
    onPointerCancel: onUp,
    style: {
      transform: `translateX(${x}px)`,
      transition: dragging.current ? 'none' : 'transform 280ms cubic-bezier(0.32, 0.72, 0, 1)',
      background: theme.card,
      touchAction: 'pan-y'
    }
  }, children));
}

// ─────────────────────────────────────────────────────────────
// Sheet modal — drag down to dismiss with rubber-band
// ─────────────────────────────────────────────────────────────
function Sheet({
  open,
  onClose,
  children,
  title,
  theme,
  maxHeight = '88%'
}) {
  const [y, setY] = useState(0);
  const [mounted, setMounted] = useState(false);
  const startY = useRef(0);
  const dragging = useRef(false);
  useEffect(() => {
    if (open) {
      setMounted(true);
      requestAnimationFrame(() => setY(0));
    } else setY(800);
  }, [open]);
  if (!open && !mounted) return null;
  const onDown = e => {
    startY.current = e.clientY;
    dragging.current = true;
  };
  const onMove = e => {
    if (!dragging.current) return;
    const dy = e.clientY - startY.current;
    if (dy > 0) setY(dy);else setY(dy * 0.2); // rubber up
  };
  const onUp = () => {
    if (!dragging.current) return;
    dragging.current = false;
    if (y > 120) {
      setY(800);
      setTimeout(() => {
        setMounted(false);
        onClose();
      }, 280);
    } else setY(0);
  };
  return /*#__PURE__*/React.createElement("div", {
    onClick: e => {
      if (e.target === e.currentTarget) {
        setY(800);
        setTimeout(() => {
          setMounted(false);
          onClose();
        }, 280);
      }
    },
    style: {
      position: 'absolute',
      inset: 0,
      zIndex: 100,
      background: open && y < 100 ? 'rgba(0,0,0,0.4)' : 'rgba(0,0,0,0)',
      transition: 'background 280ms',
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'center',
      backdropFilter: y < 50 ? 'blur(4px)' : 'none',
      WebkitBackdropFilter: y < 50 ? 'blur(4px)' : 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: theme.bg2,
      width: '100%',
      borderRadius: '14px 14px 0 0',
      maxHeight,
      display: 'flex',
      flexDirection: 'column',
      transform: `translateY(${open ? y : 800}px)`,
      transition: dragging.current ? 'none' : 'transform 380ms cubic-bezier(0.32, 0.72, 0, 1)',
      boxShadow: '0 -10px 40px rgba(0,0,0,0.25)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    onPointerDown: onDown,
    onPointerMove: onMove,
    onPointerUp: onUp,
    onPointerCancel: onUp,
    style: {
      padding: '8px 0 4px',
      display: 'flex',
      justifyContent: 'center',
      cursor: 'grab',
      touchAction: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 36,
      height: 5,
      borderRadius: 3,
      background: theme.t3
    }
  })), title && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '6px 16px 14px',
      borderBottom: `0.5px solid ${theme.sep}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 60
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 17,
      fontWeight: 600,
      color: theme.t1,
      letterSpacing: -0.4
    }
  }, title), /*#__PURE__*/React.createElement(Pressable, {
    onClick: () => {
      setY(800);
      setTimeout(() => {
        setMounted(false);
        onClose();
      }, 280);
    },
    style: {
      width: 60,
      textAlign: 'right'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 17,
      color: theme.accent,
      fontWeight: 400
    }
  }, "Done"))), /*#__PURE__*/React.createElement("div", {
    style: {
      overflowY: 'auto',
      WebkitOverflowScrolling: 'touch',
      flex: 1
    }
  }, children)));
}

// ─────────────────────────────────────────────────────────────
// Pull to refresh
// ─────────────────────────────────────────────────────────────
function PullToRefresh({
  onRefresh,
  children,
  theme
}) {
  const [pull, setPull] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const startY = useRef(0);
  const scrollerRef = useRef(null);
  const dragging = useRef(false);
  const onDown = e => {
    if (refreshing) return;
    if (scrollerRef.current && scrollerRef.current.scrollTop > 0) return;
    startY.current = e.clientY;
    dragging.current = true;
  };
  const onMove = e => {
    if (!dragging.current || refreshing) return;
    const dy = e.clientY - startY.current;
    if (dy > 0) {
      setPull(Math.min(120, dy * 0.5));
    } else if (dy < 0 && pull > 0) {
      setPull(Math.max(0, pull + dy * 0.5));
    }
  };
  const onUp = async () => {
    if (!dragging.current) return;
    dragging.current = false;
    if (pull > 60) {
      setRefreshing(true);
      setPull(56);
      try {
        await onRefresh();
      } finally {
        setTimeout(() => {
          setPull(0);
          setRefreshing(false);
        }, 400);
      }
    } else {
      setPull(0);
    }
  };
  return /*#__PURE__*/React.createElement("div", {
    onPointerDown: onDown,
    onPointerMove: onMove,
    onPointerUp: onUp,
    onPointerCancel: onUp,
    style: {
      position: 'relative',
      flex: 1,
      minHeight: 0,
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      height: pull,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      opacity: pull / 60
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 22,
      height: 22,
      borderRadius: 11,
      border: `2px solid ${theme.t3}`,
      borderTopColor: theme.accent,
      animation: refreshing ? 'spin 0.8s linear infinite' : 'none',
      transform: refreshing ? 'none' : `rotate(${pull * 4}deg)`
    }
  })), /*#__PURE__*/React.createElement("div", {
    ref: scrollerRef,
    style: {
      flex: 1,
      overflowY: 'auto',
      WebkitOverflowScrolling: 'touch',
      transform: `translateY(${pull}px)`,
      transition: dragging.current ? 'none' : 'transform 280ms cubic-bezier(0.32, 0.72, 0, 1)'
    }
  }, children));
}
Object.assign(window, {
  ThemeCtx,
  palettes,
  useTheme,
  fetchAll,
  SAMPLE,
  SERIF,
  fmtMoney,
  fmtDate,
  fmtDateLong,
  nights,
  parseDue,
  dueLabel,
  STATUS_META,
  PRIO_META,
  CAT_META,
  MSS,
  MS_FULL,
  DOWS,
  TODAY,
  TY,
  TM,
  TD,
  Icon,
  Pressable,
  SwipeRow,
  Sheet,
  PullToRefresh
});