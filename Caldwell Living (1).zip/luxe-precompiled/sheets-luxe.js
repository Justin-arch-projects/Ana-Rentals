// Sheets — bottom sheets for detail / add / edit flows
const {
  useState: useStateS,
  useEffect: useEffectS,
  useMemo: useMemoS
} = React;

// ─────────────────────────────────────────────────────────────
// Property detail sheet
// ─────────────────────────────────────────────────────────────
function PropertyDetailSheet({
  id,
  data,
  theme,
  openSheet,
  closeSheet
}) {
  const p = data.properties.find(x => x.id === id);
  if (!p) return null;
  const propBookings = data.bookings.filter(b => b.property_id === id);
  const propExp = data.expenses.filter(e => e.property_id === id);
  const propTasks = data.tasks.filter(t => t.property_id === id && !t.done);
  const inc = Number(p.rev || 0);
  const exp = propExp.reduce((s, e) => s + Number(e.amount || 0), 0);
  const net = inc - exp;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      paddingBottom: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 140,
      background: p.image_url ? `linear-gradient(180deg, rgba(0,0,0,0.1), rgba(0,0,0,0.5)), url(${p.image_url}) center/cover no-repeat` : heroGrad(p, data.properties.indexOf(p)),
      margin: '4px 16px 0',
      borderRadius: 14,
      display: 'flex',
      alignItems: 'flex-end',
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 56,
      lineHeight: 1,
      filter: 'drop-shadow(0 2px 12px rgba(0,0,0,0.25))',
      display: p.image_url ? 'none' : 'block'
    }
  }, p.emoji || '🏡')), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '14px 20px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 22,
      fontWeight: 700,
      color: theme.t1,
      letterSpacing: -0.5
    }
  }, p.name), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 4,
      marginTop: 4,
      color: theme.t2,
      fontSize: 14
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "location",
    size: 13,
    color: theme.t2
  }), p.addr)), /*#__PURE__*/React.createElement(StatusPill, {
    status: p.status,
    theme: theme
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr 1fr',
      gap: 8,
      padding: '16px 16px 0'
    }
  }, /*#__PURE__*/React.createElement(BigStat, {
    label: "Income",
    value: fmtMoney(inc, {
      compact: true
    }),
    color: theme.t1,
    theme: theme
  }), /*#__PURE__*/React.createElement(BigStat, {
    label: "Expenses",
    value: fmtMoney(exp, {
      compact: true
    }),
    color: theme.t1,
    theme: theme
  }), /*#__PURE__*/React.createElement(BigStat, {
    label: "Net",
    value: fmtMoney(net, {
      compact: true
    }),
    color: net >= 0 ? theme.green : theme.red,
    theme: theme
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 8,
      padding: '12px 16px 0'
    }
  }, /*#__PURE__*/React.createElement(Pressable, {
    onClick: () => openSheet({
      kind: 'newBooking',
      propertyId: id
    })
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: theme.accent,
      color: 'white',
      padding: '12px 14px',
      borderRadius: 12,
      fontSize: 15,
      fontWeight: 600,
      textAlign: 'center',
      letterSpacing: -0.2
    }
  }, "+ Booking")), /*#__PURE__*/React.createElement(Pressable, {
    onClick: () => openSheet({
      kind: 'newTask',
      propertyId: id
    })
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: theme.fillTertiary,
      color: theme.t1,
      padding: '12px 14px',
      borderRadius: 12,
      fontSize: 15,
      fontWeight: 600,
      textAlign: 'center',
      letterSpacing: -0.2
    }
  }, "+ Task"))), propBookings.length > 0 && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 20px 8px',
      fontSize: 13,
      fontWeight: 500,
      color: theme.t2,
      textTransform: 'uppercase',
      letterSpacing: 0.4
    }
  }, "Bookings"), /*#__PURE__*/React.createElement(Card, {
    theme: theme
  }, propBookings.map((b, i) => /*#__PURE__*/React.createElement("div", {
    key: b.id,
    style: {
      padding: '12px 16px',
      borderBottom: i < propBookings.length - 1 ? `0.5px solid ${theme.sep}` : 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15,
      fontWeight: 500,
      color: theme.t1
    }
  }, b.guest), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      fontWeight: 600,
      color: theme.green
    }
  }, fmtMoney((b.rate || 0) * nights(b.check_in, b.check_out)))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: theme.t2,
      marginTop: 3
    }
  }, fmtDate(b.check_in), " \u2013 ", fmtDate(b.check_out), " \xB7 ", nights(b.check_in, b.check_out), " nights"), b.notes && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: theme.t3,
      marginTop: 4,
      fontStyle: 'italic'
    }
  }, b.notes))))), propTasks.length > 0 && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 20px 8px',
      fontSize: 13,
      fontWeight: 500,
      color: theme.t2,
      textTransform: 'uppercase',
      letterSpacing: 0.4
    }
  }, "Open Tasks"), /*#__PURE__*/React.createElement(Card, {
    theme: theme
  }, propTasks.map((t, i) => {
    const lab = dueLabel(t.due, theme);
    return /*#__PURE__*/React.createElement("div", {
      key: t.id,
      style: {
        padding: '12px 16px',
        borderBottom: i < propTasks.length - 1 ? `0.5px solid ${theme.sep}` : 'none',
        display: 'flex',
        alignItems: 'center',
        gap: 10
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 6,
        height: 6,
        borderRadius: 3,
        background: theme[PRIO_META[t.priority || 'med'].color]
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        fontSize: 14,
        color: theme.t1
      }
    }, t.text), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        color: lab.color,
        fontWeight: 600
      }
    }, lab.text));
  }))), propExp.length > 0 && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 20px 8px',
      fontSize: 13,
      fontWeight: 500,
      color: theme.t2,
      textTransform: 'uppercase',
      letterSpacing: 0.4
    }
  }, "Recent Expenses"), /*#__PURE__*/React.createElement(Card, {
    theme: theme
  }, propExp.slice(0, 4).map((e, i, arr) => /*#__PURE__*/React.createElement("div", {
    key: e.id,
    style: {
      padding: '12px 16px',
      borderBottom: i < arr.length - 1 ? `0.5px solid ${theme.sep}` : 'none',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      color: theme.t1
    }
  }, e.desc), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: theme.t2,
      marginTop: 2
    }
  }, (CAT_META[e.category] || CAT_META.other).l, " \xB7 ", fmtDate(e.date))), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      fontWeight: 600,
      color: theme.t1
    }
  }, "\u2212", fmtMoney(e.amount)))))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 16px 0'
    }
  }, /*#__PURE__*/React.createElement(Pressable, {
    onClick: () => {}
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: theme.fillTertiary,
      color: theme.red,
      padding: '14px',
      borderRadius: 12,
      fontSize: 15,
      fontWeight: 500,
      textAlign: 'center'
    }
  }, "Delete property"))));
}
function heroGrad(p, idx) {
  const colors = ['linear-gradient(135deg, #5B8DEE 0%, #355FCC 100%)', 'linear-gradient(135deg, #FFB05A 0%, #E8722C 100%)', 'linear-gradient(135deg, #6EBE8C 0%, #2F8C5F 100%)', 'linear-gradient(135deg, #B07CE8 0%, #7C4DCC 100%)', 'linear-gradient(135deg, #F08CB0 0%, #D85686 100%)'];
  return colors[idx % colors.length];
}
function BigStat({
  label,
  value,
  color,
  theme
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: theme.card,
      borderRadius: 12,
      padding: '12px 10px',
      textAlign: 'center',
      border: `0.5px solid ${theme.sepThin}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: theme.t2,
      textTransform: 'uppercase',
      letterSpacing: 0.4,
      marginBottom: 4
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 19,
      fontWeight: 700,
      color,
      letterSpacing: -0.4
    }
  }, value));
}

// ─────────────────────────────────────────────────────────────
// Form fields (iOS style)
// ─────────────────────────────────────────────────────────────
function Field({
  label,
  children,
  theme,
  last
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '11px 16px',
      borderBottom: last ? 'none' : `0.5px solid ${theme.sep}`,
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 15,
      color: theme.t1,
      minWidth: 100,
      fontWeight: 400
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      textAlign: 'right'
    }
  }, children));
}
function TextInput({
  value,
  onChange,
  placeholder,
  theme,
  type = 'text'
}) {
  return /*#__PURE__*/React.createElement("input", {
    type: type,
    value: value || '',
    onChange: e => onChange(e.target.value),
    placeholder: placeholder,
    style: {
      background: 'transparent',
      border: 'none',
      outline: 'none',
      fontSize: 15,
      color: theme.t1,
      textAlign: 'right',
      width: '100%',
      fontFamily: 'inherit',
      letterSpacing: -0.2
    }
  });
}
function Select({
  value,
  onChange,
  options,
  theme
}) {
  return /*#__PURE__*/React.createElement("select", {
    value: value || '',
    onChange: e => onChange(e.target.value),
    style: {
      background: 'transparent',
      border: 'none',
      outline: 'none',
      fontSize: 15,
      color: theme.t1,
      textAlign: 'right',
      fontFamily: 'inherit',
      appearance: 'none',
      WebkitAppearance: 'none',
      paddingRight: 14,
      backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='14' viewBox='0 0 10 14'><path d='M5 1l3 3M5 13l3-3' stroke='%23999' stroke-width='1.5' fill='none' stroke-linecap='round'/></svg>")`,
      backgroundRepeat: 'no-repeat',
      backgroundPosition: 'right center'
    }
  }, options.map(o => /*#__PURE__*/React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label)));
}

// ─────────────────────────────────────────────────────────────
// Add/Edit Property sheet
// ─────────────────────────────────────────────────────────────
function NewPropertySheet({
  data,
  theme,
  mutate,
  closeSheet
}) {
  const [name, setName] = useStateS('');
  const [addr, setAddr] = useStateS('');
  const [emoji, setEmoji] = useStateS('🏡');
  const [rev, setRev] = useStateS('');
  const [status, setStatus] = useStateS('vacant');
  const emojis = ['🏡', '🏠', '🏖️', '🏔️', '🌴', '🏙️', '🏘️', '⛰️', '🛖', '🌅', '🚐', '⛺'];
  const save = () => {
    if (!name) return;
    mutate.addProperty({
      name,
      addr,
      emoji,
      rev: Number(rev) || 0,
      status
    });
    closeSheet();
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '8px 0 24px'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    theme: theme
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Name",
    theme: theme
  }, /*#__PURE__*/React.createElement(TextInput, {
    value: name,
    onChange: setName,
    placeholder: "Lakeside Cabin",
    theme: theme
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Address",
    theme: theme
  }, /*#__PURE__*/React.createElement(TextInput, {
    value: addr,
    onChange: setAddr,
    placeholder: "123 Main St",
    theme: theme
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Status",
    theme: theme
  }, /*#__PURE__*/React.createElement(Select, {
    value: status,
    onChange: setStatus,
    theme: theme,
    options: [{
      value: 'vacant',
      label: 'Available'
    }, {
      value: 'booked',
      label: 'Booked'
    }, {
      value: 'maint',
      label: 'Maintenance'
    }, {
      value: 'prep',
      label: 'Preparing'
    }]
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Income / mo",
    theme: theme,
    last: true
  }, /*#__PURE__*/React.createElement(TextInput, {
    value: rev,
    onChange: setRev,
    placeholder: "2000",
    type: "number",
    theme: theme
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 20px 8px',
      fontSize: 13,
      fontWeight: 500,
      color: theme.t2,
      textTransform: 'uppercase',
      letterSpacing: 0.4
    }
  }, "Icon"), /*#__PURE__*/React.createElement(Card, {
    theme: theme
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 14,
      display: 'grid',
      gridTemplateColumns: 'repeat(6, 1fr)',
      gap: 8
    }
  }, emojis.map(e => /*#__PURE__*/React.createElement(Pressable, {
    key: e,
    onClick: () => setEmoji(e),
    scale: 0.85
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 24,
      padding: 6,
      borderRadius: 10,
      textAlign: 'center',
      background: emoji === e ? theme.accentSoft : 'transparent',
      border: emoji === e ? `1.5px solid ${theme.accent}` : '1.5px solid transparent'
    }
  }, e))))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 16px 0'
    }
  }, /*#__PURE__*/React.createElement(Pressable, {
    onClick: save
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: theme.accent,
      color: 'white',
      padding: '14px',
      borderRadius: 14,
      fontSize: 16,
      fontWeight: 600,
      textAlign: 'center',
      letterSpacing: -0.2
    }
  }, "Save Property"))));
}

// ─────────────────────────────────────────────────────────────
// New booking sheet
// ─────────────────────────────────────────────────────────────
function NewBookingSheet({
  propertyId,
  data,
  theme,
  mutate,
  closeSheet
}) {
  const [pid, setPid] = useStateS(propertyId || data.properties[0] && data.properties[0].id);
  const [guest, setGuest] = useStateS('');
  const [ci, setCi] = useStateS('');
  const [co, setCo] = useStateS('');
  const [rate, setRate] = useStateS('');
  const [notes, setNotes] = useStateS('');
  const save = () => {
    if (!guest || !ci || !co) return;
    mutate.addBooking({
      property_id: pid,
      guest,
      check_in: ci,
      check_out: co,
      rate: Number(rate) || 0,
      notes
    });
    closeSheet();
  };
  const total = ci && co && rate ? nights(ci, co) * Number(rate) : 0;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '8px 0 24px'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    theme: theme
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Property",
    theme: theme
  }, /*#__PURE__*/React.createElement(Select, {
    value: pid,
    onChange: setPid,
    theme: theme,
    options: data.properties.map(p => ({
      value: p.id,
      label: p.name
    }))
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Guest",
    theme: theme
  }, /*#__PURE__*/React.createElement(TextInput, {
    value: guest,
    onChange: setGuest,
    placeholder: "Smith Family",
    theme: theme
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Check-in",
    theme: theme
  }, /*#__PURE__*/React.createElement(TextInput, {
    value: ci,
    onChange: setCi,
    placeholder: "2026-05-10",
    type: "date",
    theme: theme
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Check-out",
    theme: theme
  }, /*#__PURE__*/React.createElement(TextInput, {
    value: co,
    onChange: setCo,
    placeholder: "2026-05-15",
    type: "date",
    theme: theme
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Rate / night",
    theme: theme
  }, /*#__PURE__*/React.createElement(TextInput, {
    value: rate,
    onChange: setRate,
    placeholder: "250",
    type: "number",
    theme: theme
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Notes",
    theme: theme,
    last: true
  }, /*#__PURE__*/React.createElement(TextInput, {
    value: notes,
    onChange: setNotes,
    placeholder: "Optional",
    theme: theme
  }))), total > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '14px 20px 0',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: theme.t2
    }
  }, nights(ci, co), " nights total"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 22,
      fontWeight: 700,
      color: theme.green,
      letterSpacing: -0.4
    }
  }, fmtMoney(total))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 16px 0'
    }
  }, /*#__PURE__*/React.createElement(Pressable, {
    onClick: save
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: theme.accent,
      color: 'white',
      padding: '14px',
      borderRadius: 14,
      fontSize: 16,
      fontWeight: 600,
      textAlign: 'center'
    }
  }, "Confirm Booking"))));
}

// ─────────────────────────────────────────────────────────────
// New task sheet
// ─────────────────────────────────────────────────────────────
function NewTaskSheet({
  propertyId,
  data,
  theme,
  mutate,
  closeSheet
}) {
  const [text, setText] = useStateS('');
  const [pid, setPid] = useStateS(propertyId || data.properties[0] && data.properties[0].id);
  const [priority, setPriority] = useStateS('med');
  const [due, setDue] = useStateS('today');
  const [assignees, setAssignees] = useStateS([]);
  const allAssignees = useMemoS(() => {
    const s = new Set(['Justin', 'Jay', 'Plumber', 'Cleaner', 'Electrician', 'Landscaper']);
    data.tasks.forEach(t => (t.assignees || []).forEach(a => s.add(a)));
    return Array.from(s);
  }, [data.tasks]);
  const save = () => {
    if (!text) return;
    mutate.addTask({
      text,
      property_id: pid,
      priority,
      due,
      assignees,
      done: false
    });
    closeSheet();
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '8px 0 24px'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    theme: theme
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '14px 16px'
    }
  }, /*#__PURE__*/React.createElement("textarea", {
    value: text,
    onChange: e => setText(e.target.value),
    placeholder: "What needs to be done?",
    style: {
      width: '100%',
      minHeight: 60,
      background: 'transparent',
      border: 'none',
      outline: 'none',
      resize: 'none',
      fontSize: 17,
      color: theme.t1,
      fontFamily: 'inherit',
      letterSpacing: -0.3,
      lineHeight: 1.4
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement(Card, {
    theme: theme
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Property",
    theme: theme
  }, /*#__PURE__*/React.createElement(Select, {
    value: pid,
    onChange: setPid,
    theme: theme,
    options: data.properties.map(p => ({
      value: p.id,
      label: p.name
    }))
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Priority",
    theme: theme
  }, /*#__PURE__*/React.createElement(Select, {
    value: priority,
    onChange: setPriority,
    theme: theme,
    options: Object.entries(PRIO_META).map(([k, v]) => ({
      value: k,
      label: v.label
    }))
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Due",
    theme: theme,
    last: true
  }, /*#__PURE__*/React.createElement(TextInput, {
    value: due,
    onChange: setDue,
    placeholder: "today, May 10...",
    theme: theme
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 20px 8px',
      fontSize: 13,
      fontWeight: 500,
      color: theme.t2,
      textTransform: 'uppercase',
      letterSpacing: 0.4
    }
  }, "Assign To"), /*#__PURE__*/React.createElement(Card, {
    theme: theme
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 12,
      display: 'flex',
      gap: 6,
      flexWrap: 'wrap'
    }
  }, allAssignees.map(a => {
    const on = assignees.includes(a);
    return /*#__PURE__*/React.createElement(Pressable, {
      key: a,
      scale: 0.92,
      onClick: () => {
        setAssignees(on ? assignees.filter(x => x !== a) : [...assignees, a]);
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '6px 12px',
        borderRadius: 20,
        fontSize: 13,
        fontWeight: 500,
        background: on ? theme.accent : theme.fillTertiary,
        color: on ? 'white' : theme.t1
      }
    }, a));
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 16px 0'
    }
  }, /*#__PURE__*/React.createElement(Pressable, {
    onClick: save
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: theme.accent,
      color: 'white',
      padding: '14px',
      borderRadius: 14,
      fontSize: 16,
      fontWeight: 600,
      textAlign: 'center'
    }
  }, "Add Task"))));
}

// ─────────────────────────────────────────────────────────────
// Task detail sheet
// ─────────────────────────────────────────────────────────────
function TaskDetailSheet({
  id,
  data,
  theme,
  mutate,
  closeSheet
}) {
  const t = data.tasks.find(x => x.id === id);
  if (!t) return null;
  const p = data.properties.find(x => x.id === t.property_id);
  const lab = dueLabel(t.due, theme);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '8px 0 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 20px 18px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement(PriorityDot, {
    priority: t.priority,
    theme: theme
  }), !t.done && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      color: lab.color,
      padding: '2px 8px',
      borderRadius: 12,
      background: lab.bg
    }
  }, lab.text)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 22,
      fontWeight: 600,
      color: theme.t1,
      lineHeight: 1.25,
      letterSpacing: -0.4
    }
  }, t.text), p && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      color: theme.t2,
      marginTop: 6
    }
  }, p.emoji, " ", p.name)), /*#__PURE__*/React.createElement(Card, {
    theme: theme
  }, /*#__PURE__*/React.createElement(Pressable, {
    onClick: () => mutate.toggleTask(id)
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '14px 16px',
      borderBottom: `0.5px solid ${theme.sep}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 26,
      height: 26,
      borderRadius: 13,
      border: `1.5px solid ${t.done ? theme.green : theme.t3}`,
      background: t.done ? theme.green : 'transparent',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, t.done && /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 14,
    color: "white"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 16,
      color: theme.t1
    }
  }, "Mark as ", t.done ? 'incomplete' : 'complete'))), t.assignees && t.assignees.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 16px',
      borderBottom: `0.5px solid ${theme.sep}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: theme.t2,
      marginBottom: 6
    }
  }, "Assigned to"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 6
    }
  }, t.assignees.map(a => /*#__PURE__*/React.createElement("div", {
    key: a,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      padding: '4px 10px',
      borderRadius: 16,
      background: theme.fillTertiary,
      fontSize: 13,
      color: theme.t1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 18,
      height: 18,
      borderRadius: 9,
      background: avatarColor(a),
      color: 'white',
      fontSize: 10,
      fontWeight: 700,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, initials(a)), a)))), t.notes && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 16px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: theme.t2,
      marginBottom: 4
    }
  }, "Notes"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      color: theme.t1,
      lineHeight: 1.45
    }
  }, t.notes))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 16px 0'
    }
  }, /*#__PURE__*/React.createElement(Pressable, {
    onClick: () => {
      mutate.deleteTask(id);
      closeSheet();
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: theme.fillTertiary,
      color: theme.red,
      padding: '14px',
      borderRadius: 14,
      fontSize: 15,
      fontWeight: 500,
      textAlign: 'center'
    }
  }, "Delete Task"))));
}

// ─────────────────────────────────────────────────────────────
// Guest detail sheet
// ─────────────────────────────────────────────────────────────
function GuestDetailSheet({
  name,
  data,
  theme
}) {
  const bks = data.bookings.filter(b => b.guest === name);
  const sts = (data.stays || []).filter(s => s.guest_name === name);
  const total = bks.reduce((s, b) => s + (b.rate || 0) * nights(b.check_in, b.check_out), 0) + sts.reduce((s, st) => s + Number(st.amount || 0), 0);
  const visits = bks.length + sts.length;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 0 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '8px 20px 20px',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 88,
      height: 88,
      borderRadius: 44,
      background: avatarColor(name),
      color: 'white',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 32,
      fontWeight: 600,
      margin: '0 auto 12px'
    }
  }, initials(name)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 24,
      fontWeight: 700,
      color: theme.t1,
      letterSpacing: -0.5
    }
  }, name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      color: theme.t2,
      marginTop: 4
    }
  }, visits, " visit", visits !== 1 ? 's' : '', " \xB7 ", fmtMoney(total), " lifetime")), bks.length > 0 && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '4px 20px 8px',
      fontSize: 13,
      fontWeight: 500,
      color: theme.t2,
      textTransform: 'uppercase',
      letterSpacing: 0.4
    }
  }, "Upcoming & Active"), /*#__PURE__*/React.createElement(Card, {
    theme: theme
  }, bks.map((b, i) => {
    const p = data.properties.find(x => x.id === b.property_id);
    return /*#__PURE__*/React.createElement("div", {
      key: b.id,
      style: {
        padding: '12px 16px',
        borderBottom: i < bks.length - 1 ? `0.5px solid ${theme.sep}` : 'none'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 15,
        color: theme.t1,
        fontWeight: 500
      }
    }, p?.name), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 14,
        color: theme.green,
        fontWeight: 600
      }
    }, fmtMoney((b.rate || 0) * nights(b.check_in, b.check_out)))), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: theme.t2,
        marginTop: 3
      }
    }, fmtDate(b.check_in), " \u2013 ", fmtDate(b.check_out), " \xB7 ", nights(b.check_in, b.check_out), " nights"));
  }))), sts.length > 0 && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 20px 8px',
      fontSize: 13,
      fontWeight: 500,
      color: theme.t2,
      textTransform: 'uppercase',
      letterSpacing: 0.4
    }
  }, "Past Stays"), /*#__PURE__*/React.createElement(Card, {
    theme: theme
  }, sts.map((s, i) => {
    const p = data.properties.find(x => x.id === s.property_id);
    return /*#__PURE__*/React.createElement("div", {
      key: s.id,
      style: {
        padding: '12px 16px',
        borderBottom: i < sts.length - 1 ? `0.5px solid ${theme.sep}` : 'none'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 15,
        color: theme.t1,
        fontWeight: 500
      }
    }, p?.name || 'Unknown property'), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 14,
        color: theme.t1,
        fontWeight: 600
      }
    }, fmtMoney(s.amount))), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: theme.t2,
        marginTop: 3
      }
    }, fmtDate(s.check_in), " \u2013 ", fmtDate(s.check_out)), s.note && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: theme.t3,
        marginTop: 4,
        fontStyle: 'italic'
      }
    }, s.note));
  }))));
}

// ─────────────────────────────────────────────────────────────
// New expense sheet
// ─────────────────────────────────────────────────────────────
function NewExpenseSheet({
  data,
  theme,
  mutate,
  closeSheet
}) {
  const [pid, setPid] = useStateS(data.properties[0] && data.properties[0].id);
  const [cat, setCat] = useStateS('cleaning');
  const [desc, setDesc] = useStateS('');
  const [amt, setAmt] = useStateS('');
  const [date, setDate] = useStateS('2026-05-07');
  const save = () => {
    if (!desc || !amt) return;
    mutate.addExpense({
      property_id: pid,
      category: cat,
      desc,
      amount: Number(amt),
      date
    });
    closeSheet();
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '8px 0 24px'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    theme: theme
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Property",
    theme: theme
  }, /*#__PURE__*/React.createElement(Select, {
    value: pid,
    onChange: setPid,
    theme: theme,
    options: data.properties.map(p => ({
      value: p.id,
      label: p.name
    }))
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Category",
    theme: theme
  }, /*#__PURE__*/React.createElement(Select, {
    value: cat,
    onChange: setCat,
    theme: theme,
    options: Object.entries(CAT_META).map(([k, v]) => ({
      value: k,
      label: v.l
    }))
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Description",
    theme: theme
  }, /*#__PURE__*/React.createElement(TextInput, {
    value: desc,
    onChange: setDesc,
    placeholder: "What was it for?",
    theme: theme
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Amount",
    theme: theme
  }, /*#__PURE__*/React.createElement(TextInput, {
    value: amt,
    onChange: setAmt,
    placeholder: "0",
    type: "number",
    theme: theme
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Date",
    theme: theme,
    last: true
  }, /*#__PURE__*/React.createElement(TextInput, {
    value: date,
    onChange: setDate,
    type: "date",
    theme: theme
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 16px 0'
    }
  }, /*#__PURE__*/React.createElement(Pressable, {
    onClick: save
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: theme.accent,
      color: 'white',
      padding: '14px',
      borderRadius: 14,
      fontSize: 16,
      fontWeight: 600,
      textAlign: 'center'
    }
  }, "Save Expense"))));
}
Object.assign(window, {
  PropertyDetailSheet,
  NewPropertySheet,
  NewBookingSheet,
  NewTaskSheet,
  TaskDetailSheet,
  GuestDetailSheet,
  NewExpenseSheet,
  Field,
  TextInput,
  Select,
  BigStat,
  heroGrad
});