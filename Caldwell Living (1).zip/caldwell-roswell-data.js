/* Caldwell Living — live data layer (Supabase + realtime, local fallback)
 *
 * Connects to window.CALDWELL_SUPA_URL / window.CALDWELL_SUPA_KEY (set in
 * the host HTML). Falls back to the baked-in Roswell sample if Supabase is
 * unreachable or a table is missing.
 *
 * Realtime: subscribes to all 5 tables. Any insert/update/delete from any
 * device pushes a refresh through window.__caldwellRefresh() (exposed by the
 * app shell), so other phones see the change within ~1 second.
 *
 * Tables expected:
 *   properties (id text pk, name, addr, emoji, rev numeric, status,
 *               next_renter, sort_order int)
 *   bookings   (id text pk, property_id text, guest, check_in date,
 *               check_out date, rate numeric, notes)
 *   tasks      (id text pk, text, property_id text, priority, due,
 *               done bool, notes, assignees text[], created_at timestamptz,
 *               completed_at timestamptz)
 *   expenses   (id text pk, property_id text, category, desc, amount numeric,
 *               date date)
 *   stays      (id text pk, guest_name, property_id text, check_in date,
 *               check_out date, amount numeric, note)
 *
 * Realtime must be enabled on each table. RLS: a permissive policy is fine
 * for the prototype; we'll lock it down once Phase 3 (login) lands.
 */
(function () {
  // ─── Local fallback data (also used as initial seed) ────────────────
  const ROSWELL = {
    properties: [
      { id: 'p1', name: 'The Magnolia House',     addr: '845 Mimosa Blvd, Roswell, GA 30075',  emoji: '🏛️', image_url: 'https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=600&h=400&fit=crop', rev: 5800, status: 'booked', next_renter: 'The Hartleys',   sort_order: 1 },
      { id: 'p2', name: 'Vickery Creek Cottage',  addr: '220 Sloan St, Roswell, GA 30075',     emoji: '🌿', image_url: 'https://images.unsplash.com/photo-1416331108676-a22ccb276e35?w=600&h=400&fit=crop', rev: 4100, status: 'prep',   next_renter: 'Smith Family',   sort_order: 2 },
      { id: 'p3', name: 'The Mill House',         addr: '95 Mill St, Roswell, GA 30075',       emoji: '🏚️', image_url: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=600&h=400&fit=crop', rev: 3650, status: 'maint',  next_renter: null,             sort_order: 3 },
      { id: 'p4', name: 'Canton Street Loft',     addr: '1085 Canton St, Roswell, GA 30075',   emoji: '🏙️', image_url: 'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=600&h=400&fit=crop', rev: 4400, status: 'booked', next_renter: 'Marcus Webb',    sort_order: 4 },
      { id: 'p5', name: 'Roswell Square Carriage',addr: '38 Norcross St, Roswell, GA 30075',   emoji: '🏡', image_url: 'https://images.unsplash.com/photo-1518780664697-55e3ad937233?w=600&h=400&fit=crop', rev: 3900, status: 'vacant', next_renter: null,             sort_order: 5 },
      { id: 'p6', name: 'The Parkside',           addr: '405 Atlanta St, Roswell, GA 30075',   emoji: '🌳', image_url: 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=600&h=400&fit=crop', rev: 4250, status: 'booked', next_renter: 'Patel Group',    sort_order: 6 },
      { id: 'p7', name: 'Old Roswell Estate',     addr: '12 Bulloch Ave, Roswell, GA 30075',   emoji: '🏰', image_url: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=600&h=400&fit=crop', rev: 7200, status: 'booked', next_renter: 'Chen Party',     sort_order: 7 },
      { id: 'p8', name: 'Chattahoochee View',     addr: '770 Riverside Rd, Roswell, GA 30075', emoji: '🌊', image_url: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=600&h=400&fit=crop', rev: 5300, status: 'prep',   next_renter: 'The Okonkwos',   sort_order: 8 },
      { id: 'p9', name: 'The Coleman',            addr: '175 Magnolia St, Roswell, GA 30075',  emoji: '🪴', image_url: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=600&h=400&fit=crop', rev: 3850, status: 'vacant', next_renter: null,             sort_order: 9 }
    ],
    bookings: [
      { id: 'b1', property_id: 'p1', guest: 'The Hartleys',   check_in: '2026-05-04', check_out: '2026-05-11', rate: 385, notes: 'Repeat guests — leave a bottle of wine' },
      { id: 'b2', property_id: 'p4', guest: 'Marcus Webb',    check_in: '2026-05-06', check_out: '2026-05-09', rate: 295, notes: 'Solo business traveler' },
      { id: 'b3', property_id: 'p7', guest: 'Chen Party',     check_in: '2026-05-08', check_out: '2026-05-12', rate: 520, notes: 'Family of 6, 2 dogs (paid pet fee)' },
      { id: 'b4', property_id: 'p6', guest: 'Patel Group',    check_in: '2026-05-09', check_out: '2026-05-15', rate: 310, notes: "Wedding weekend — bride's family" },
      { id: 'b5', property_id: 'p2', guest: 'Smith Family',   check_in: '2026-05-10', check_out: '2026-05-17', rate: 280, notes: 'Anniversary trip, early check-in 1pm' },
      { id: 'b6', property_id: 'p8', guest: 'The Okonkwos',   check_in: '2026-05-11', check_out: '2026-05-18', rate: 360, notes: 'Bringing parents — needs all 3 bedrooms' },
      { id: 'b7', property_id: 'p1', guest: 'Reyes Family',   check_in: '2026-05-15', check_out: '2026-05-19', rate: 390, notes: '' },
      { id: 'b8', property_id: 'p4', guest: 'Daniel Brooks',  check_in: '2026-05-14', check_out: '2026-05-17', rate: 295, notes: 'Late check-in 11pm' },
      { id: 'b9', property_id: 'p7', guest: 'The Whitlocks',  check_in: '2026-05-22', check_out: '2026-05-26', rate: 540, notes: 'Memorial Day weekend' },
      { id: 'b10', property_id: 'p5', guest: 'Hannah Lee',    check_in: '2026-05-18', check_out: '2026-05-22', rate: 265, notes: 'Atlanta wedding guest' },
      { id: 'b11', property_id: 'p9', guest: 'The Calhouns',  check_in: '2026-05-20', check_out: '2026-05-25', rate: 250, notes: '' },
      { id: 'b12', property_id: 'p6', guest: 'Jordan Ellis',  check_in: '2026-05-23', check_out: '2026-05-26', rate: 305, notes: '' },
      { id: 'b13', property_id: 'p2', guest: 'The Garzas',    check_in: '2026-05-22', check_out: '2026-05-29', rate: 290, notes: '' },
      { id: 'b14', property_id: 'p8', guest: 'Aiden Pollard', check_in: '2026-05-23', check_out: '2026-05-26', rate: 350, notes: '' }
    ],
    tasks: [
      { id: 't1',  text: "Restock coffee, soap & towels at Magnolia House before Hartleys' next guests", property_id: 'p1', priority: 'urgent', due: 'today',   done: false, notes: 'Hartleys check out May 11 → Reyes check in May 15, but supplies are low now.', assignees: ['Marrissa'], created_at: '2026-05-07T07:00:00Z' },
      { id: 't2',  text: 'Confirm Chen Party arrival time + dog fee receipt',                            property_id: 'p7', priority: 'urgent', due: 'today',   done: false, notes: "They're driving from Charlotte — text Mei Chen.", assignees: ['Jay'],      created_at: '2026-05-07T07:30:00Z' },
      { id: 't3',  text: 'Pick up new dishwasher rack — Mill House',                                     property_id: 'p3', priority: 'high',   due: 'today',   done: false, notes: "Lower rack model RPK-90; Lowe's on Holcomb Bridge has it.",       assignees: ['Jay'],      created_at: '2026-05-06T18:00:00Z' },
      { id: 't4',  text: 'Reply to 3-star review at Canton Street Loft',                                 property_id: 'p4', priority: 'high',   due: 'today',   done: false, notes: 'Guest mentioned WiFi was slow. Apologize, mention router upgrade.', assignees: ['Marrissa'], created_at: '2026-05-06T20:15:00Z' },
      { id: 't5',  text: 'Deep clean turnover — Magnolia House (Hartleys → Reyes)',                      property_id: 'p1', priority: 'high',   due: 'May 11',  done: false, notes: 'Lupita scheduled 11am Mon. Master bath grout — please scrub.',     assignees: ['Lupita'],   created_at: '2026-05-05T09:00:00Z' },
      { id: 't6',  text: 'Replace HVAC filter — Mill House',                                             property_id: 'p3', priority: 'high',   due: 'May 9',   done: false, notes: '20x25x1, MERV 11. Two filters — main return + bedroom return.',    assignees: ['Jay'],      created_at: '2026-05-05T11:00:00Z' },
      { id: 't7',  text: 'Patch + paint scuff on Vickery Creek hallway',                                 property_id: 'p2', priority: 'med',    due: 'May 9',   done: false, notes: 'Behr "Swiss Coffee" eggshell — qt left in basement.',              assignees: ['Jay'],      created_at: '2026-05-04T15:00:00Z' },
      { id: 't8',  text: 'Order linen restock for Roswell Square Carriage',                              property_id: 'p5', priority: 'med',    due: 'May 10',  done: false, notes: 'Down to 1 spare king set. Order 3 from Brooklinen.',                assignees: ['Marrissa'], created_at: '2026-05-04T10:00:00Z' },
      { id: 't9',  text: 'Quote new water heater — Old Roswell Estate',                                  property_id: 'p7', priority: 'med',    due: 'May 13',  done: false, notes: 'Anode rod is shot, ~12 yr old tank. Get 3 quotes.',                 assignees: ['Plumber'],  created_at: '2026-05-03T14:00:00Z' },
      { id: 't10', text: 'Renew City of Roswell short-term rental permits (all 9)',                      property_id: 'p1', priority: 'high',   due: 'May 14',  done: false, notes: 'Annual renewal — $250 ea. Submit online at roswellgov.com.',       assignees: ['Marrissa'], created_at: '2026-05-02T12:00:00Z' },
      { id: 't11', text: 'Mow lawn + trim hedges — Parkside',                                            property_id: 'p6', priority: 'low',    due: 'May 12',  done: false, notes: '',                                                                  assignees: ['Landscaper'], created_at: '2026-05-02T08:00:00Z' },
      { id: 't12', text: 'Pressure-wash deck — Chattahoochee View',                                      property_id: 'p8', priority: 'low',    due: 'May 17',  done: false, notes: 'Before Memorial Day weekend bookings.',                              assignees: ['Jay'],      created_at: '2026-05-01T10:00:00Z' },
      { id: 't13', text: 'Schedule pest control quarterly — all properties',                             property_id: 'p1', priority: 'low',    due: 'May 20',  done: false, notes: 'Northside Pest, Tony — same crew as last quarter.',                 assignees: ['Marrissa'], created_at: '2026-04-30T09:00:00Z' },
      { id: 't14', text: 'Pay May mortgages (all properties)',                                           property_id: 'p1', priority: 'urgent', due: 'today',   done: true,  notes: 'Auto-pay confirmed. $14,820 total.',                                  assignees: ['Jay'],      completed_at: '2026-05-07T08:30:00Z', created_at: '2026-05-01T08:00:00Z' },
      { id: 't15', text: 'Reorder welcome cards (250 ct)',                                               property_id: 'p1', priority: 'low',    due: 'May 5',   done: true,  notes: '',                                                                  assignees: ['Marrissa'], completed_at: '2026-05-05T16:00:00Z', created_at: '2026-04-25T10:00:00Z' }
    ],
    expenses: [
      { id: 'e1',  property_id: 'p1', category: 'mortgage',    desc: 'May mortgage',                amount: 2150, date: '2026-05-01' },
      { id: 'e2',  property_id: 'p2', category: 'mortgage',    desc: 'May mortgage',                amount: 1620, date: '2026-05-01' },
      { id: 'e3',  property_id: 'p3', category: 'mortgage',    desc: 'May mortgage',                amount: 1480, date: '2026-05-01' },
      { id: 'e4',  property_id: 'p4', category: 'mortgage',    desc: 'May mortgage',                amount: 1720, date: '2026-05-01' },
      { id: 'e5',  property_id: 'p5', category: 'mortgage',    desc: 'May mortgage',                amount: 1540, date: '2026-05-01' },
      { id: 'e6',  property_id: 'p6', category: 'mortgage',    desc: 'May mortgage',                amount: 1680, date: '2026-05-01' },
      { id: 'e7',  property_id: 'p7', category: 'mortgage',    desc: 'May mortgage',                amount: 2410, date: '2026-05-01' },
      { id: 'e8',  property_id: 'p8', category: 'mortgage',    desc: 'May mortgage',                amount: 1960, date: '2026-05-01' },
      { id: 'e9',  property_id: 'p9', category: 'mortgage',    desc: 'May mortgage',                amount: 1450, date: '2026-05-01' },
      { id: 'e10', property_id: 'p1', category: 'cleaning',    desc: 'Turnover clean (Hartleys)',   amount: 220,  date: '2026-05-04' },
      { id: 'e11', property_id: 'p4', category: 'supplies',    desc: 'Welcome basket + coffee',     amount: 64,   date: '2026-05-05' },
      { id: 'e12', property_id: 'p3', category: 'appliances',  desc: 'Dishwasher rack replacement', amount: 89,   date: '2026-05-06' },
      { id: 'e13', property_id: 'p7', category: 'plumbing',    desc: 'Master bath leak repair',     amount: 380,  date: '2026-04-28' },
      { id: 'e14', property_id: 'p3', category: 'hvac',        desc: 'AC tune-up + freon recharge', amount: 420,  date: '2026-04-26' },
      { id: 'e15', property_id: 'p8', category: 'landscaping', desc: 'Quarterly riverside trim',    amount: 285,  date: '2026-04-22' },
      { id: 'e16', property_id: 'p2', category: 'painting',    desc: 'Hallway touch-ups',           amount: 140,  date: '2026-04-20' },
      { id: 'e17', property_id: 'p6', category: 'electrical',  desc: 'GFCI outlet replacement (2)', amount: 165,  date: '2026-04-18' },
      { id: 'e18', property_id: 'p1', category: 'supplies',    desc: 'Linens + towels restock',     amount: 320,  date: '2026-04-15' },
      { id: 'e19', property_id: 'p5', category: 'pest',        desc: 'Quarterly pest control',      amount: 95,   date: '2026-04-12' },
      { id: 'e20', property_id: 'p9', category: 'cleaning',    desc: 'Deep clean (between guests)', amount: 240,  date: '2026-04-10' },
      { id: 'e21', property_id: 'p4', category: 'insurance',   desc: 'Quarterly STR insurance',     amount: 540,  date: '2026-04-05' },
      { id: 'e22', property_id: 'p7', category: 'roofing',     desc: 'Gutter cleaning',             amount: 175,  date: '2026-04-03' }
    ],
    stays: [
      { id: 's1',  guest_name: 'The Hartleys',   property_id: 'p1', check_in: '2025-09-12', check_out: '2025-09-19', amount: 2695, note: 'Repeat — anniversary' },
      { id: 's2',  guest_name: 'Smith Family',   property_id: 'p2', check_in: '2025-07-10', check_out: '2025-07-17', amount: 1960, note: 'Loved the porch' },
      { id: 's3',  guest_name: 'Chen Party',     property_id: 'p7', check_in: '2025-11-22', check_out: '2025-11-26', amount: 2080, note: 'Thanksgiving — booked again for May' },
      { id: 's4',  guest_name: 'Marcus Webb',    property_id: 'p4', check_in: '2025-10-08', check_out: '2025-10-11', amount: 885,  note: 'Business — quiet guest' },
      { id: 's5',  guest_name: 'The Okonkwos',   property_id: 'p8', check_in: '2025-08-15', check_out: '2025-08-22', amount: 2520, note: 'Family reunion' },
      { id: 's6',  guest_name: 'Reyes Family',   property_id: 'p1', check_in: '2024-12-20', check_out: '2024-12-27', amount: 2730, note: 'Christmas week' },
      { id: 's7',  guest_name: 'Patel Group',    property_id: 'p6', check_in: '2025-04-19', check_out: '2025-04-25', amount: 1860, note: 'Wedding party' },
      { id: 's8',  guest_name: 'Daniel Brooks',  property_id: 'p4', check_in: '2025-06-03', check_out: '2025-06-05', amount: 590,  note: '' },
      { id: 's9',  guest_name: 'The Calhouns',   property_id: 'p9', check_in: '2025-05-09', check_out: '2025-05-14', amount: 1250, note: '' },
      { id: 's10', guest_name: 'Hannah Lee',     property_id: 'p5', check_in: '2025-03-21', check_out: '2025-03-24', amount: 795,  note: 'Solo getaway' }
    ]
  };

  // ─── Supabase client ────────────────────────────────────────────────
  const URL = window.CALDWELL_SUPA_URL;
  const KEY = window.CALDWELL_SUPA_KEY;
  let client = null;
  try {
    if (URL && KEY && window.supabase) {
      client = window.supabase.createClient(URL, KEY, {
        realtime: { params: { eventsPerSecond: 10 } }
      });
      console.log('[Caldwell] Supabase client created →', URL);
    } else if (!window.supabase) {
      console.warn('[Caldwell] Supabase JS lib not loaded — running offline');
    }
  } catch (e) {
    console.warn('[Caldwell] Supabase init failed', e);
  }

  // ─── Per-table fetch with graceful fallback ─────────────────────────
  async function fetchTable(name, orderCol, ascending) {
    if (!client) return ROSWELL[name];
    try {
      const q = orderCol ? client.from(name).select('*').order(orderCol, { ascending: ascending !== false })
                         : client.from(name).select('*');
      const { data, error } = await q;
      if (error) throw error;
      if (!data || data.length === 0) {
        console.info('[Caldwell] ' + name + ' empty — using local sample');
        return ROSWELL[name];
      }
      return data;
    } catch (e) {
      console.warn('[Caldwell] ' + name + ' fetch failed → fallback', e.message || e);
      return ROSWELL[name];
    }
  }

  window.fetchAll = async function fetchAllCaldwell() {
    const [properties, bookings, tasks, expenses, stays] = await Promise.all([
      fetchTable('properties', 'sort_order', true),
      fetchTable('bookings', 'check_in', true),
      fetchTable('tasks', 'created_at', true),
      fetchTable('expenses', 'date', false),
      fetchTable('stays', 'check_in', false)
    ]);

    // ─── Demo-mode safety net ─────────────────────────────────────────
    // If Supabase doesn't have the 9 Roswell demo properties (p1–p9),
    // fall back to the local sample so Jay & Marrissa always see a full
    // populated app. Try to auto-seed once in the background; even if
    // seeding fails (RLS, missing columns, etc.), we still return ROSWELL.
    const haveAll9 = properties && ROSWELL.properties.every(rp =>
      properties.some(p => p.id === rp.id));

    if (!haveAll9) {
      if (client && !window.__caldwellSeeded) {
        window.__caldwellSeeded = true;
        console.log('[Caldwell] Supabase missing demo rows — attempting auto-seed…');
        window.CaldwellSeed({ silent: true })
          .then(() => console.log('[Caldwell] auto-seed complete — refresh to see live rows'))
          .catch(e => console.warn('[Caldwell] auto-seed failed (showing local demo data instead):', e.message || e));
      }
      console.info('[Caldwell] using local Roswell demo data (' + ROSWELL.properties.length + ' properties)');
      return {
        properties: ROSWELL.properties,
        bookings:   ROSWELL.bookings,
        tasks:      ROSWELL.tasks,
        expenses:   ROSWELL.expenses,
        stays:      ROSWELL.stays
      };
    }

    return { properties, bookings, tasks, expenses, stays };
  };

  // ─── Realtime — push updates from any device to all subscribers ─────
  if (client) {
    let pending = false;
    function nudge() {
      if (pending) return;
      pending = true;
      // Coalesce bursts (e.g. multi-row edits) into one refresh
      setTimeout(async () => {
        pending = false;
        if (typeof window.__caldwellRefresh === 'function') {
          try { await window.__caldwellRefresh(); }
          catch (e) { console.warn('[Caldwell] refresh failed', e); }
        }
      }, 250);
    }
    const tables = ['properties', 'bookings', 'tasks', 'expenses', 'stays'];
    const ch = client.channel('caldwell-live');
    tables.forEach(t => {
      ch.on('postgres_changes', { event: '*', schema: 'public', table: t }, payload => {
        console.log('[Caldwell] realtime ' + t, payload.eventType);
        nudge();
      });
    });
    ch.subscribe(status => {
      console.log('[Caldwell] realtime status:', status);
    });
  }

  // ─── Helper: seed (auto-runs from fetchAll if rows are missing) ─────
  window.CaldwellSeed = async function CaldwellSeed(opts) {
    opts = opts || {};
    if (!client) { console.error('No Supabase client'); return; }
    for (const table of ['properties', 'bookings', 'tasks', 'expenses', 'stays']) {
      const rows = ROSWELL[table];
      const { error } = await client.from(table).upsert(rows);
      if (error) console.error('seed ' + table + ':', error);
      else if (!opts.silent) console.log('seeded ' + rows.length + ' → ' + table);
    }
    if (!opts.silent && typeof window.__caldwellRefresh === 'function') await window.__caldwellRefresh();
  };
})();
