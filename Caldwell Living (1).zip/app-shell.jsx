// App shell — floating pill nav, theme switcher, sheet routing

const { useState: useStateA, useEffect: useEffectA, useMemo: useMemoA, useCallback: useCallbackA } = React;

function App() {
  // Theme
  const [themeMode, setThemeMode] = useStateA(() => {
    const saved = localStorage.getItem('cl-theme');
    if (saved) return saved;
    return 'auto';
  });
  const sysDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  const isDark = themeMode === 'dark' || (themeMode === 'auto' && sysDark);
  const theme = isDark ? palettes.dark : palettes.light;

  useEffectA(() => { localStorage.setItem('cl-theme', themeMode); }, [themeMode]);

  // Data
  const [data, setData] = useStateA({ properties: [], bookings: [], tasks: [], expenses: [], stays: [] });
  const [loading, setLoading] = useStateA(true);
  const [view, setView] = useStateA('properties');
  const [sheet, setSheet] = useStateA(null);
  const [statusBarTime] = useStateA('9:41');

  const refresh = useCallbackA(async () => {
    const d = await fetchAll();
    setData(d);
  }, []);

  useEffectA(() => {
    (async () => {
      await refresh();
      setLoading(false);
    })();
  }, []);

  // Mutations — optimistic local-only when no Supabase
  const mutate = useMemoA(() => ({
    toggleTask: (id) => {
      setData(d => ({
        ...d,
        tasks: d.tasks.map(t => t.id === id ? {
          ...t, done: !t.done,
          completed_at: !t.done ? new Date().toISOString() : null,
        } : t),
      }));
      if (supa) supa.from('tasks').update({ done: !data.tasks.find(t => t.id === id)?.done }).eq('id', id);
    },
    deleteTask: (id) => {
      setData(d => ({ ...d, tasks: d.tasks.filter(t => t.id !== id) }));
      if (supa) supa.from('tasks').delete().eq('id', id);
    },
    addTask: (t) => {
      const newT = { ...t, id: 't_' + Date.now(), created_at: new Date().toISOString() };
      setData(d => ({ ...d, tasks: [...d.tasks, newT] }));
      if (supa) supa.from('tasks').insert(newT);
    },
    addProperty: (p) => {
      const np = { ...p, id: 'p_' + Date.now(), sort_order: data.properties.length + 1 };
      setData(d => ({ ...d, properties: [...d.properties, np] }));
      if (supa) supa.from('properties').insert(np);
    },
    addBooking: (b) => {
      const nb = { ...b, id: 'b_' + Date.now() };
      setData(d => ({ ...d, bookings: [...d.bookings, nb] }));
      if (supa) supa.from('bookings').insert(nb);
    },
    deleteBooking: (id) => {
      setData(d => ({ ...d, bookings: d.bookings.filter(b => b.id !== id) }));
      if (supa) supa.from('bookings').delete().eq('id', id);
    },
    addExpense: (e) => {
      const ne = { ...e, id: 'e_' + Date.now() };
      setData(d => ({ ...d, expenses: [ne, ...d.expenses] }));
      if (supa) supa.from('expenses').insert(ne);
    },
  }), [data]);

  // Bg tinted by theme on scroll, but for now solid
  const containerBg = theme.bg;

  // Counts for nav badge
  const taskCount = data.tasks.filter(t => !t.done && parseDue(t.due) && parseDue(t.due).getTime() === TODAY.getTime()).length;

  // Status bar time advances based on real time (cosmetic)
  const t = (() => {
    const d = new Date();
    let h = d.getHours();
    const m = d.getMinutes();
    return `${h}:${String(m).padStart(2, '0')}`;
  })();

  return (
    <ThemeCtx.Provider value={theme}>
      <div style={{
        position: 'absolute', inset: 0, background: theme.bg,
        display: 'flex', flexDirection: 'column',
        fontFamily: '-apple-system, "SF Pro Text", "SF Pro", system-ui, sans-serif',
        WebkitFontSmoothing: 'antialiased',
        color: theme.t1, overflow: 'hidden',
      }}>
        {/* Status bar (fake but pixel-accurate) */}
        <FakeStatusBar dark={isDark} time={t} />

        {/* Top bar with theme toggle */}
        <TopBar theme={theme} themeMode={themeMode} setThemeMode={setThemeMode} setSheet={setSheet} view={view} />

        {/* Body */}
        {loading ? (
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 16 }}>
            <div style={{ fontSize: 32 }}>🏡</div>
            <div style={{ fontSize: 17, fontWeight: 600, color: theme.t1 }}>Caldwell Living</div>
            <div style={{
              width: 22, height: 22, borderRadius: 11,
              border: `2px solid ${theme.t3}`, borderTopColor: theme.accent,
              animation: 'spin 0.8s linear infinite',
            }} />
          </div>
        ) : (
          <PullToRefresh onRefresh={refresh} theme={theme}>
            {view === 'properties' && <PropertiesView data={data} setData={setData} theme={theme} openSheet={setSheet} mutate={mutate} />}
            {view === 'tasks' && <TasksView data={data} setData={setData} theme={theme} openSheet={setSheet} mutate={mutate} />}
            {view === 'calendar' && <CalendarView data={data} theme={theme} openSheet={setSheet} />}
            {view === 'finance' && <FinancesView data={data} theme={theme} openSheet={setSheet} />}
            {view === 'renters' && <RentersView data={data} theme={theme} openSheet={setSheet} />}
          </PullToRefresh>
        )}

        {/* Floating pill nav */}
        <FloatingNav view={view} setView={setView} theme={theme} taskCount={taskCount} setSheet={setSheet} isDark={isDark} />

        {/* Home indicator */}
        <div style={{
          position: 'absolute', bottom: 0, left: 0, right: 0,
          height: 34, display: 'flex', justifyContent: 'center', alignItems: 'flex-end',
          paddingBottom: 8, pointerEvents: 'none', zIndex: 200,
        }}>
          <div style={{
            width: 134, height: 5, borderRadius: 100,
            background: isDark ? 'rgba(255,255,255,0.55)' : 'rgba(0,0,0,0.3)',
          }} />
        </div>

        {/* Sheets */}
        <Sheet
          open={!!sheet}
          onClose={() => setSheet(null)}
          theme={theme}
          title={sheetTitle(sheet)}
        >
          {sheet?.kind === 'propertyDetail' && (
            <PropertyDetailSheet id={sheet.id} data={data} theme={theme} openSheet={setSheet} closeSheet={() => setSheet(null)} />
          )}
          {sheet?.kind === 'newProperty' && (
            <NewPropertySheet data={data} theme={theme} mutate={mutate} closeSheet={() => setSheet(null)} />
          )}
          {sheet?.kind === 'newBooking' && (
            <NewBookingSheet propertyId={sheet.propertyId} data={data} theme={theme} mutate={mutate} closeSheet={() => setSheet(null)} />
          )}
          {sheet?.kind === 'newTask' && (
            <NewTaskSheet propertyId={sheet.propertyId} data={data} theme={theme} mutate={mutate} closeSheet={() => setSheet(null)} />
          )}
          {sheet?.kind === 'taskDetail' && (
            <TaskDetailSheet id={sheet.id} data={data} theme={theme} mutate={mutate} closeSheet={() => setSheet(null)} />
          )}
          {sheet?.kind === 'guestDetail' && (
            <GuestDetailSheet name={sheet.name} data={data} theme={theme} />
          )}
          {sheet?.kind === 'newExpense' && (
            <NewExpenseSheet data={data} theme={theme} mutate={mutate} closeSheet={() => setSheet(null)} />
          )}
        </Sheet>
      </div>
    </ThemeCtx.Provider>
  );
}

function sheetTitle(s) {
  if (!s) return null;
  const m = {
    propertyDetail: 'Property',
    newProperty: 'New Property',
    newBooking: 'New Booking',
    newTask: 'New Task',
    taskDetail: 'Task',
    guestDetail: 'Guest',
    newExpense: 'New Expense',
  };
  return m[s.kind] || null;
}

// ─────────────────────────────────────────────────────────────
// Status bar
// ─────────────────────────────────────────────────────────────
function FakeStatusBar({ dark, time }) {
  const c = dark ? '#fff' : '#000';
  return (
    <div style={{
      flexShrink: 0, height: 47,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 24px', position: 'relative', zIndex: 30,
    }}>
      <span style={{
        fontFamily: '-apple-system, "SF Pro", system-ui',
        fontWeight: 600, fontSize: 16, color: c, letterSpacing: -0.2,
      }}>{time}</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <svg width="18" height="11" viewBox="0 0 18 11">
          <rect x="0" y="7" width="3" height="4" rx="0.5" fill={c}/>
          <rect x="4.5" y="5" width="3" height="6" rx="0.5" fill={c}/>
          <rect x="9" y="2.5" width="3" height="8.5" rx="0.5" fill={c}/>
          <rect x="13.5" y="0" width="3" height="11" rx="0.5" fill={c}/>
        </svg>
        <svg width="16" height="11" viewBox="0 0 16 11">
          <path d="M8 3C9.8 3 11.5 3.7 12.7 4.9L13.7 4C12.1 2.5 10.2 1.6 8 1.6S3.9 2.5 2.3 4L3.3 4.9C4.5 3.7 6.2 3 8 3Z" fill={c}/>
          <path d="M8 6C9 6 9.9 6.4 10.6 7L11.6 6C10.6 5 9.4 4.5 8 4.5S5.4 5 4.4 6L5.4 7C6.1 6.4 7 6 8 6Z" fill={c}/>
          <circle cx="8" cy="9.5" r="1.2" fill={c}/>
        </svg>
        <svg width="25" height="12" viewBox="0 0 25 12">
          <rect x="0.5" y="0.5" width="21" height="11" rx="3" stroke={c} strokeOpacity="0.4" fill="none"/>
          <rect x="2" y="2" width="18" height="8" rx="1.5" fill={c}/>
          <path d="M22.5 4v4c.7-.2 1.3-1 1.3-2s-.6-1.8-1.3-2z" fill={c} fillOpacity="0.4"/>
        </svg>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Top bar — theme toggle + add button
// ─────────────────────────────────────────────────────────────
function TopBar({ theme, themeMode, setThemeMode, setSheet, view }) {
  const cycle = () => {
    const order = ['auto', 'light', 'dark'];
    const i = order.indexOf(themeMode);
    setThemeMode(order[(i + 1) % order.length]);
  };
  const themeIcon = themeMode === 'dark' ? 'moon' : themeMode === 'light' ? 'sun' : 'settings';
  const isDark = palettes.dark === theme;

  return (
    <div style={{
      flexShrink: 0, padding: '6px 12px',
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      position: 'relative', zIndex: 25,
    }}>
      <Pressable onClick={cycle} scale={0.88}>
        <div style={{
          width: 38, height: 38, borderRadius: 19,
          background: theme.fillTertiary,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Icon name={themeIcon} size={18} color={theme.t1} />
        </div>
      </Pressable>
      <Pressable onClick={() => {
        const sheetMap = { properties: 'newProperty', tasks: 'newTask', calendar: 'newBooking', renters: 'newBooking', finance: 'newExpense' };
        setSheet({ kind: sheetMap[view] || 'newTask' });
      }} scale={0.88}>
        <div style={{
          width: 38, height: 38, borderRadius: 19,
          background: theme.fillTertiary,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Icon name="plus" size={20} color={theme.t1} />
        </div>
      </Pressable>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Floating pill nav
// ─────────────────────────────────────────────────────────────
function FloatingNav({ view, setView, theme, taskCount, setSheet, isDark }) {
  const tabs = [
    { id: 'properties', icon: 'house',    label: 'Homes' },
    { id: 'tasks',      icon: 'check',    label: 'Tasks', badge: taskCount },
    { id: 'calendar',   icon: 'calendar', label: 'Calendar' },
    { id: 'renters',    icon: 'people',   label: 'Guests' },
    { id: 'finance',    icon: 'dollar',   label: 'Money' },
  ];

  return (
    <div style={{
      position: 'absolute', bottom: 24, left: 0, right: 0,
      display: 'flex', justifyContent: 'center', zIndex: 150,
      pointerEvents: 'none',
    }}>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 2,
        padding: 6,
        borderRadius: 36,
        pointerEvents: 'auto',
        background: isDark ? 'rgba(40,40,42,0.78)' : 'rgba(255,255,255,0.78)',
        backdropFilter: 'blur(40px) saturate(180%)',
        WebkitBackdropFilter: 'blur(40px) saturate(180%)',
        border: isDark ? '0.5px solid rgba(255,255,255,0.1)' : '0.5px solid rgba(0,0,0,0.06)',
        boxShadow: isDark
          ? '0 8px 24px rgba(0,0,0,0.5), 0 2px 6px rgba(0,0,0,0.3)'
          : '0 10px 30px rgba(0,0,0,0.12), 0 2px 6px rgba(0,0,0,0.06)',
      }}>
        {tabs.map(tab => {
          const on = view === tab.id;
          return (
            <Pressable key={tab.id} onClick={() => setView(tab.id)} scale={0.88}>
              <div style={{
                position: 'relative',
                padding: on ? '8px 14px' : '8px',
                borderRadius: 30,
                display: 'flex', alignItems: 'center', gap: 6,
                background: on ? theme.accent : 'transparent',
                transition: 'all 280ms cubic-bezier(0.32, 0.72, 0, 1)',
              }}>
                <Icon name={tab.icon} size={20} color={on ? 'white' : theme.t2} />
                {on && (
                  <span style={{
                    fontSize: 13, fontWeight: 600, color: 'white',
                    letterSpacing: -0.2, whiteSpace: 'nowrap',
                  }}>{tab.label}</span>
                )}
                {tab.badge > 0 && !on && (
                  <span style={{
                    position: 'absolute', top: 2, right: 2,
                    minWidth: 16, height: 16, padding: '0 4px', borderRadius: 8,
                    background: theme.red, color: 'white',
                    fontSize: 10, fontWeight: 700,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    border: `1.5px solid ${isDark ? 'rgba(40,40,42,1)' : 'rgba(255,255,255,1)'}`,
                  }}>{tab.badge}</span>
                )}
              </div>
            </Pressable>
          );
        })}
      </div>
    </div>
  );
}

Object.assign(window, { App, FloatingNav, TopBar, FakeStatusBar });
