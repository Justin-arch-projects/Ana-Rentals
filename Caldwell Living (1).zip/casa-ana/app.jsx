// Mosa Casa — soft sidebar layout
const { useState, useEffect, useMemo } = React;

// ─── Sidebar ────────────────────────────────────────────────────
function Sidebar({ active, onPick }) {
  const { properties } = window.CASA_ANA_DATA;
  return (
    <aside style={{
      width: 280,
      background: "var(--bg2)",
      borderRight: "1px solid var(--line)",
      padding: "28px 18px",
      display: "flex",
      flexDirection: "column",
      gap: 24,
      flexShrink: 0,
      overflowY: "auto",
    }}>
      {/* Brand */}
      <div style={{ padding: "0 10px" }}>
        <div style={{
          fontFamily: "var(--sans)", fontWeight: 700,
          fontSize: 22, lineHeight: 1, color: "var(--primary)",
          letterSpacing: -0.4,
        }}>Mosa Casa</div>
        <div style={{
          fontSize: 11, color: "var(--t3)", marginTop: 6,
          letterSpacing: 0.2, fontWeight: 500,
        }}>Costa Rica · 4 rentals</div>
      </div>

      {/* Properties */}
      <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
        <div style={{
          fontSize: 11, fontWeight: 600, letterSpacing: 0.8,
          color: "var(--t3)", textTransform: "uppercase",
          padding: "6px 12px 10px",
        }}>Properties</div>
        {properties.map(p => {
          const isActive = active === p.id;
          return (
            <button
              key={p.id}
              onClick={() => onPick(p.id)}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 12,
                padding: "11px 12px",
                borderRadius: 12,
                background: isActive ? "var(--primary-tint)" : "transparent",
                color: isActive ? "var(--primary-deep)" : "var(--t1)",
                fontWeight: isActive ? 600 : 500,
                fontSize: 14,
                textAlign: "left",
                transition: "background 120ms",
              }}
              onMouseEnter={e => { if (!isActive) e.currentTarget.style.background = "var(--bg3)"; }}
              onMouseLeave={e => { if (!isActive) e.currentTarget.style.background = "transparent"; }}
            >
              <span style={{
                width: 10, height: 10, borderRadius: 50,
                background: `linear-gradient(135deg, oklch(0.72 0.10 ${p.hue}), oklch(0.52 0.12 ${p.hue}))`,
                flexShrink: 0,
              }}/>
              <span style={{ flex: 1 }}>{p.name}</span>
              {p.flag && <span style={{
                width: 6, height: 6, borderRadius: 50,
                background: "var(--danger)",
              }}/>}
            </button>
          );
        })}
      </div>

      {/* People */}
      <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
        <div style={{
          fontSize: 11, fontWeight: 600, letterSpacing: 0.8,
          color: "var(--t3)", textTransform: "uppercase",
          padding: "6px 12px 10px",
        }}>People</div>
        {window.CASA_ANA_DATA.contacts.map(c => {
          const key = `contact:${c.id}`;
          const isActive = active === key;
          const pending = c.questions.filter(q => !q.done).length;
          return (
            <button
              key={c.id}
              onClick={() => onPick(key)}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 12,
                padding: "11px 12px",
                borderRadius: 12,
                background: isActive ? "var(--primary-tint)" : "transparent",
                color: isActive ? "var(--primary-deep)" : "var(--t1)",
                fontWeight: isActive ? 600 : 500,
                fontSize: 14,
                textAlign: "left",
                transition: "background 120ms",
              }}
              onMouseEnter={e => { if (!isActive) e.currentTarget.style.background = "var(--bg3)"; }}
              onMouseLeave={e => { if (!isActive) e.currentTarget.style.background = "transparent"; }}
            >
              <span style={{
                width: 10, height: 10, borderRadius: 50,
                background: `linear-gradient(135deg, oklch(0.72 0.10 ${c.hue}), oklch(0.52 0.12 ${c.hue}))`,
                flexShrink: 0,
              }}/>
              <span style={{ flex: 1 }}>{c.role}</span>
              {pending > 0 && (
                <span style={{
                  fontSize: 11, fontWeight: 600,
                  color: isActive ? "var(--primary-deep)" : "var(--t3)",
                  background: isActive ? "var(--bg2)" : "var(--bg3)",
                  padding: "2px 8px", borderRadius: 999,
                }}>{pending}</span>
              )}
            </button>
          );
        })}
      </div>

      {/* Footer */}
      <div style={{ marginTop: "auto", padding: "16px 10px 4px", borderTop: "1px solid var(--line)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{
            width: 36, height: 36, borderRadius: 50,
            background: "linear-gradient(135deg, #D88656, #C7A769)",
            display: "flex", alignItems: "center", justifyContent: "center",
            color: "#fff", fontWeight: 700, fontSize: 14,
          }}>A</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: "var(--t1)" }}>Ana Augustine</div>
            <div style={{ fontSize: 11, color: "var(--t3)" }}>Owner</div>
          </div>
          <a href="sign-in.html" title="Sign in" style={{
            fontSize: 11, fontWeight: 600, color: "var(--t2)",
            border: "1px solid var(--line2)", borderRadius: 999,
            padding: "5px 10px", textDecoration: "none",
            background: "var(--bg2)",
          }}>Sign in</a>
        </div>
      </div>
    </aside>
  );
}

// ─── Property page (roomy) ──────────────────────────────────────
function PropertyPage({ p }) {
  const { tasks } = window.CASA_ANA_DATA;
  const [done, setDone] = useState({});
  const myTasks = tasks
    .filter(t => t.status === "open" && (t.prop === p.id || t.prop === "all"))
    .sort((a, b) => parseDate(a.due) - parseDate(b.due));

  const rentComps = p.comps.rent;
  const saleComps = p.comps.sale;
  const rentAvg = rentComps.reduce((s, c) => s + c.rent, 0) / rentComps.length;
  const rentDelta = p.rent - rentAvg;
  const rentDeltaPct = Math.round((rentDelta / rentAvg) * 100);

  const statusMap = {
    rented:    { tone: "var(--ok)",      bg: "var(--ok-soft)",     label: "Rented" },
    vacant:    { tone: "var(--warn)",    bg: "var(--warn-soft)",   label: "Vacant" },
    watch:     { tone: "var(--warn)",    bg: "var(--warn-soft)",   label: "Watch" },
    "for-sale":{ tone: "var(--accent)",  bg: "var(--accent-soft)", label: "For sale" },
  };
  const st = statusMap[p.status] || statusMap.rented;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 40 }}>
      {/* Hero */}
      <section>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
          <SoftPill color={st.tone} bg={st.bg}>{st.label}</SoftPill>
          <span style={{ fontSize: 12, color: "var(--t3)", fontWeight: 500 }}>
            Managed by {p.manager} · {p.llc}
          </span>
        </div>
        <h1 style={{
          fontSize: 48, fontWeight: 700, lineHeight: 1.05,
          letterSpacing: -1, margin: 0, color: "var(--t1)",
        }}>{p.name}</h1>
        {p.flag && (
          <div style={{
            marginTop: 18,
            padding: "14px 18px",
            background: "var(--danger-soft)",
            color: "var(--danger)",
            borderRadius: 14,
            fontSize: 13,
            fontWeight: 500,
            display: "inline-flex",
            alignItems: "center",
            gap: 8,
          }}>⚠ {p.flag}</div>
        )}
      </section>

      {/* Big stats — 3 friendly tiles */}
      <section style={{
        display: "grid",
        gridTemplateColumns: "repeat(3, 1fr)",
        gap: 16,
      }}>
        <StatTile label="Current rent" value={`$${p.rent.toLocaleString()}`} sub="per month" />
        <StatTile label="Monthly HOA"  value={`$${Math.round(p.hoaAvg).toLocaleString()}`} sub="due the 25th" />
        <StatTile label="Tenant since" value={p.tenantSince} sub={p.status === "watch" ? "watch this one" : "in good standing"} />
      </section>

      {/* To-do */}
      <section>
        <SectionHead title="To-do" sub={`${myTasks.length} open · sorted by due date`} />
        <div style={{
          background: "var(--bg2)",
          borderRadius: 20,
          boxShadow: "var(--shadow-sm)",
          border: "1px solid var(--line)",
          overflow: "hidden",
        }}>
          {myTasks.length === 0 ? (
            <div style={{ padding: "32px 24px", color: "var(--t3)", textAlign: "center", fontSize: 14 }}>
              Nothing pending. ✨
            </div>
          ) : myTasks.map((t, i) => {
            const d = dueLabel(t.due);
            const isLast = i === myTasks.length - 1;
            const isDone = done[t.id];
            return (
              <div key={t.id} style={{
                display: "grid",
                gridTemplateColumns: "auto 1fr auto",
                gap: 16,
                alignItems: "center",
                padding: "18px 22px",
                borderBottom: isLast ? "none" : "1px solid var(--line)",
                opacity: isDone ? 0.5 : 1,
                transition: "opacity 120ms",
              }}>
                <button
                  onClick={() => setDone({ ...done, [t.id]: !isDone })}
                  style={{
                    width: 22, height: 22, borderRadius: 7,
                    border: "1.5px solid " + (isDone ? "var(--primary)" : "var(--line2)"),
                    background: isDone ? "var(--primary)" : "transparent",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    flexShrink: 0,
                    transition: "all 120ms",
                  }}>
                  {isDone && <span style={{ color: "#fff", fontSize: 13, lineHeight: 1 }}>✓</span>}
                </button>
                <div>
                  <div style={{
                    fontSize: 14.5, fontWeight: 500, color: "var(--t1)",
                    textDecoration: isDone ? "line-through" : "none",
                  }}>{t.title}</div>
                  <div style={{ fontSize: 12, color: "var(--t3)", marginTop: 3, fontWeight: 500 }}>
                    {t.cat} · {t.assignee}
                  </div>
                </div>
                <span style={{
                  fontSize: 12, fontWeight: 600,
                  padding: "6px 12px",
                  borderRadius: 999,
                  background: d.kind === "danger" ? "var(--danger-soft)"
                          : d.kind === "warn" ? "var(--warn-soft)"
                          : "var(--bg3)",
                  color: d.kind === "danger" ? "var(--danger)"
                       : d.kind === "warn" ? "var(--warn)"
                       : "var(--t2)",
                  whiteSpace: "nowrap",
                }}>{d.txt}</span>
              </div>
            );
          })}
        </div>
      </section>

      {/* Rental comps */}
      <section>
        <SectionHead
          title="Rental comps"
          sub={`Avg $${Math.round(rentAvg).toLocaleString()} · you're ${rentDelta >= 0 ? "above" : "below"} market by $${Math.round(Math.abs(rentDelta)).toLocaleString()} (${rentDeltaPct > 0 ? "+" : ""}${rentDeltaPct}%)`}
        />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 16 }}>
          {rentComps.map((c, i) => {
            const cDelta = c.rent - p.rent;
            const cKind = cDelta > 0 ? "above" : cDelta < 0 ? "below" : "same";
            return <CompCard key={i} name={c.name} sub={`${c.beds} BR · ${c.note}`}
              price={`$${c.rent.toLocaleString()}`} priceSub="per month"
              delta={cDelta !== 0 ? `${cDelta > 0 ? "+" : ""}$${Math.abs(cDelta)}` : "same"}
              deltaKind={cKind} />;
          })}
        </div>
      </section>

      {/* For-sale comps */}
      <section>
        <SectionHead
          title="For-sale comps"
          sub={p.est ? `Your estimate: $${p.est.toLocaleString()}` : "Recent activity nearby"}
        />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 16 }}>
          {saleComps.map((c, i) => (
            <CompCard key={i} name={c.name} sub={`${c.beds} BR · ${c.note}`}
              price={`$${(c.price / 1000).toFixed(0)}k`}
              priceSub={`$${c.price.toLocaleString()}`} />
          ))}
        </div>
      </section>
    </div>
  );
}

// ─── Helper components ──────────────────────────────────────────
function SoftPill({ children, color, bg }) {
  return (
    <span style={{
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      padding: "5px 12px",
      fontSize: 12,
      fontWeight: 600,
      borderRadius: 999,
      background: bg,
      color: color,
    }}>
      <span style={{ width: 6, height: 6, borderRadius: 50, background: color }}/>
      {children}
    </span>
  );
}

function StatTile({ label, value, sub }) {
  return (
    <div style={{
      background: "var(--bg2)",
      borderRadius: 20,
      padding: "22px 24px",
      boxShadow: "var(--shadow-sm)",
      border: "1px solid var(--line)",
    }}>
      <div style={{
        fontSize: 12, fontWeight: 600, color: "var(--t3)",
        textTransform: "uppercase", letterSpacing: 0.6,
      }}>{label}</div>
      <div style={{
        fontSize: 34, fontWeight: 700, color: "var(--t1)",
        letterSpacing: -0.8, marginTop: 8, lineHeight: 1,
      }}>{value}</div>
      <div style={{ fontSize: 12.5, color: "var(--t2)", marginTop: 6, fontWeight: 500 }}>{sub}</div>
    </div>
  );
}

function SectionHead({ title, sub }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <h2 style={{
        fontSize: 22, fontWeight: 700, color: "var(--t1)",
        margin: 0, letterSpacing: -0.4,
      }}>{title}</h2>
      {sub && <div style={{ fontSize: 13, color: "var(--t2)", marginTop: 4, fontWeight: 500 }}>{sub}</div>}
    </div>
  );
}

function CompCard({ name, sub, price, priceSub, delta, deltaKind }) {
  const deltaColor = deltaKind === "above" ? "var(--danger)"
                   : deltaKind === "below" ? "var(--ok)"
                   : "var(--t3)";
  return (
    <div style={{
      background: "var(--bg2)",
      borderRadius: 20,
      padding: "22px 24px",
      boxShadow: "var(--shadow-sm)",
      border: "1px solid var(--line)",
      display: "flex",
      flexDirection: "column",
      gap: 14,
    }}>
      <div>
        <div style={{ fontSize: 16, fontWeight: 600, color: "var(--t1)", lineHeight: 1.2 }}>{name}</div>
        <div style={{ fontSize: 12.5, color: "var(--t2)", marginTop: 4, fontWeight: 500 }}>{sub}</div>
      </div>
      <div style={{
        display: "flex",
        alignItems: "baseline",
        justifyContent: "space-between",
        gap: 12,
        paddingTop: 14,
        borderTop: "1px solid var(--line)",
      }}>
        <div>
          <div style={{ fontSize: 26, fontWeight: 700, color: "var(--t1)", letterSpacing: -0.6, lineHeight: 1 }}>{price}</div>
          <div style={{ fontSize: 11.5, color: "var(--t3)", marginTop: 4, fontWeight: 500 }}>{priceSub}</div>
        </div>
        {delta && (
          <div style={{
            fontSize: 12.5, fontWeight: 600,
            padding: "6px 12px", borderRadius: 999,
            background: deltaKind === "above" ? "var(--danger-soft)"
                      : deltaKind === "below" ? "var(--ok-soft)"
                      : "var(--bg3)",
            color: deltaColor,
          }}>{delta}</div>
        )}
      </div>
    </div>
  );
}

// ─── App ────────────────────────────────────────────────────────
function App() {
  const { properties } = window.CASA_ANA_DATA;
  const [active, setActive] = useState(properties[0].id);

  const view = active.startsWith("contact:")
    ? <ContactsSection filterId={active.split(":")[1]} />
    : active === "contacts"
      ? <ContactsSection />
      : <PropertyPage p={properties.find(p => p.id === active)} />;

  return (
    <div style={{ display: "flex", height: "100vh", background: "var(--bg)" }}>
      <Sidebar active={active} onPick={setActive} />
      <main style={{
        flex: 1,
        overflowY: "auto",
        padding: "56px 64px 80px",
      }}>
        <div style={{ maxWidth: 880, margin: "0 auto" }}>
          {view}
        </div>
      </main>
    </div>
  );
}

// ─── Boot ───────────────────────────────────────────────────────
const splash = document.getElementById("splash");
ReactDOM.createRoot(document.getElementById("root")).render(<App />);
setTimeout(() => { if (splash) splash.style.display = "none"; }, 200);
