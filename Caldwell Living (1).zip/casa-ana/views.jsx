// Casa Ana — global views: Dashboard, Tasks, Bills, Rent, ForSale

// Helpers
function getPropFinance(prop) {
  const collected = prop.rentLedger.filter(v => v !== null).reduce((s,v)=>s+v,0);
  const expected = prop.rentLedger.filter(v => v !== null).length * prop.rent;
  const collectionRate = expected > 0 ? collected / expected : 1;
  const hoaPaid = prop.hoaLedger.filter(v => v !== null).reduce((s,v)=>s+v,0);
  return { collected, expected, collectionRate, hoaPaid, gap: expected - collected };
}

// ============================================================
// DASHBOARD
// ============================================================
function Dashboard({ ctx, onNav, onProp }) {
  const { properties, tasks, bills, months } = window.CASA_ANA_DATA;
  const cur = useCurrency(ctx.currency);

  // KPIs
  const portfolio = properties.reduce((acc, p) => {
    const f = getPropFinance(p);
    acc.collected += f.collected;
    acc.expected += f.expected;
    acc.hoaPaid += f.hoaPaid;
    return acc;
  }, { collected: 0, expected: 0, hoaPaid: 0 });

  const monthlyPotential = properties.reduce((s,p) => s + p.rent, 0);
  const openTasks = tasks.filter(t => !ctx.done.has(t.id) && t.status !== "done");
  const unpaidBills = bills.filter(b => !ctx.paid.has(b.id) && b.status !== "paid");
  const unpaidTotal = unpaidBills.reduce((s,b) => s + b.amt, 0);
  const collectionPct = Math.round((portfolio.collected / portfolio.expected) * 100);

  // Urgent items this week
  const urgent = [
    ...openTasks.map(t => ({ kind: "task", id: t.id, prop: t.prop, title: t.title, due: t.due, priority: t.priority })),
    ...unpaidBills.map(b => ({ kind: "bill", id: b.id, prop: b.prop, title: b.vendor, amt: b.amt, due: b.due, status: b.status })),
  ].sort((a,b) => parseDate(a.due) - parseDate(b.due)).slice(0, 8);

  return (
    <div>
      <PageHead
        kicker="Wednesday · May 20, 2026 · Roswell, GA"
        title="Buenos días, Ana."
        sub="Four condos, four S.A.s, two managers. Here's where things stand this week."
        right={
          <div style={{ textAlign: "right" }}>
            <div style={{ fontFamily: "var(--mono)", fontSize: 10, letterSpacing: 1.5, textTransform: "uppercase", color: "var(--t3)" }}>Last close</div>
            <div style={{ fontFamily: "var(--serif)", fontSize: 22, color: "var(--t1)", marginTop: 4 }}>
              Apr 25, 2026
            </div>
            <div style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--t2)", marginTop: 2 }}>balance sheet up to date</div>
          </div>
        }
      />

      <div style={{ padding: "24px 40px" }}>
        {/* KPIs */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 14, marginBottom: 24 }}>
          <Kpi label="Monthly rent roll" value={cur.fmt(monthlyPotential, { compact: true })} sub="If all 4 collect fully" sublabel="Potential" tone="primary" />
          <Kpi label="Collected — Oct→Apr" value={cur.fmt(portfolio.collected, { compact: true })} sub={`${cur.fmt(portfolio.expected - portfolio.collected)} short of full`} sublabel={`${collectionPct}%`} tone={collectionPct >= 95 ? "ok" : "warn"} />
          <Kpi label="Open tasks" value={openTasks.length} sub={`${openTasks.filter(t => t.priority === "high").length} high priority`} sublabel="Now" tone="accent" />
          <Kpi label="Unpaid bills" value={cur.fmt(unpaidTotal, { compact: true })} sub={`${unpaidBills.length} invoices`} sublabel="Due" tone="warn" />
        </div>

        {/* Property strip */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 14, marginBottom: 24 }}>
          {properties.map(p => (
            <PropertyCard key={p.id} prop={p} onClick={() => onProp(p.id)} ctx={ctx} />
          ))}
        </div>

        {/* Two columns */}
        <div style={{ display: "grid", gridTemplateColumns: "1.3fr 1fr", gap: 14 }}>
          <Card title="This week" action={<button onClick={() => onNav("tasks")} className="link">See all tasks →</button>}>
            <div style={{ display: "flex", flexDirection: "column" }}>
              {urgent.map((u, i) => {
                const prop = properties.find(p => p.id === u.prop) || { name: "All properties", hue: 60 };
                const due = dueLabel(u.due);
                return (
                  <div key={u.kind + u.id} style={{
                    display: "grid",
                    gridTemplateColumns: "16px 1fr auto auto",
                    alignItems: "center",
                    gap: 12,
                    padding: "12px 4px",
                    borderTop: i === 0 ? "none" : "0.5px solid var(--line)",
                    cursor: u.prop !== "all" ? "pointer" : "default",
                  }} onClick={() => u.prop !== "all" && onProp(u.prop)}>
                    <div style={{ width: 10, height: 10, borderRadius: 2,
                      background: u.kind === "task" ? "var(--primary)" : "var(--accent)" }} />
                    <div>
                      <div style={{ fontSize: 13, color: "var(--t1)" }}>{u.title}</div>
                      <div style={{ fontSize: 11, color: "var(--t2)", marginTop: 2 }}>
                        {prop.name}{u.kind === "bill" && <span> · {cur.fmt(u.amt)}</span>}
                      </div>
                    </div>
                    <Pill tone={due.kind === "danger" ? "danger" : due.kind === "warn" ? "warn" : "muted"} mono>{due.txt}</Pill>
                    {u.kind === "task"
                      ? <button onClick={(e) => { e.stopPropagation(); ctx.markTaskDone(u.id); }}
                          className="ghost-btn">Done</button>
                      : <button onClick={(e) => { e.stopPropagation(); ctx.markBillPaid(u.id); }}
                          className="ghost-btn">Pay</button>}
                  </div>
                );
              })}
              {urgent.length === 0 && (
                <div style={{ padding: 24, textAlign: "center", color: "var(--t3)", fontStyle: "italic", fontFamily: "var(--serif)", fontSize: 18 }}>
                  All caught up. Pour yourself a coffee.
                </div>
              )}
            </div>
          </Card>

          <Card title="Rent collection — 8 months">
            <RentChart ctx={ctx} />
          </Card>
        </div>

        {/* Rent ledger + watch */}
        <div style={{ display: "grid", gridTemplateColumns: ctx.showSale ? "1.3fr 1fr" : "1fr", gap: 14, marginTop: 14 }}>
          <Card title="Rent ledger — recent months" action={<button onClick={() => onNav("rent")} className="link">Full ledger →</button>}>
            <RentGrid compact />
          </Card>
          {ctx.showSale && (
            <Card title="Considering for sale — Antioco" action={<button onClick={() => onNav("forsale")} className="link">Open →</button>}>
              <AntiocoSnapshot onProp={onProp} />
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

function PropertyCard({ prop, onClick, ctx }) {
  const { tasks, bills } = window.CASA_ANA_DATA;
  const cur = useCurrency(ctx.currency);
  const open = tasks.filter(t => (t.prop === prop.id) && !ctx.done.has(t.id) && t.status !== "done").length;
  const unpaid = bills.filter(b => b.prop === prop.id && !ctx.paid.has(b.id) && b.status !== "paid").length;
  const fin = getPropFinance(prop);
  const collectionPct = Math.round(fin.collectionRate * 100);

  const statusPill = prop.status === "rented" ? <Pill tone="ok" mono>Rented</Pill>
                   : prop.status === "watch" ? <Pill tone="warn" mono>Watch</Pill>
                   : prop.status === "vacant" ? <Pill tone="danger" mono>Vacant</Pill>
                   : <Pill tone="muted" mono>—</Pill>;

  return (
    <div onClick={onClick} style={{
      background: "var(--bg2)",
      border: "0.5px solid var(--line)",
      borderRadius: "var(--r-lg)",
      overflow: "hidden",
      cursor: "pointer",
      transition: "transform .15s ease, border-color .15s ease",
    }}
    onMouseEnter={e => { e.currentTarget.style.borderColor = "var(--line2)"; e.currentTarget.style.transform = "translateY(-2px)"; }}
    onMouseLeave={e => { e.currentTarget.style.borderColor = "var(--line)"; e.currentTarget.style.transform = "none"; }}
    >
      <PropImg prop={prop} height={130} rounded={false} label={`${prop.name} — exterior`} />
      <div style={{ padding: 14 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 6 }}>
          <div>
            <div style={{ fontFamily: "var(--serif)", fontSize: 22, lineHeight: 1.1, color: "var(--t1)" }}>{prop.name}</div>
            <div style={{ fontFamily: "var(--mono)", fontSize: 10, letterSpacing: 1.4, textTransform: "uppercase", color: "var(--t2)", marginTop: 4 }}>
              {prop.llc}
            </div>
          </div>
          {statusPill}
        </div>
        <div style={{ display: "flex", gap: 10, marginTop: 10, fontSize: 11, color: "var(--t2)" }}>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 5 }}>
            <span style={{ width: 5, height: 5, borderRadius: 50, background: "var(--t3)" }}/> {prop.manager}
          </span>
          <span>·</span>
          <span><b style={{ color: "var(--t1)", fontFamily: "var(--serif)", fontSize: 13 }}>{cur.fmt(prop.rent)}</b>/mo</span>
        </div>
        <div style={{ display: "flex", gap: 14, marginTop: 12, fontSize: 11, color: "var(--t2)" }}>
          <span><b style={{ color: collectionPct >= 95 ? "var(--t1)" : "var(--warn)" }}>{collectionPct}%</b> coll.</span>
          <span><b style={{ color: open > 0 ? "var(--accent)" : "var(--t1)" }}>{open}</b> tasks</span>
          <span><b style={{ color: unpaid > 0 ? "var(--warn)" : "var(--t1)" }}>{unpaid}</b> bills</span>
        </div>
        {prop.flag && (
          <div style={{
            marginTop: 10, padding: "6px 8px",
            background: "var(--warn-soft)", border: "0.5px solid var(--warn)",
            borderRadius: 3, fontSize: 11, color: "var(--warn)",
          }}>{prop.flag}</div>
        )}
      </div>
    </div>
  );
}

function RentChart({ ctx }) {
  const { properties, months } = window.CASA_ANA_DATA;
  const cur = useCurrency(ctx.currency);
  // Bars per month: stacked rent collected
  const colors = { manfredonia: "var(--primary)", espada: "var(--accent)", montijo: "var(--gold)", antioco: "var(--ocean)" };
  const monthTotals = months.map((m, i) =>
    properties.reduce((s, p) => s + (p.rentLedger[i] || 0), 0)
  );
  const maxTotal = Math.max(...monthTotals.filter((_,i) => properties.some(p => p.rentLedger[i] !== null)), 1);
  const expectedPerMonth = properties.reduce((s,p)=>s+p.rent,0);
  return (
    <div>
      <div style={{ display: "flex", gap: 14, marginBottom: 10, flexWrap: "wrap" }}>
        {properties.map(p => (
          <div key={p.id} style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <div style={{ width: 8, height: 8, background: colors[p.id], borderRadius: 1 }}/>
            <span style={{ fontSize: 10, color: "var(--t2)" }}>{p.name}</span>
          </div>
        ))}
      </div>
      <div style={{ display: "flex", alignItems: "flex-end", gap: 6, height: 120, padding: "4px 0" }}>
        {months.map((m, i) => {
          const isFuture = properties.every(p => p.rentLedger[i] === null);
          return (
            <div key={m.iso} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
              <div style={{
                width: "100%", maxWidth: 28,
                height: 110, display: "flex", flexDirection: "column-reverse",
                borderTop: isFuture ? "1px dashed var(--line2)" : "none",
                opacity: isFuture ? 0.4 : 1,
              }}>
                {!isFuture && properties.map(p => {
                  const v = p.rentLedger[i] || 0;
                  const h = (v / expectedPerMonth) * 100;
                  return (
                    <div key={p.id} style={{
                      height: `${h}%`,
                      background: colors[p.id],
                      minHeight: v > 0 ? 1 : 0,
                    }} title={`${p.name} · ${m.label} · ${cur.fmt(v)}`}/>
                  );
                })}
              </div>
              <div style={{
                fontFamily: "var(--mono)", fontSize: 9, letterSpacing: 0.5,
                color: isFuture ? "var(--t3)" : "var(--t2)",
                fontStyle: isFuture ? "italic" : "normal",
              }}>{m.label}</div>
            </div>
          );
        })}
      </div>
      <div style={{ fontSize: 10, color: "var(--t3)", textAlign: "right", marginTop: 4, fontStyle: "italic" }}>
        Dashed = upcoming. Full bar = ${expectedPerMonth.toLocaleString()} potential.
      </div>
    </div>
  );
}

function RentGrid({ compact = false }) {
  const { properties, months } = window.CASA_ANA_DATA;
  const cur = useCurrency("USD");
  const visibleMonths = compact ? months.slice(-5) : months;
  return (
    <div style={{ overflowX: "auto" }}>
      <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
        <thead>
          <tr>
            <Th>Property</Th>
            {visibleMonths.map(m => <Th key={m.iso} align="right">{m.label}</Th>)}
          </tr>
        </thead>
        <tbody>
          {properties.map(p => (
            <tr key={p.id} style={{ borderTop: "0.5px solid var(--line)" }}>
              <Td>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <div style={{ width: 8, height: 18, borderRadius: 1, background: `oklch(0.55 0.10 ${p.hue})` }}/>
                  <span style={{ fontFamily: "var(--serif)", fontSize: 14 }}>{p.name}</span>
                </div>
              </Td>
              {visibleMonths.map((m, vi) => {
                const i = months.findIndex(x => x.iso === m.iso);
                const v = p.rentLedger[i];
                const short = v !== null && v < p.rent;
                const future = v === null;
                return (
                  <Td key={m.iso} align="right">
                    {future ? <span style={{ color: "var(--t3)", fontFamily: "var(--mono)", fontSize: 11 }}>—</span>
                            : v === 0 ? <span style={{ color: "var(--danger)", fontFamily: "var(--mono)", fontSize: 11 }}>vacant</span>
                            : <span style={{ fontFamily: "var(--serif)", fontSize: 14, color: short ? "var(--warn)" : "var(--t1)" }}>{cur.fmt(v)}</span>}
                    {short && v > 0 && (
                      <div style={{ fontFamily: "var(--mono)", fontSize: 9, color: "var(--warn)", letterSpacing: 0.5 }}>
                        −{cur.fmt(p.rent - v)}
                      </div>
                    )}
                  </Td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function AntiocoSnapshot({ onProp }) {
  const { properties } = window.CASA_ANA_DATA;
  const antioco = properties.find(p => p.id === "antioco");
  const fin = getPropFinance(antioco);
  const cur = useCurrency("USD");
  return (
    <div>
      <div style={{ fontFamily: "var(--serif)", fontSize: 16, fontStyle: "italic", color: "var(--t2)", marginBottom: 14 }}>
        "{antioco.forSale.notes}"
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 14 }}>
        <Stat label="Rent collected" value={cur.fmt(fin.collected, { compact: true })} />
        <Stat label="Shortfall" value={cur.fmt(fin.gap, { compact: true })} />
        <Stat label="Months at full rent" value={`${antioco.rentLedger.filter(v => v === antioco.rent).length} / 7`} />
        <Stat label="Vacant or short" value={`${antioco.rentLedger.filter(v => v !== null && v < antioco.rent).length} mo`} />
      </div>
      <button onClick={() => onProp("antioco")} className="primary-btn">
        Open Antioco <Icon name="arrow" size={14}/>
      </button>
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div style={{ background: "var(--bg3)", borderRadius: 4, padding: "10px 12px" }}>
      <div style={{ fontFamily: "var(--mono)", fontSize: 9, letterSpacing: 1, textTransform: "uppercase", color: "var(--t2)" }}>{label}</div>
      <div style={{ fontFamily: "var(--serif)", fontSize: 22, color: "var(--t1)", marginTop: 4 }}>{value}</div>
    </div>
  );
}

// ============================================================
// TASKS (global)
// ============================================================
function TasksView({ ctx, onProp }) {
  const { properties, tasks } = window.CASA_ANA_DATA;
  const cur = useCurrency(ctx.currency);
  const [propFilter, setPropFilter] = useState("all-filter");
  const [statusFilter, setStatusFilter] = useState("open");
  const [priorityFilter, setPriorityFilter] = useState("all");

  const filtered = tasks.filter(t => {
    if (propFilter !== "all-filter" && t.prop !== propFilter) return false;
    const done = ctx.done.has(t.id) || t.status === "done";
    if (statusFilter === "open" && done) return false;
    if (statusFilter === "done" && !done) return false;
    if (priorityFilter !== "all" && t.priority !== priorityFilter) return false;
    return true;
  }).sort((a,b) => parseDate(a.due) - parseDate(b.due));

  return (
    <div>
      <PageHead
        kicker={`${filtered.length} of ${tasks.length} tasks`}
        title="Tasks"
        sub="Rent collection, HOA, viáticos, the will, that bathroom leak — everything that needs doing."
        right={<button className="primary-btn"><Icon name="plus" size={14}/> New task</button>}
      />

      <div style={{ padding: "20px 40px", display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
        <FilterChip label="Property" value={propFilter} onChange={setPropFilter}
          options={[{ v: "all-filter", l: "All" }, { v: "all", l: "Cross-portfolio" }, ...properties.map(p => ({ v: p.id, l: p.name }))]} />
        <FilterChip label="Status" value={statusFilter} onChange={setStatusFilter}
          options={[{ v: "open", l: "Open" }, { v: "done", l: "Done" }, { v: "all", l: "All" }]} />
        <FilterChip label="Priority" value={priorityFilter} onChange={setPriorityFilter}
          options={[{ v: "all", l: "All" }, { v: "high", l: "High" }, { v: "med", l: "Medium" }, { v: "low", l: "Low" }]} />
      </div>

      <div style={{ padding: "0 40px 40px" }}>
        <Card padded={false}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ background: "var(--bg3)" }}>
                <Th>Done</Th><Th>Task</Th><Th>Property</Th><Th>Category</Th><Th>Due</Th><Th>Assignee</Th><Th align="right">Est.</Th><Th align="right">Priority</Th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(t => {
                const prop = properties.find(p => p.id === t.prop);
                const done = ctx.done.has(t.id) || t.status === "done";
                const due = dueLabel(t.due);
                return (
                  <tr key={t.id} style={{ borderTop: "0.5px solid var(--line)", opacity: done ? 0.5 : 1 }}>
                    <Td>
                      <button onClick={() => ctx.markTaskDone(t.id)} style={{
                        width: 18, height: 18, borderRadius: 4, border: "1px solid var(--line2)",
                        display: "flex", alignItems: "center", justifyContent: "center",
                        background: done ? "var(--primary)" : "transparent", color: "#fff",
                      }}>
                        {done && <Icon name="check" size={12} strokeWidth={2.5} />}
                      </button>
                    </Td>
                    <Td>
                      <div style={{ fontSize: 13, color: "var(--t1)", textDecoration: done ? "line-through" : "none" }}>{t.title}</div>
                      {t.note && <div style={{ fontSize: 11, color: "var(--t3)", marginTop: 2, fontStyle: "italic" }}>{t.note}</div>}
                    </Td>
                    <Td>
                      {prop ? (
                        <button onClick={() => onProp(prop.id)} style={{
                          display: "inline-flex", alignItems: "center", gap: 6, color: "var(--primary)", fontSize: 12,
                        }}>
                          <span style={{ width: 6, height: 6, borderRadius: 1, background: `oklch(0.55 0.10 ${prop.hue})` }}/>
                          {prop.name}
                        </button>
                      ) : (
                        <Pill tone="muted" mono>All 4</Pill>
                      )}
                    </Td>
                    <Td><span style={{ fontSize: 11, color: "var(--t2)" }}>{t.cat}</span></Td>
                    <Td><Pill tone={due.kind === "danger" ? "danger" : due.kind === "warn" ? "warn" : "muted"} mono>{due.txt}</Pill></Td>
                    <Td><span style={{ fontSize: 12, color: "var(--t2)" }}>{t.assignee}</span></Td>
                    <Td align="right"><span style={{ fontFamily: "var(--serif)", fontSize: 14 }}>{t.est ? cur.fmt(t.est) : "—"}</span></Td>
                    <Td align="right"><TaskStatusPill status={done ? "done" : "open"} priority={t.priority} /></Td>
                  </tr>
                );
              })}
              {filtered.length === 0 && (
                <tr><Td colSpan={8}><div style={{ padding: 24, textAlign: "center", color: "var(--t3)", fontStyle: "italic" }}>Nothing matches these filters.</div></Td></tr>
              )}
            </tbody>
          </table>
        </Card>
      </div>
    </div>
  );
}

// ============================================================
// BILLS (global)
// ============================================================
function BillsView({ ctx, onProp }) {
  const { properties, bills } = window.CASA_ANA_DATA;
  const cur = useCurrency(ctx.currency);
  const [propFilter, setPropFilter] = useState("all-filter");
  const [statusFilter, setStatusFilter] = useState("unpaid");
  const [catFilter, setCatFilter] = useState("all");

  const cats = [...new Set(bills.map(b => b.cat))];

  const filtered = bills.filter(b => {
    if (propFilter !== "all-filter" && b.prop !== propFilter) return false;
    const paid = ctx.paid.has(b.id) || b.status === "paid";
    if (statusFilter === "unpaid" && paid) return false;
    if (statusFilter === "paid" && !paid) return false;
    if (catFilter !== "all" && b.cat !== catFilter) return false;
    return true;
  }).sort((a,b) => parseDate(a.due) - parseDate(b.due));

  const totalUnpaid = bills
    .filter(b => !ctx.paid.has(b.id) && b.status !== "paid")
    .reduce((s, b) => s + b.amt, 0);
  const totalPaid = bills
    .filter(b => ctx.paid.has(b.id) || b.status === "paid")
    .reduce((s, b) => s + b.amt, 0);

  return (
    <div>
      <PageHead
        kicker={`${filtered.length} invoices · ${cur.fmt(totalUnpaid, { compact: true })} unpaid`}
        title="Bills"
        sub="HOA · municipality · digital signatures · viáticos · the occasional notario."
        right={<button className="primary-btn"><Icon name="plus" size={14}/> Record bill</button>}
      />

      <div style={{ padding: "20px 40px 0", display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14 }}>
        <Kpi label="Total unpaid" value={cur.fmt(totalUnpaid, { compact: true })} sub={`${bills.filter(b => !ctx.paid.has(b.id) && b.status !== "paid").length} bills`} sublabel="Open" />
        <Kpi label="Paid YTD" value={cur.fmt(totalPaid, { compact: true })} sub="Across all categories" sublabel="Settled" tone="ok" />
        <Kpi label="Avg monthly HOA" value={cur.fmt(properties.reduce((s,p)=>s+p.hoaAvg,0), { compact: true })} sub="All 4 condos" sublabel="HOA" tone="ocean" />
        <Kpi label="Next due" value={filtered[0] ? fmtDate(filtered[0].due) : "—"} sub={filtered[0] ? `${filtered[0].vendor} · ${cur.fmt(filtered[0].amt)}` : "—"} sublabel="Up next" tone="warn" />
      </div>

      <div style={{ padding: "20px 40px", display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
        <FilterChip label="Property" value={propFilter} onChange={setPropFilter}
          options={[{ v: "all-filter", l: "All" }, { v: "all", l: "Cross-portfolio" }, ...properties.map(p => ({ v: p.id, l: p.name }))]} />
        <FilterChip label="Status" value={statusFilter} onChange={setStatusFilter}
          options={[{ v: "unpaid", l: "Open" }, { v: "paid", l: "Paid" }, { v: "all", l: "All" }]} />
        <FilterChip label="Category" value={catFilter} onChange={setCatFilter}
          options={[{ v: "all", l: "All" }, ...cats.map(c => ({ v: c, l: c }))]} />
      </div>

      <div style={{ padding: "0 40px 40px" }}>
        <Card padded={false}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ background: "var(--bg3)" }}>
                <Th>Vendor</Th><Th>Property</Th><Th>Category</Th><Th>Due</Th><Th>Recurrence</Th><Th align="right">Amount</Th><Th align="right">Status</Th><Th align="right"></Th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(b => {
                const prop = properties.find(p => p.id === b.prop);
                const paid = ctx.paid.has(b.id) || b.status === "paid";
                const due = dueLabel(b.due);
                const isOver = b.status === "overdue" && !paid;
                return (
                  <tr key={b.id} style={{ borderTop: "0.5px solid var(--line)", opacity: paid ? 0.55 : 1 }}>
                    <Td><div style={{ fontSize: 13, color: "var(--t1)" }}>{b.vendor}</div></Td>
                    <Td>
                      {prop ? (
                        <button onClick={() => onProp(prop.id)} style={{
                          display: "inline-flex", alignItems: "center", gap: 6, color: "var(--primary)", fontSize: 12,
                        }}>
                          <span style={{ width: 6, height: 6, borderRadius: 1, background: `oklch(0.55 0.10 ${prop.hue})` }}/>
                          {prop.name}
                        </button>
                      ) : (
                        <Pill tone="muted" mono>All 4</Pill>
                      )}
                    </Td>
                    <Td><span style={{ fontSize: 11, color: "var(--t2)" }}>{b.cat}</span></Td>
                    <Td><Pill tone={isOver ? "danger" : due.kind === "warn" ? "warn" : "muted"} mono>{isOver ? due.txt : fmtDate(b.due)}</Pill></Td>
                    <Td><span style={{ fontSize: 11, color: "var(--t3)", fontFamily: "var(--mono)", letterSpacing: 1, textTransform: "uppercase" }}>{b.recurring}</span></Td>
                    <Td align="right">
                      <div style={{ fontFamily: "var(--serif)", fontSize: 18, color: "var(--t1)" }}>{cur.fmt(b.amt)}</div>
                      {ctx.currency === "USD" && <div style={{ fontFamily: "var(--mono)", fontSize: 9, color: "var(--t3)" }}>₡{Math.round(b.amt * 520).toLocaleString()}</div>}
                    </Td>
                    <Td align="right"><BillStatusPill status={paid ? "paid" : b.status === "overdue" ? "overdue" : "unpaid"} /></Td>
                    <Td align="right">
                      {!paid && <button onClick={() => ctx.markBillPaid(b.id)} className="ghost-btn">Mark paid</button>}
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </Card>
      </div>
    </div>
  );
}

// ============================================================
// RENT — monthly ledger view (replaces Bookings)
// ============================================================
function RentView({ ctx, onProp }) {
  const { properties, months } = window.CASA_ANA_DATA;
  const cur = useCurrency(ctx.currency);

  // Totals
  const monthTotals = months.map((m, i) => ({
    expected: properties.reduce((s,p) => p.rentLedger[i] !== null ? s + p.rent : s, 0),
    collected: properties.reduce((s,p) => s + (p.rentLedger[i] || 0), 0),
    future: properties.every(p => p.rentLedger[i] === null),
  }));
  const grandCollected = monthTotals.reduce((s,m) => s + m.collected, 0);
  const grandExpected = monthTotals.reduce((s,m) => s + m.expected, 0);

  return (
    <div>
      <PageHead
        kicker="Oct 2025 — May 2026"
        title="Rent ledger"
        sub="Eight months across four S.A.s. Where each peso went and where one slipped."
        right={
          <div style={{ display: "flex", gap: 8 }}>
            <button className="ghost-btn">Export CSV</button>
            <button className="primary-btn"><Icon name="plus" size={14}/> Log a payment</button>
          </div>
        }
      />

      <div style={{ padding: "24px 40px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14, marginBottom: 24 }}>
          <Kpi label="Collected" value={cur.fmt(grandCollected, { compact: true })} sub={`of ${cur.fmt(grandExpected, { compact: true })} expected`} sublabel="YTD" tone="primary" />
          <Kpi label="Shortfall" value={cur.fmt(grandExpected - grandCollected, { compact: true })} sub="All from Antioco" sublabel="Gap" tone="warn" />
          <Kpi label="Monthly potential" value={cur.fmt(properties.reduce((s,p)=>s+p.rent,0), { compact: true })} sub="If all 4 collect fully" sublabel="Roll" tone="ok" />
        </div>

        <Card padded={false}>
          <div style={{ padding: "14px 18px", display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "0.5px solid var(--line)" }}>
            <div style={{ fontFamily: "var(--serif)", fontSize: 20 }}>Monthly rent — by property</div>
            <div style={{ display: "flex", gap: 12, fontSize: 11, color: "var(--t2)" }}>
              <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}><span style={{width:10,height:10,background:"var(--ok-soft)",borderRadius:2,border:"0.5px solid var(--ok)"}}/> full</span>
              <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}><span style={{width:10,height:10,background:"var(--warn-soft)",borderRadius:2,border:"0.5px solid var(--warn)"}}/> partial</span>
              <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}><span style={{width:10,height:10,background:"var(--danger-soft)",borderRadius:2,border:"0.5px solid var(--danger)"}}/> vacant</span>
              <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}><span style={{width:10,height:10,background:"var(--bg3)",borderRadius:2,border:"0.5px dashed var(--line2)"}}/> upcoming</span>
            </div>
          </div>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ background: "var(--bg3)" }}>
                <Th>Property</Th>
                <Th>Manager</Th>
                <Th align="right">Rent</Th>
                {months.map(m => <Th key={m.iso} align="right">{m.label}</Th>)}
                <Th align="right">Total</Th>
              </tr>
            </thead>
            <tbody>
              {properties.map(p => {
                const fin = getPropFinance(p);
                return (
                  <tr key={p.id} style={{ borderTop: "0.5px solid var(--line)" }}>
                    <Td>
                      <button onClick={() => onProp(p.id)} style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <div style={{ width: 8, height: 22, borderRadius: 1, background: `oklch(0.55 0.10 ${p.hue})` }}/>
                        <div style={{ textAlign: "left" }}>
                          <div style={{ fontFamily: "var(--serif)", fontSize: 15, color: "var(--t1)" }}>{p.name}</div>
                          <div style={{ fontFamily: "var(--mono)", fontSize: 9, color: "var(--t3)", letterSpacing: 0.5, marginTop: 1 }}>{p.llc}</div>
                        </div>
                      </button>
                    </Td>
                    <Td><Pill tone={p.manager === "Piki" ? "primary" : "accent"} mono>{p.manager}</Pill></Td>
                    <Td align="right"><span style={{ fontFamily: "var(--serif)", fontSize: 14 }}>{cur.fmt(p.rent)}</span></Td>
                    {months.map((m, i) => {
                      const v = p.rentLedger[i];
                      const future = v === null;
                      const vacant = v === 0;
                      const partial = !future && !vacant && v < p.rent;
                      const tone = future ? null : vacant ? "danger" : partial ? "warn" : "ok";
                      return (
                        <Td key={m.iso} align="right">
                          {future ? <span style={{ color: "var(--t3)", fontFamily: "var(--mono)", fontSize: 11 }}>—</span>
                                  : <div style={{
                                      display: "inline-block",
                                      padding: "3px 8px",
                                      background: tone === "ok" ? "var(--ok-soft)" : tone === "warn" ? "var(--warn-soft)" : "var(--danger-soft)",
                                      borderRadius: 3,
                                      fontFamily: "var(--serif)", fontSize: 13,
                                      color: tone === "ok" ? "var(--ok)" : tone === "warn" ? "var(--warn)" : "var(--danger)",
                                    }}>{vacant ? "vacant" : cur.fmt(v)}</div>}
                        </Td>
                      );
                    })}
                    <Td align="right">
                      <div style={{ fontFamily: "var(--serif)", fontSize: 16, color: "var(--t1)" }}>{cur.fmt(fin.collected, { compact: true })}</div>
                      {fin.gap > 0 && <div style={{ fontFamily: "var(--mono)", fontSize: 9, color: "var(--warn)" }}>−{cur.fmt(fin.gap)}</div>}
                    </Td>
                  </tr>
                );
              })}
              {/* Totals row */}
              <tr style={{ borderTop: "1px solid var(--line2)", background: "var(--bg3)" }}>
                <Td><span style={{ fontFamily: "var(--mono)", fontSize: 10, letterSpacing: 1.5, textTransform: "uppercase", color: "var(--t2)" }}>Total</span></Td>
                <Td></Td>
                <Td align="right"><span style={{ fontFamily: "var(--serif)", fontSize: 14 }}>{cur.fmt(properties.reduce((s,p)=>s+p.rent,0))}</span></Td>
                {monthTotals.map((mt, i) => (
                  <Td key={i} align="right">
                    {mt.future ? <span style={{ color: "var(--t3)", fontFamily: "var(--mono)", fontSize: 11 }}>—</span>
                              : <div style={{ fontFamily: "var(--serif)", fontSize: 14, color: "var(--t1)" }}>{cur.fmt(mt.collected)}</div>}
                  </Td>
                ))}
                <Td align="right"><span style={{ fontFamily: "var(--serif)", fontSize: 18, color: "var(--primary)" }}>{cur.fmt(grandCollected, { compact: true })}</span></Td>
              </tr>
            </tbody>
          </table>
        </Card>

        {/* Chart */}
        <div style={{ marginTop: 14 }}>
          <Card title="Rent collected — by month">
            <RentChart ctx={ctx} />
          </Card>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// FOR SALE — Antioco being considered
// ============================================================
function ForSaleView({ ctx, onProp }) {
  const { properties } = window.CASA_ANA_DATA;
  const cur = useCurrency(ctx.currency);
  const candidates = properties.filter(p => p.forSale);

  return (
    <div>
      <PageHead
        kicker={`${candidates.length} considering listing`}
        title="For Sale"
        sub="Properties under review — and the rest of the portfolio, ready to go on the market when you are."
        right={<button className="primary-btn"><Icon name="plus" size={14}/> List a property</button>}
      />

      <div style={{ padding: "24px 40px" }}>
        {candidates.map(p => {
          const fs = p.forSale;
          const fin = getPropFinance(p);
          return (
            <div key={p.id} style={{ marginBottom: 24 }}>
              <div style={{ display: "grid", gridTemplateColumns: "320px 1fr", gap: 0, background: "var(--bg2)", border: "0.5px solid var(--line)", borderRadius: "var(--r-lg)", overflow: "hidden" }}>
                <PropImg prop={p} height={300} rounded={false} label={`${p.name} — hero shot`} />
                <div style={{ padding: "24px 24px 24px 28px", display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
                  <div>
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      {fs.considering
                        ? <Pill tone="warn" mono>Considering</Pill>
                        : <Pill tone="accent" mono>Listed {fs.listedOn}</Pill>}
                      <span style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--t2)", letterSpacing: 1, textTransform: "uppercase" }}>
                        {p.llc}
                      </span>
                    </div>
                    <div style={{ fontFamily: "var(--serif)", fontSize: 36, fontStyle: "italic", color: "var(--t1)", marginTop: 10, lineHeight: 1.05 }}>{p.name}</div>
                    <div style={{ fontSize: 13, color: "var(--t2)", marginTop: 4 }}>
                      Managed by {p.manager} · Tenant since {p.tenantSince}
                    </div>
                    {fs.notes && (
                      <div style={{ fontFamily: "var(--serif)", fontStyle: "italic", fontSize: 16, color: "var(--t2)", marginTop: 14, maxWidth: 480, borderLeft: "2px solid var(--accent)", paddingLeft: 12 }}>
                        "{fs.notes}"
                      </div>
                    )}
                  </div>
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginTop: 18 }}>
                    <Stat label="Monthly rent" value={cur.fmt(p.rent, { compact: true })} />
                    <Stat label="Collected (7mo)" value={cur.fmt(fin.collected, { compact: true })} />
                    <Stat label="Shortfall" value={cur.fmt(fin.gap, { compact: true })} />
                    <Stat label="List price" value={fs.list ? cur.fmt(fs.list, { compact: true }) : "—"} />
                  </div>
                  <div style={{ marginTop: 16, display: "flex", gap: 10 }}>
                    <button onClick={() => onProp(p.id)} className="primary-btn">
                      Open {p.name} <Icon name="arrow" size={14}/>
                    </button>
                    {fs.considering && <button className="ghost-btn">Get agent quote</button>}
                  </div>
                </div>
              </div>
            </div>
          );
        })}

        {/* Not listed */}
        <div>
          <Card title="Not on the market">
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14 }}>
              {properties.filter(p => !p.forSale).map(p => (
                <div key={p.id} style={{ padding: 14, background: "var(--bg3)", borderRadius: 6, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <div style={{ fontFamily: "var(--serif)", fontSize: 17 }}>{p.name}</div>
                    <div style={{ fontSize: 11, color: "var(--t2)", marginTop: 2 }}>{p.manager} · {cur.fmt(p.rent)}/mo</div>
                  </div>
                  <button className="ghost-btn">Consider</button>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// Helpers
// ============================================================
function Th({ children, align = "left" }) {
  return <th style={{
    textAlign: align, padding: "10px 14px",
    fontFamily: "var(--mono)", fontSize: 9, letterSpacing: 1.4,
    textTransform: "uppercase", color: "var(--t2)", fontWeight: 500,
  }}>{children}</th>;
}
function Td({ children, align = "left", colSpan }) {
  return <td colSpan={colSpan} style={{ textAlign: align, padding: "12px 14px", verticalAlign: "middle" }}>{children}</td>;
}

function FilterChip({ label, value, onChange, options }) {
  return (
    <label style={{
      display: "inline-flex", alignItems: "center", gap: 8,
      background: "var(--bg2)", border: "0.5px solid var(--line2)", borderRadius: 999,
      padding: "6px 4px 6px 14px",
    }}>
      <span style={{ fontFamily: "var(--mono)", fontSize: 9, letterSpacing: 1.4, textTransform: "uppercase", color: "var(--t2)" }}>{label}</span>
      <select value={value} onChange={e => onChange(e.target.value)} style={{
        background: "transparent", border: "none", outline: "none", fontSize: 12, color: "var(--t1)",
        padding: "2px 18px 2px 4px", appearance: "none", cursor: "pointer",
      }}>
        {options.map(o => <option key={o.v} value={o.v}>{o.l}</option>)}
      </select>
    </label>
  );
}

Object.assign(window, {
  Dashboard, TasksView, BillsView, RentView, ForSaleView,
  PropertyCard, Stat, Th, Td, FilterChip,
  getPropFinance, RentGrid, RentChart,
});
