// Casa Ana — shared UI parts
const { useState, useEffect, useRef, useMemo } = React;

// ---- Currency helper ----
function useCurrency(primary = "USD") {
  // ~520 colones per USD (rough)
  const FX = 520;
  return useMemo(() => ({
    fmt(usd, opts = {}) {
      const { compact = false, secondary = false } = opts;
      const n = Number(usd);
      if (primary === "USD") {
        const main = compact && Math.abs(n) >= 1000
          ? "$" + (n / 1000).toFixed(n >= 10000 ? 0 : 1) + "k"
          : "$" + n.toLocaleString("en-US", { maximumFractionDigits: n % 1 === 0 ? 0 : 2 });
        if (!secondary) return main;
        const crc = Math.round(n * FX);
        return { main, sub: "₡" + crc.toLocaleString("en-US") };
      } else {
        const crc = Math.round(n * FX);
        const main = compact && crc >= 1000000
          ? "₡" + (crc / 1000000).toFixed(1) + "M"
          : "₡" + crc.toLocaleString("en-US");
        if (!secondary) return main;
        return { main, sub: "$" + n.toLocaleString("en-US", { maximumFractionDigits: 0 }) };
      }
    },
  }), [primary]);
}

// ---- Date helpers ----
function parseDate(s) {
  const [y, m, d] = s.split("-").map(Number);
  return new Date(y, m - 1, d);
}
function fmtDate(s, opts = {}) {
  const dt = parseDate(s);
  const m = dt.toLocaleString("en-US", { month: "short" });
  return opts.long
    ? `${m} ${dt.getDate()}, ${dt.getFullYear()}`
    : `${m} ${dt.getDate()}`;
}
function daysFromNow(s) {
  const today = new Date(2026, 4, 20); // May 20, 2026 reference
  const dt = parseDate(s);
  return Math.round((dt - today) / 86400000);
}
function dueLabel(s) {
  const d = daysFromNow(s);
  if (d < 0) return { txt: `${Math.abs(d)}d overdue`, kind: "danger" };
  if (d === 0) return { txt: "Due today", kind: "warn" };
  if (d === 1) return { txt: "Tomorrow", kind: "warn" };
  if (d <= 3) return { txt: `In ${d}d`, kind: "warn" };
  if (d <= 7) return { txt: `In ${d}d`, kind: "muted" };
  return { txt: fmtDate(s), kind: "muted" };
}

// ---- Pill ----
function Pill({ children, tone = "muted", solid = false, mono = false }) {
  const toneMap = {
    ok:      { bg: "var(--ok-soft)",      fg: "var(--ok)",      bd: "var(--ok)" },
    warn:    { bg: "var(--warn-soft)",    fg: "var(--warn)",    bd: "var(--warn)" },
    danger:  { bg: "var(--danger-soft)",  fg: "var(--danger)",  bd: "var(--danger)" },
    primary: { bg: "var(--primary-soft)", fg: "var(--primary)", bd: "var(--primary)" },
    accent:  { bg: "var(--accent-soft)",  fg: "var(--accent)",  bd: "var(--accent)" },
    ocean:   { bg: "var(--ocean-soft)",   fg: "var(--ocean)",   bd: "var(--ocean)" },
    gold:    { bg: "var(--gold-soft)",    fg: "var(--gold)",    bd: "var(--gold)" },
    muted:   { bg: "var(--bg3)",          fg: "var(--t2)",      bd: "var(--line2)" },
  };
  const c = toneMap[tone] || toneMap.muted;
  return (
    <span style={{
      display: "inline-flex",
      alignItems: "center",
      gap: 4,
      padding: "2px 8px",
      fontSize: 10,
      fontFamily: mono ? "var(--mono)" : "var(--sans)",
      fontWeight: 500,
      letterSpacing: mono ? 1 : 0.3,
      textTransform: mono ? "uppercase" : "none",
      borderRadius: 999,
      background: solid ? c.fg : c.bg,
      color: solid ? "#fff" : c.fg,
      whiteSpace: "nowrap",
      lineHeight: 1.6,
    }}>{children}</span>
  );
}

// ---- Property image placeholder ----
// Striped placeholder tinted by hue. Lets user know "drop photo here" via the label.
function PropImg({ prop, label, height = 180, rounded = true }) {
  const h = prop.hue ?? 168;
  const id = `stripe-${prop.id}`;
  return (
    <div style={{
      position: "relative",
      width: "100%",
      height,
      borderRadius: rounded ? "var(--r-lg)" : 0,
      overflow: "hidden",
      background: `oklch(0.82 0.05 ${h})`,
      border: "0.5px solid var(--line)",
    }}>
      <svg width="100%" height="100%" style={{ position: "absolute", inset: 0, opacity: 0.45 }}>
        <defs>
          <pattern id={id} patternUnits="userSpaceOnUse" width="14" height="14" patternTransform="rotate(45)">
            <line x1="0" y1="0" x2="0" y2="14" stroke={`oklch(0.55 0.10 ${h})`} strokeWidth="1.5" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill={`url(#${id})`} />
      </svg>
      <div style={{
        position: "absolute",
        left: 10, bottom: 10,
        fontFamily: "var(--mono)",
        fontSize: 9,
        letterSpacing: 1.4,
        textTransform: "uppercase",
        color: `oklch(0.30 0.10 ${h})`,
        background: `oklch(0.95 0.03 ${h} / 0.6)`,
        padding: "3px 7px",
        borderRadius: 2,
      }}>{label || `${prop.name} — photo`}</div>
    </div>
  );
}

// ---- KPI card ----
function Kpi({ label, value, sub, sublabel, tone = "primary" }) {
  return (
    <div style={{
      background: "var(--bg2)",
      border: "0.5px solid var(--line)",
      borderRadius: "var(--r-lg)",
      padding: "18px 20px",
      display: "flex",
      flexDirection: "column",
      gap: 4,
    }}>
      <div style={{
        fontFamily: "var(--mono)",
        fontSize: 10,
        letterSpacing: 1.4,
        textTransform: "uppercase",
        color: "var(--t2)",
      }}>{label}</div>
      <div style={{
        fontFamily: "var(--serif)",
        fontSize: 38,
        lineHeight: 1,
        letterSpacing: -0.5,
        color: "var(--t1)",
        marginTop: 4,
      }}>{value}</div>
      {sub && (
        <div style={{
          fontSize: 12,
          color: "var(--t2)",
          marginTop: 6,
          display: "flex",
          alignItems: "center",
          gap: 6,
        }}>
          {sublabel && <span style={{ fontFamily: "var(--mono)", fontSize: 9, letterSpacing: 1, textTransform: "uppercase", color: `var(--${tone})` }}>{sublabel}</span>}
          <span>{sub}</span>
        </div>
      )}
    </div>
  );
}

// ---- Card chrome ----
function Card({ title, action, children, padded = true, style = {} }) {
  return (
    <div style={{
      background: "var(--bg2)",
      border: "0.5px solid var(--line)",
      borderRadius: "var(--r-lg)",
      overflow: "hidden",
      ...style,
    }}>
      {(title || action) && (
        <div style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "14px 18px",
          borderBottom: "0.5px solid var(--line)",
        }}>
          <div style={{ fontFamily: "var(--serif)", fontSize: 20, color: "var(--t1)" }}>{title}</div>
          {action}
        </div>
      )}
      <div style={{ padding: padded ? "14px 18px" : 0 }}>{children}</div>
    </div>
  );
}

// ---- Section header (large, editorial) ----
function PageHead({ kicker, title, sub, right }) {
  return (
    <div style={{
      display: "flex",
      alignItems: "flex-end",
      justifyContent: "space-between",
      padding: "28px 40px 20px",
      borderBottom: "0.5px solid var(--line)",
      gap: 24,
    }}>
      <div>
        {kicker && <div style={{
          fontFamily: "var(--mono)", fontSize: 10, letterSpacing: 2,
          textTransform: "uppercase", color: "var(--t2)", marginBottom: 6
        }}>{kicker}</div>}
        <div style={{
          fontFamily: "var(--serif)", fontSize: 42, lineHeight: 1.05,
          fontStyle: "italic", color: "var(--t1)", letterSpacing: -0.5
        }}>{title}</div>
        {sub && <div style={{ fontSize: 13, color: "var(--t2)", marginTop: 8, maxWidth: 560 }}>{sub}</div>}
      </div>
      {right && <div>{right}</div>}
    </div>
  );
}

// ---- Status pill for tasks ----
function TaskStatusPill({ status, priority }) {
  if (status === "done") return <Pill tone="ok" mono>Done</Pill>;
  if (priority === "high") return <Pill tone="danger" mono>High</Pill>;
  if (priority === "med")  return <Pill tone="warn" mono>Med</Pill>;
  return <Pill tone="muted" mono>Low</Pill>;
}

function BillStatusPill({ status }) {
  if (status === "paid")    return <Pill tone="ok" mono>Paid</Pill>;
  if (status === "overdue") return <Pill tone="danger" mono>Overdue</Pill>;
  return <Pill tone="warn" mono>Unpaid</Pill>;
}

// ---- Sparkline (income vs expense) ----
function Sparkline({ income, expense, width = 220, height = 56 }) {
  const max = Math.max(...income, ...expense);
  const stepX = width / (income.length - 1);
  const toY = v => height - (v / max) * (height - 4) - 2;
  const inPath = income.map((v, i) => `${i === 0 ? "M" : "L"}${i * stepX},${toY(v)}`).join(" ");
  const exPath = expense.map((v, i) => `${i === 0 ? "M" : "L"}${i * stepX},${toY(v)}`).join(" ");
  const inArea = `${inPath} L${width},${height} L0,${height} Z`;
  return (
    <svg width={width} height={height} style={{ display: "block" }}>
      <path d={inArea} fill="var(--primary-soft)" />
      <path d={inPath} stroke="var(--primary)" strokeWidth="1.5" fill="none" />
      <path d={exPath} stroke="var(--accent)" strokeWidth="1.2" fill="none" strokeDasharray="2,2" />
    </svg>
  );
}

// ---- Bookings strip (mini gantt for a property) ----
function BookingStrip({ bookings, days = 28, startISO = "2026-05-20" }) {
  const start = parseDate(startISO);
  const dayWidth = 100 / days;
  return (
    <div style={{ position: "relative", height: 32, background: "var(--bg3)", borderRadius: 4, overflow: "hidden" }}>
      {bookings.map(b => {
        const inDay = Math.max(0, (parseDate(b.checkin) - start) / 86400000);
        const outDay = Math.min(days, (parseDate(b.checkout) - start) / 86400000);
        if (outDay <= 0 || inDay >= days) return null;
        const left = inDay * dayWidth;
        const w = Math.max(0.8, (outDay - inDay) * dayWidth);
        const color = b.status === "in-house" ? "var(--accent)" : "var(--primary)";
        return (
          <div key={b.id} title={`${b.guest} · ${b.nights}n`} style={{
            position: "absolute",
            top: 4, bottom: 4,
            left: `${left}%`,
            width: `${w}%`,
            background: color,
            borderRadius: 3,
            display: "flex",
            alignItems: "center",
            padding: "0 6px",
            overflow: "hidden",
          }}>
            <span style={{ fontSize: 10, color: "#fff", whiteSpace: "nowrap", textOverflow: "ellipsis", overflow: "hidden" }}>
              {b.guest}
            </span>
          </div>
        );
      })}
    </div>
  );
}

// ---- Icon (minimal, line-only) ----
function Icon({ name, size = 16, strokeWidth = 1.5 }) {
  const common = {
    width: size, height: size, viewBox: "0 0 24 24",
    fill: "none", stroke: "currentColor", strokeWidth, strokeLinecap: "round", strokeLinejoin: "round",
  };
  const paths = {
    home:   <><path d="M3 11l9-7 9 7v9a1 1 0 01-1 1h-5v-7h-6v7H4a1 1 0 01-1-1z"/></>,
    check:  <><path d="M4 12l5 5L20 6"/></>,
    bill:   <><path d="M5 3h14v18l-3-2-2 2-2-2-2 2-2-2-3 2z"/><path d="M8 8h8"/><path d="M8 12h8"/><path d="M8 16h5"/></>,
    cal:    <><rect x="3" y="5" width="18" height="16" rx="1"/><path d="M3 9h18"/><path d="M8 3v4"/><path d="M16 3v4"/></>,
    tag:    <><path d="M3 12V4a1 1 0 011-1h8l9 9-9 9z"/><circle cx="7.5" cy="7.5" r="1"/></>,
    plus:   <><path d="M12 5v14"/><path d="M5 12h14"/></>,
    filter: <><path d="M3 5h18"/><path d="M6 12h12"/><path d="M10 19h4"/></>,
    chev:   <><path d="M9 6l6 6-6 6"/></>,
    chevD:  <><path d="M6 9l6 6 6-6"/></>,
    dot:    <><circle cx="12" cy="12" r="2"/></>,
    arrow:  <><path d="M5 12h14"/><path d="M13 5l7 7-7 7"/></>,
    pin:    <><path d="M12 21s-7-7.5-7-12a7 7 0 0114 0c0 4.5-7 12-7 12z"/><circle cx="12" cy="9" r="2.5"/></>,
    bed:    <><path d="M3 18V8"/><path d="M21 18v-5a3 3 0 00-3-3H3"/><path d="M3 18h18"/><circle cx="7.5" cy="11.5" r="1.5"/></>,
    bath:   <><path d="M4 11h16v3a4 4 0 01-4 4H8a4 4 0 01-4-4z"/><path d="M6 11V6a2 2 0 014 0"/><path d="M5 21l1-3"/><path d="M19 21l-1-3"/></>,
    user:   <><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-7 8-7s8 3 8 7"/></>,
    search: <><circle cx="11" cy="11" r="7"/><path d="M21 21l-4-4"/></>,
    sun:    <><circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="M4.93 4.93l1.41 1.41"/><path d="M17.66 17.66l1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="M4.93 19.07l1.41-1.41"/><path d="M17.66 6.34l1.41-1.41"/></>,
  };
  return <svg {...common}>{paths[name] || null}</svg>;
}

Object.assign(window, {
  useCurrency, parseDate, fmtDate, daysFromNow, dueLabel,
  Pill, PropImg, Kpi, Card, PageHead, TaskStatusPill, BillStatusPill, Sparkline, BookingStrip, Icon,
});
