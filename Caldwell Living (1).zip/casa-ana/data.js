// Casa Ana — real data from Ana Augustine's balance sheet (Apr 25, 2026)
// 4 condos in Costa Rica, each held in its own S.A. LLC.
// Managed by Piki (Manfredonia, Espada de Fuego) and Nena (Montijo, Antioco).
window.CASA_ANA_DATA = (() => {
  // Months as ISO first-of-month
  const MONTHS = [
    { iso: "2025-10-01", label: "Oct 25" },
    { iso: "2025-11-01", label: "Nov 25" },
    { iso: "2025-12-01", label: "Dec 25" },
    { iso: "2026-01-01", label: "Jan 26" },
    { iso: "2026-02-01", label: "Feb 26" },
    { iso: "2026-03-01", label: "Mar 26" },
    { iso: "2026-04-01", label: "Apr 26" },
    { iso: "2026-05-01", label: "May 26" }, // current month — expected, not yet collected
  ];

  const properties = [
    {
      id: "manfredonia",
      name: "Manfredonia",
      llc: "MF Manfredonia S.A",
      manager: "Piki",
      rent: 1500,
      hoaAvg: 460,
      status: "rented",  // rented | vacant | for-sale
      tenantSince: "2024",
      hue: 168, // palm green
      // Rent collected per MONTHS index (0..7). null = not yet due. 0 = vacant.
      rentLedger: [1500, 1500, 1500, 1500, 1500, 1500, 1500, null],
      hoaLedger:  [447,  445,  458,  450,  455,  473,  483,  null],
      comps: {
        rent: [
          { name: "Casa Bromelia",      rent: 1400, beds: 2, note: "2 blocks away · similar layout" },
          { name: "Villa Sol Naciente", rent: 1600, beds: 2, note: "Same complex · pool view" },
        ],
        sale: [
          { name: "Casa Bromelia",   price: 295000, beds: 2, note: "Listed 38 days · similar layout" },
          { name: "Mirador Unit 4B", price: 335000, beds: 2, note: "Sold last month · corner unit" },
        ],
      },
      est: 315000,
    },
    {
      id: "espada",
      name: "Espada de Fuego",
      llc: "Espada de Fuego S.A",
      manager: "Piki",
      rent: 1650,
      hoaAvg: 530,
      status: "rented",
      tenantSince: "2023",
      hue: 28, // terracotta
      rentLedger: [1650, 1650, 1650, 1650, 1650, 1650, 1650, null],
      hoaLedger:  [515,  516,  531,  521,  527,  548,  558,  null],
      comps: {
        rent: [
          { name: "Mirador del Río", rent: 1750, beds: 3, note: "Up the hill · partial view" },
          { name: "Casa Coral",      rent: 1500, beds: 2, note: "Across the road · smaller" },
        ],
        sale: [
          { name: "Vista del Río 12", price: 385000, beds: 3, note: "Listed 22 days · full view" },
          { name: "Casa Coral 2B",    price: 345000, beds: 3, note: "Sold Mar 26 · smaller lot" },
        ],
      },
      est: 365000,
    },
    {
      id: "montijo",
      name: "Montijo",
      llc: "MJ Montijo INT S.A",
      manager: "Nena",
      rent: 1450,
      hoaAvg: 530,
      status: "rented",
      tenantSince: "2024",
      hue: 92, // gold-green
      rentLedger: [1450, 1450, 1450, 1450, 1450, 1450, 1450, null],
      hoaLedger:  [515,  516,  531,  521,  527,  548,  558,  null],
      comps: {
        rent: [
          { name: "Quinta Esperanza", rent: 1350, beds: 2, note: "Same street · furnished" },
          { name: "Casa Verde",       rent: 1550, beds: 3, note: "3 doors down · larger lot" },
        ],
        sale: [
          { name: "Quinta Esperanza", price: 280000, beds: 2, note: "Listed 51 days · needs paint" },
          { name: "Casa Verde",       price: 310000, beds: 3, note: "Sold Feb 26 · larger" },
        ],
      },
      est: 295000,
    },
    {
      id: "antioco",
      name: "Antioco",
      llc: "Comercial IB Antioco",
      manager: "Nena",
      rent: 1500,
      hoaAvg: 458,
      status: "watch", // current tenant had partial Feb payment, vacant in Oct
      tenantSince: "2025",
      hue: 210, // ocean
      // Vacant in Oct 25, partial in Feb 26 ($1000), short in Jan ($1400)
      rentLedger: [0,    1500, 1500, 1400, 1000, 1500, 1500, null],
      hoaLedger:  [447,  445,  458,  450,  455,  473,  482.53, null],
      flag: "Partial Feb payment · keep an eye on it",
      comps: {
        rent: [
          { name: "Villa Brisa",       rent: 1450, beds: 2, note: "Same building · just leased" },
          { name: "Hacienda Pequeña", rent: 1600, beds: 3, note: "Two streets over · newer reno" },
        ],
        sale: [
          { name: "Villa Brisa 3C",     price: 290000, beds: 2, note: "Listed 14 days · same line" },
          { name: "Hacienda Pequeña",  price: 325000, beds: 3, note: "Sold Apr 26 · renovated" },
        ],
      },
      est: 305000,
      // For-sale draft
      forSale: {
        considering: true,
        list: null,        // not yet listed
        listedOn: null,
        agent: null,
        showings: 0,
        offers: 0,
        topOffer: null,
        notes: "Rent has been inconsistent. Worth a quote from agent.",
      },
    },
  ];

  // ─────────────────────────────────────────────────────────────
  // Tasks — from real notes + reasonable upcoming items
  // ─────────────────────────────────────────────────────────────
  const tasks = [
    // Done / from history
    { id: "t-tax",       prop: "all",         title: "Taxes on LLCs — yearly filing (4 S.A.s)", cat: "Admin / Tax", due: "2026-03-12", assignee: "Ana", status: "done", priority: "high", est: null, note: "Filed Mar 12 2026 for all four LLCs." },
    { id: "t-muni",      prop: "all",         title: "Municipality taxes — quarterly", cat: "Tax", due: "2026-01-22", assignee: "Ana", status: "done", priority: "high" },
    { id: "t-dsp",       prop: "all",         title: "Digital signature renewal — Piki", cat: "Admin", due: "2026-03-31", assignee: "Piki", status: "done", priority: "med" },
    { id: "t-dsn",       prop: "all",         title: "Digital signature renewal — Nena", cat: "Admin", due: "2026-04-04", assignee: "Nena", status: "done", priority: "med" },
    { id: "t-toilet",    prop: "manfredonia", title: "Toilet repair", cat: "Maintenance", due: "2026-02-14", assignee: "Piki", status: "done", priority: "high", est: 80 },
    { id: "t-bath",      prop: "espada",      title: "Bathroom leak repair", cat: "Maintenance", due: "2026-04-19", assignee: "Piki", status: "done", priority: "high", est: 140 },
    { id: "t-will",      prop: "all",         title: "Will — legal fees (Guillermo Salas)", cat: "Legal", due: "2026-04-21", assignee: "Piki", status: "done", priority: "med", est: 850 },

    // Open / upcoming — May 2026 forward
    { id: "t-rent-may",  prop: "all",         title: "Collect May rent (4 units)", cat: "Rent", due: "2026-05-01", assignee: "Piki & Nena", status: "open", priority: "high" },
    { id: "t-antioco-feb", prop: "antioco",   title: "Follow up on Feb partial payment ($500 short)", cat: "Rent", due: "2026-05-22", assignee: "Nena", status: "open", priority: "high" },
    { id: "t-antioco-decide", prop: "antioco", title: "Decide: keep renting or list for sale", cat: "For Sale", due: "2026-05-31", assignee: "Ana", status: "open", priority: "med" },
    { id: "t-hoa-may",   prop: "all",         title: "Pay May HOA — all 4 units", cat: "HOA", due: "2026-05-25", assignee: "Ana", status: "open", priority: "high" },
    { id: "t-muni-q2",   prop: "all",         title: "Municipality taxes — Q2 filing", cat: "Tax", due: "2026-06-22", assignee: "Ana", status: "open", priority: "med" },
    { id: "t-viatp",     prop: "all",         title: "Piki — viáticos May visit", cat: "Manager", due: "2026-05-25", assignee: "Piki", status: "open", priority: "low", est: 220 },
    { id: "t-viatn",     prop: "all",         title: "Nena — viáticos May visit", cat: "Manager", due: "2026-05-30", assignee: "Nena", status: "open", priority: "low", est: 200 },
    { id: "t-espada-paint", prop: "espada",   title: "Repaint living room (tenant request)", cat: "Maintenance", due: "2026-06-10", assignee: "Piki", status: "open", priority: "low", est: 320 },
    { id: "t-montijo-ac", prop: "montijo",    title: "AC service — pre-summer check", cat: "Maintenance", due: "2026-06-01", assignee: "Nena", status: "open", priority: "med", est: 180 },
    { id: "t-manfredonia-lease", prop: "manfredonia", title: "Lease renewal conversation (anniversary Jul)", cat: "Admin", due: "2026-06-15", assignee: "Piki", status: "open", priority: "med" },
  ];

  // ─────────────────────────────────────────────────────────────
  // Bills — HOA recurring + one-offs from the balance sheet
  // ─────────────────────────────────────────────────────────────
  const bills = [];

  // Monthly HOA bills (May 2026, upcoming)
  properties.forEach(p => {
    bills.push({
      id: `bhoa-${p.id}-may`,
      prop: p.id,
      vendor: "HOA Maintenance — May",
      cat: "HOA",
      amt: p.hoaAvg,
      due: "2026-05-25",
      status: "unpaid",
      recurring: "monthly",
    });
  });

  // Paid HOA history (Apr 2026)
  properties.forEach(p => {
    bills.push({
      id: `bhoa-${p.id}-apr`,
      prop: p.id,
      vendor: "HOA Maintenance — Apr",
      cat: "HOA",
      amt: p.hoaLedger[6],
      due: "2026-04-25",
      status: "paid",
      recurring: "monthly",
    });
  });

  // Other expenses (across properties — assigned to 'all' bucket but split)
  bills.push(
    { id: "b-bank",     prop: "all",         vendor: "Banco Nacional — bank fee", cat: "Banking", amt: 7.25, due: "2026-05-15", status: "unpaid", recurring: "monthly" },
    { id: "b-bank-apr", prop: "all",         vendor: "Banco Nacional — bank fee", cat: "Banking", amt: 7.25, due: "2026-04-15", status: "paid", recurring: "monthly" },
    { id: "b-piki-may", prop: "all",         vendor: "Piki — viáticos May",      cat: "Manager", amt: 220, due: "2026-05-25", status: "unpaid", recurring: "monthly" },
    { id: "b-nena-may", prop: "all",         vendor: "Nena — viáticos May",      cat: "Manager", amt: 200, due: "2026-05-30", status: "unpaid", recurring: "monthly" },
    { id: "b-piki-apr", prop: "all",         vendor: "Piki — viáticos Apr 14",   cat: "Manager", amt: 220, due: "2026-04-14", status: "paid", recurring: "monthly" },
    { id: "b-will",     prop: "all",         vendor: "Guillermo Salas — Will (legal)", cat: "Legal", amt: 850, due: "2026-04-21", status: "paid", recurring: "one-off" },
    { id: "b-bath",     prop: "espada",      vendor: "Bathroom leak repair",      cat: "Maintenance", amt: 140, due: "2026-04-19", status: "paid", recurring: "one-off" },
    { id: "b-toilet",   prop: "manfredonia", vendor: "Toilet repair",             cat: "Maintenance", amt: 80, due: "2026-02-14", status: "paid", recurring: "one-off" },
    { id: "b-tax",      prop: "all",         vendor: "Taxes on LLCs (4 S.A.s)",   cat: "Tax", amt: 1240, due: "2026-03-12", status: "paid", recurring: "yearly" },
    { id: "b-muni",     prop: "all",         vendor: "Municipality taxes — Q1",   cat: "Tax", amt: 420, due: "2026-01-22", status: "paid", recurring: "quarterly" },
    { id: "b-dsp",      prop: "all",         vendor: "Digital signature — Piki",  cat: "Admin", amt: 95, due: "2026-03-31", status: "paid", recurring: "yearly" },
    { id: "b-dsn",      prop: "all",         vendor: "Digital signature — Nena",  cat: "Admin", amt: 95, due: "2026-04-04", status: "paid", recurring: "yearly" },
    { id: "b-muni-q2",  prop: "all",         vendor: "Municipality taxes — Q2",   cat: "Tax", amt: 420, due: "2026-06-22", status: "unpaid", recurring: "quarterly" },
  );

  // For-sale activity — only Antioco being considered (no real activity yet)
  const saleActivity = [
    // empty — Antioco is in "considering" status
  ];

  // ─────────────────────────────────────────────────────────────
  // Contacts — grouped by role, each with a list of open questions
  // ─────────────────────────────────────────────────────────────
  const contacts = [
    {
      id: "lawyer",
      role: "Lawyer",
      name: "Guillermo Salas",
      firm: "Salas & Asociados",
      phone: "+506 2222 1188",
      email: "g.salas@salaslaw.cr",
      hue: 28,
      questions: [
        { id: "ql-1", text: "Confirm the Will is filed and where the original copy is stored.", priority: "high" },
        { id: "ql-2", text: "Do I need to update LLC officers after Piki's signature renewal?", priority: "med" },
        { id: "ql-3", text: "What is the eviction timeline if Antioco tenant misses another month?", priority: "med" },
        { id: "ql-4", text: "Estimate fees to add Justin as co-signer on the S.A.s.", priority: "low" },
      ],
    },
    {
      id: "accountant",
      role: "Accountant",
      name: "Marisol Rojas",
      firm: "Rojas Contabilidad",
      phone: "+506 2233 4477",
      email: "marisol@rojascontab.cr",
      hue: 168,
      questions: [
        { id: "qa-1", text: "Have all 4 S.A. tax filings been accepted by Tributación?", priority: "high" },
        { id: "qa-2", text: "Q2 municipality tax — confirm exact amount per property before Jun 22.", priority: "high" },
        { id: "qa-3", text: "Best way to record the $500 short Feb rent for Antioco?", priority: "med" },
        { id: "qa-4", text: "Year-end planning call — schedule for July.", priority: "low" },
      ],
    },
    {
      id: "agent",
      role: "Real Estate Agent",
      name: "Daniela Quesada",
      firm: "Costa Realty Group",
      phone: "+506 8844 7200",
      email: "daniela@costarealty.cr",
      hue: 92,
      questions: [
        { id: "qr-1", text: "What would Antioco list for today, as-is?", priority: "high" },
        { id: "qr-2", text: "Repairs / staging needed before listing? Rough budget?", priority: "high" },
        { id: "qr-3", text: "What's the current cap rate for similar 2BR units in the area?", priority: "med" },
        { id: "qr-4", text: "How long are similar units sitting on market right now?", priority: "low" },
      ],
    },
    {
      id: "managers",
      role: "Property Managers",
      name: "Piki & Nena",
      firm: "On the ground",
      phone: "—",
      email: "via WhatsApp",
      hue: 210,
      questions: [
        { id: "qm-1", text: "Piki — exact status of Espada paint job, timeline.", priority: "med" },
        { id: "qm-2", text: "Nena — get written statement from Antioco tenant about Feb shortfall.", priority: "high" },
        { id: "qm-3", text: "Nena — schedule Montijo AC service for pre-summer.", priority: "med" },
        { id: "qm-4", text: "Piki — Manfredonia lease anniversary in July, start conversation.", priority: "low" },
      ],
    },
  ];

  return { properties, tasks, bills, months: MONTHS, saleActivity, contacts };
})();
