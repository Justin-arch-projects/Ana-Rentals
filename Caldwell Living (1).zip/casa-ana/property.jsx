// Casa Ana — single-property detail view
function PropertyView({ propId, ctx, onNav, onProp }) {
  const { properties, tasks, bills, months } = window.CASA_ANA_DATA;
  const prop = properties.find(p => p.id === propId);
  const cur = useCurrency(ctx.currency);
  const [tab, setTab] = useState("overview");

  if (!prop) return null;

  // Tasks & bills targeting this property OR cross-portfolio
  const propTasks = tasks.filter(t => t.prop === propId);
  const propBills = bills.filter(b => b.prop === propId);
  const openTasks = propTasks.filter(t => !ctx.done.has(t.id) && t.status !== "done");
  const unpaidBills = propBills.filter(b => !ctx.paid.has(b.id) && b.status !== "paid");
  const fin = getPropFinance(prop);

  const hasSale = !!prop.forSale;
  const tabs = [
    { id: "overview", label: "Overview" },
    { id: "tasks", label: `Tasks · ${openTasks.length}` },
    { id: "bills", label: `Bills · ${unpaidBills.length}` },
    { id: "rent", label: "Rent ledger" },
    ...(hasSale ? [{ id: "sale", label: "For Sale" }] : []),
  ];

  return (
    <div>
      {/* Hero */}
      <div style={{ position: "relative" }}>
        <PropImg prop={prop} height={260} rounded={false} label={`${prop.name} — hero shot`} />
        <div style={{
          position: "absolute", inset: 0,
          background: "linear-gradient(180deg, transparent 30%, rgba(20,16,12,0.6) 100%)",
        }}/>
        <div style={{ position: "absolute", left: 40, bottom: 24, right: 40, display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
          <div>
            <button onClick={() => onNav("dashboard")} style={{
              fontFamily: "var(--mono)", fontSize: 10, letterSpacing: 1.5,
              textTransform: "uppercase", color: "rgba(255,255,255,0.75)",
              display: "inline-flex", alignItems: "center", gap: 6, marginBottom: 10,
            }}>
              ← Portfolio
            </button>
            <div style={{
              display: "flex", alignItems: "center", gap: 10,
              fontFamily: "var(--mono)", fontSize: 10, letterSpacing: 1.6,
              textTransform: "uppercase", color: "rgba(255,255,255,0.9)",
            }}>
              {prop.llc}
              <span style={{ opacity: 0.5 }}>·</span>
              Managed by {prop.manager}
              {hasSale && <Pill tone="warn" mono>Considering listing</Pill>}
            </div>
            <div style={{
              fontFamily: "var(--serif)", fontSize: 58, fontStyle: "italic",
              color: "#FBF8F2", lineHeight: 1, marginTop: 8, letterSpacing: -1,
            }}>{prop.name}</div>
            {prop.flag && (
              <div style={{ fontFamily: "var(--serif)", fontStyle: "italic", fontSize: 16, color: "rgba(255,255,255,0.85)", marginTop: 6 }}>
                "{prop.flag}"
              </div>
            )}
          </div>
          <div style={{ textAlign: "right", color: "rgba(255,255,255,0.92)" }}>
            <div style={{ display: "flex", gap: 22, fontSize: 12 }}>
              <Spec v={"$" + prop.rent.toLocaleString()} l="rent / month" />
              <Spec v={"$" + Math.round(prop.hoaAvg).toLocaleString()} l="hoa avg" />
              <Spec v={prop.tenantSince} l="tenant since" />
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div style={{
        padding: "0 40px",
        borderBottom: "0.5px solid var(--line)",
        display: "flex",
        gap: 4,
        background: "var(--bg2)",
        position: "sticky", top: 0, zIndex: 5,
      }}>
        {tabs.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            padding: "14px 18px",
            fontSize: 13,
            color: tab === t.id ? "var(--primary)" : "var(--t2)",
            borderBottom: tab === t.id ? "2px solid var(--primary)" : "2px solid transparent",
            marginBottom: -0.5,
            fontWeight: tab === t.id ? 500 : 400,
          }}>{t.label}</button>
        ))}
      </div>

      {/* Tab content */}
      <div style={{ padding: "24px 40px 40px" }}>
        {tab === "overview" && (
          <PropertyOverview prop={prop} ctx={ctx} setTab={setTab} cur={cur}
            openTasks={openTasks} unpaidBills={unpaidBills} fin={fin} />
        )}
        {tab === "tasks" && (
          <PropertyTasks prop={prop} tasks={propTasks} ctx={ctx} cur={cur} />
        )}
        {tab === "bills" && (
          <PropertyBills prop={prop} bills={propBills} ctx={ctx} cur={cur} />
        )}
        {tab === "rent" && (
          <PropertyRent prop={prop} cur={cur} />
        )}
        {tab === "sale" && hasSale && (
          <PropertySale prop={prop} cur={cur} />
        )}
      </div>
    </div>
  );
}

function Spec({ v, l }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 2 }}>
      <div style={{ fontFamily: "var(--serif)", fontSize: 24, color: "#FBF8F2", lineHeight: 1 }}>{v}</div>
      <div style={{ fontFamily: "var(--mono)", fontSize: 9, letterSpacing: 1.2, textTransform: "uppercase", color: "rgba(255,255,255,0.7)" }}>{l}</div>
    </div>
  );
}

function PropertyOverview({ prop, ctx, setTab, cur, openTasks, unpaidBills, fin }) {
  const collectionPct = Math.round(fin.collectionRate * 100);
  const netYTD = fin.collected - fin.hoaPaid; // rough net (rent − HOA only)

  return (
    <>
      {/* KPIs */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 24 }}>
        <Kpi label="Collected" value={cur.fmt(fin.collected, { compact: true })} sub={`of ${cur.fmt(fin.expected)}`} sublabel={`${collectionPct}%`} tone={collectionPct >= 95 ? "ok" : "warn"} />
        <Kpi label="Net (rent − HOA)" value={cur.fmt(netYTD, { compact: true })} sub={`HOA: ${cur.fmt(fin.hoaPaid, { compact: true })}`} sublabel="7 mo" tone="primary" />
        <Kpi label="Status" value={prop.status === "rented" ? "Rented" : prop.status === "watch" ? "Watch" : "Vacant"} sub={`Tenant since ${prop.tenantSince}`} sublabel="Now" tone={prop.status === "rented" ? "ok" : "warn"} />
        <Kpi label="Manager" value={prop.manager} sub={prop.manager === "Piki" ? "Piki — Manfredonia + Espada" : "Nena — Montijo + Antioco"} sublabel="On site" tone="accent" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 14 }}>
        {/* Tasks preview */}
        <Card title={`Open tasks · ${openTasks.length}`} action={<button className="link" onClick={() => setTab("tasks")}>See all →</button>}>
          {openTasks.slice(0, 5).map((t, i) => {
            const due = dueLabel(t.due);
            return (
              <div key={t.id} style={{ display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 10, alignItems: "center", padding: "10px 0", borderTop: i === 0 ? "none" : "0.5px solid var(--line)" }}>
                <button onClick={() => ctx.markTaskDone(t.id)} style={{
                  width: 16, height: 16, borderRadius: 3, border: "1px solid var(--line2)",
                }}/>
                <div>
                  <div style={{ fontSize: 12 }}>{t.title}</div>
                  <div style={{ fontSize: 10, color: "var(--t2)", marginTop: 2, fontFamily: "var(--mono)", letterSpacing: 0.5 }}>{t.cat} · {t.assignee}</div>
                </div>
                <Pill tone={due.kind === "danger" ? "danger" : due.kind === "warn" ? "warn" : "muted"} mono>{due.txt}</Pill>
              </div>
            );
          })}
          {openTasks.length === 0 && <div style={{ padding: 14, color: "var(--t3)", fontStyle: "italic", textAlign: "center" }}>Nothing open.</div>}
        </Card>

        {/* Bills preview */}
        <Card title={`Unpaid bills · ${unpaidBills.length}`} action={<button className="link" onClick={() => setTab("bills")}>See all →</button>}>
          {unpaidBills.slice(0, 5).map((b, i) => {
            const due = dueLabel(b.due);
            return (
              <div key={b.id} style={{ display: "grid", gridTemplateColumns: "1fr auto auto", gap: 10, alignItems: "center", padding: "10px 0", borderTop: i === 0 ? "none" : "0.5px solid var(--line)" }}>
                <div>
                  <div style={{ fontSize: 12 }}>{b.vendor}</div>
                  <div style={{ fontSize: 10, color: "var(--t2)", marginTop: 2, fontFamily: "var(--mono)", letterSpacing: 0.5 }}>{b.cat}</div>
                </div>
                <div style={{ fontFamily: "var(--serif)", fontSize: 16 }}>{cur.fmt(b.amt)}</div>
                <Pill tone={due.kind === "warn" ? "warn" : "muted"} mono>{due.txt}</Pill>
              </div>
            );
          })}
          {unpaidBills.length === 0 && <div style={{ padding: 14, color: "var(--t3)", fontStyle: "italic", textAlign: "center" }}>All paid.</div>}
        </Card>
      </div>

      {/* Rent ledger inline */}
      <Card title={`Rent — Oct 2025 to today`} action={<button className="link" onClick={() => setTab("rent")}>Full ledger →</button>}>
        <SinglePropRentStrip prop={prop} cur={cur} />
      </Card>
    </>
  );
}

function SinglePropRentStrip({ prop, cur }) {
  const { months } = window.CASA_ANA_DATA;
  return (
    <div>
      <div style={{ display: "grid", gridTemplateColumns: `repeat(${months.length}, 1fr)`, gap: 6 }}>
        {months.map((m, i) => {
          const v = prop.rentLedger[i];
          const future = v === null;
          const vacant = v === 0;
          const partial = !future && !vacant && v < prop.rent;
          const full = !future && !vacant && v >= prop.rent;
          const bg = future ? "var(--bg3)" : vacant ? "var(--danger-soft)" : partial ? "var(--warn-soft)" : "var(--ok-soft)";
          const bd = future ? "0.5px dashed var(--line2)" : vacant ? "0.5px solid var(--danger)" : partial ? "0.5px solid var(--warn)" : "0.5px solid var(--ok)";
          const fg = future ? "var(--t3)" : vacant ? "var(--danger)" : partial ? "var(--warn)" : "var(--ok)";
          return (
            <div key={m.iso} style={{
              padding: "12px 10px",
              background: bg, border: bd, borderRadius: 4,
              textAlign: "center",
            }}>
              <div style={{ fontFamily: "var(--mono)", fontSize: 9, letterSpacing: 1, textTransform: "uppercase", color: fg }}>{m.label}</div>
              <div style={{ fontFamily: "var(--serif)", fontSize: 18, color: fg, marginTop: 4 }}>
                {future ? "—" : vacant ? "vacant" : cur.fmt(v, { compact: true })}
              </div>
              {partial && (
                <div style={{ fontFamily: "var(--mono)", fontSize: 9, color: "var(--warn)", marginTop: 2 }}>
                  −{cur.fmt(prop.rent - v)}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function PropertyTasks({ prop, tasks, ctx, cur }) {
  const [statusFilter, setStatusFilter] = useState("open");
  const grouped = tasks
    .filter(t => {
      const done = ctx.done.has(t.id) || t.status === "done";
      if (statusFilter === "open" && done) return false;
      if (statusFilter === "done" && !done) return false;
      return true;
    })
    .sort((a,b) => parseDate(a.due) - parseDate(b.due));

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
        <div style={{ display: "flex", gap: 10 }}>
          <FilterChip label="Status" value={statusFilter} onChange={setStatusFilter}
            options={[{ v: "open", l: "Open" }, { v: "done", l: "Done" }, { v: "all", l: "All" }]} />
        </div>
        <button className="primary-btn"><Icon name="plus" size={14}/> New task for {prop.name}</button>
      </div>
      <Card padded={false}>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ background: "var(--bg3)" }}>
              <Th>Done</Th><Th>Task</Th><Th>Category</Th><Th>Due</Th><Th>Assignee</Th><Th align="right">Est.</Th><Th align="right">Priority</Th>
            </tr>
          </thead>
          <tbody>
            {grouped.map(t => {
              const done = ctx.done.has(t.id) || t.status === "done";
              const due = dueLabel(t.due);
              return (
                <tr key={t.id} style={{ borderTop: "0.5px solid var(--line)", opacity: done ? 0.5 : 1 }}>
                  <Td>
                    <button onClick={() => ctx.markTaskDone(t.id)} style={{
                      width: 18, height: 18, borderRadius: 4, border: "1px solid var(--line2)",
                      display: "flex", alignItems: "center", justifyContent: "center",
                      background: done ? "var(--primary)" : "transparent", color: "#fff",
                    }}>
                      {done && <Icon name="check" size={12} strokeWidth={2.5} />}
                    </button>
                  </Td>
                  <Td><div style={{ fontSize: 13, textDecoration: done ? "line-through" : "none" }}>{t.title}</div></Td>
                  <Td><span style={{ fontSize: 11, color: "var(--t2)" }}>{t.cat}</span></Td>
                  <Td><Pill tone={due.kind === "danger" ? "danger" : due.kind === "warn" ? "warn" : "muted"} mono>{due.txt}</Pill></Td>
                  <Td><span style={{ fontSize: 12, color: "var(--t2)" }}>{t.assignee}</span></Td>
                  <Td align="right"><span style={{ fontFamily: "var(--serif)", fontSize: 14 }}>{t.est ? cur.fmt(t.est) : "—"}</span></Td>
                  <Td align="right"><TaskStatusPill status={done ? "done" : "open"} priority={t.priority} /></Td>
                </tr>
              );
            })}
            {grouped.length === 0 && (
              <tr><Td colSpan={7}><div style={{ padding: 24, color: "var(--t3)", fontStyle: "italic", textAlign: "center" }}>Nothing on the list.</div></Td></tr>
            )}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

function PropertyBills({ prop, bills, ctx, cur }) {
  const [statusFilter, setStatusFilter] = useState("unpaid");
  const filtered = bills.filter(b => {
    const paid = ctx.paid.has(b.id) || b.status === "paid";
    if (statusFilter === "unpaid" && paid) return false;
    if (statusFilter === "paid" && !paid) return false;
    return true;
  }).sort((a,b) => parseDate(a.due) - parseDate(b.due));

  const unpaid = bills.filter(b => !ctx.paid.has(b.id) && b.status !== "paid");
  const totalUnpaid = unpaid.reduce((s,b)=>s+b.amt,0);
  const totalPaid = bills.filter(b => b.status === "paid" || ctx.paid.has(b.id)).reduce((s,b)=>s+b.amt,0);

  return (
    <div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14, marginBottom: 14 }}>
        <Kpi label="Total unpaid" value={cur.fmt(totalUnpaid, { compact: true })} sub={`${unpaid.length} bills`} sublabel="Open" />
        <Kpi label="Paid (7 mo)" value={cur.fmt(totalPaid, { compact: true })} sub="HOA + maintenance" sublabel="Settled" tone="ok" />
        <Kpi label="Avg HOA" value={cur.fmt(prop.hoaAvg, { compact: true })} sub="Monthly" sublabel="HOA" tone="warn" />
      </div>

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
        <FilterChip label="Status" value={statusFilter} onChange={setStatusFilter}
          options={[{ v: "unpaid", l: "Open" }, { v: "paid", l: "Paid" }, { v: "all", l: "All" }]} />
        <button className="primary-btn"><Icon name="plus" size={14}/> Record bill</button>
      </div>

      <Card padded={false}>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ background: "var(--bg3)" }}>
              <Th>Vendor</Th><Th>Category</Th><Th>Due</Th><Th>Recurrence</Th><Th align="right">Amount</Th><Th align="right">Status</Th><Th align="right"></Th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(b => {
              const paid = ctx.paid.has(b.id) || b.status === "paid";
              const due = dueLabel(b.due);
              return (
                <tr key={b.id} style={{ borderTop: "0.5px solid var(--line)", opacity: paid ? 0.55 : 1 }}>
                  <Td><div style={{ fontSize: 13 }}>{b.vendor}</div></Td>
                  <Td><span style={{ fontSize: 11, color: "var(--t2)" }}>{b.cat}</span></Td>
                  <Td><Pill tone={due.kind === "warn" ? "warn" : "muted"} mono>{fmtDate(b.due)}</Pill></Td>
                  <Td><span style={{ fontSize: 11, color: "var(--t3)", fontFamily: "var(--mono)", letterSpacing: 1, textTransform: "uppercase" }}>{b.recurring}</span></Td>
                  <Td align="right"><div style={{ fontFamily: "var(--serif)", fontSize: 18 }}>{cur.fmt(b.amt)}</div></Td>
                  <Td align="right"><BillStatusPill status={paid ? "paid" : "unpaid"} /></Td>
                  <Td align="right">{!paid && <button onClick={() => ctx.markBillPaid(b.id)} className="ghost-btn">Mark paid</button>}</Td>
                </tr>
              );
            })}
            {filtered.length === 0 && (
              <tr><Td colSpan={7}><div style={{ padding: 24, color: "var(--t3)", fontStyle: "italic", textAlign: "center" }}>Nothing on the list.</div></Td></tr>
            )}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

function PropertyRent({ prop, cur }) {
  const { months } = window.CASA_ANA_DATA;
  const fin = getPropFinance(prop);
  return (
    <div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 14 }}>
        <Kpi label="Monthly rent" value={cur.fmt(prop.rent, { compact: true })} sub="Lease agreement" sublabel="Rate" />
        <Kpi label="Collected" value={cur.fmt(fin.collected, { compact: true })} sub={`of ${cur.fmt(fin.expected)} expected`} sublabel="7 mo" tone="primary" />
        <Kpi label="Shortfall" value={cur.fmt(fin.gap, { compact: true })} sub={fin.gap > 0 ? "Follow up" : "All good"} sublabel="Gap" tone={fin.gap > 0 ? "warn" : "ok"} />
        <Kpi label="HOA paid" value={cur.fmt(fin.hoaPaid, { compact: true })} sub="Maintenance fees" sublabel="HOA" tone="accent" />
      </div>

      <Card title="Month-by-month ledger">
        <SinglePropRentStrip prop={prop} cur={cur} />
        <div style={{ marginTop: 16, padding: "12px 0 0", borderTop: "0.5px solid var(--line)" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr>
                <Th>Month</Th><Th align="right">Expected</Th><Th align="right">Collected</Th><Th align="right">HOA</Th><Th align="right">Net</Th><Th align="right">Status</Th>
              </tr>
            </thead>
            <tbody>
              {months.map((m, i) => {
                const r = prop.rentLedger[i];
                const h = prop.hoaLedger[i];
                const future = r === null;
                const vacant = r === 0;
                const partial = !future && !vacant && r < prop.rent;
                return (
                  <tr key={m.iso} style={{ borderTop: "0.5px solid var(--line)", opacity: future ? 0.5 : 1 }}>
                    <Td><span style={{ fontFamily: "var(--serif)", fontSize: 14 }}>{m.label}</span></Td>
                    <Td align="right"><span style={{ fontFamily: "var(--serif)", fontSize: 13, color: "var(--t2)" }}>{cur.fmt(prop.rent)}</span></Td>
                    <Td align="right">
                      {future ? <span style={{ color: "var(--t3)", fontFamily: "var(--mono)" }}>—</span>
                              : <span style={{ fontFamily: "var(--serif)", fontSize: 14, color: vacant ? "var(--danger)" : partial ? "var(--warn)" : "var(--t1)" }}>
                                  {vacant ? "vacant" : cur.fmt(r)}
                                </span>}
                    </Td>
                    <Td align="right"><span style={{ fontFamily: "var(--serif)", fontSize: 13, color: "var(--t2)" }}>{future ? "—" : cur.fmt(h)}</span></Td>
                    <Td align="right"><span style={{ fontFamily: "var(--serif)", fontSize: 14 }}>{future ? "—" : cur.fmt((r||0) - (h||0))}</span></Td>
                    <Td align="right">
                      {future ? <Pill tone="muted" mono>Upcoming</Pill>
                              : vacant ? <Pill tone="danger" mono>Vacant</Pill>
                              : partial ? <Pill tone="warn" mono>Partial</Pill>
                              : <Pill tone="ok" mono>Full</Pill>}
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

function PropertySale({ prop, cur }) {
  const fs = prop.forSale;
  const fin = getPropFinance(prop);
  return (
    <div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 14 }}>
        <Kpi label="Status" value={fs.considering ? "Considering" : "Listed"} sub={fs.considering ? "Not yet on market" : `Listed ${fs.listedOn}`} sublabel="Stage" tone="warn" />
        <Kpi label="Monthly rent" value={cur.fmt(prop.rent, { compact: true })} sub={`Net ${cur.fmt(prop.rent - prop.hoaAvg)}`} sublabel="Income" tone="primary" />
        <Kpi label="Collected (7 mo)" value={cur.fmt(fin.collected, { compact: true })} sub={`of ${cur.fmt(fin.expected, { compact: true })}`} sublabel="Track" tone={fin.gap === 0 ? "ok" : "warn"} />
        <Kpi label="List price" value={fs.list ? cur.fmt(fs.list, { compact: true }) : "—"} sub={fs.list ? "Set by agent" : "Get a quote"} sublabel="Asking" tone="accent" />
      </div>

      {fs.notes && (
        <div style={{
          padding: 18, marginBottom: 14,
          background: "var(--bg3)", borderLeft: "3px solid var(--accent)",
          borderRadius: 4,
          fontFamily: "var(--serif)", fontStyle: "italic", fontSize: 18, color: "var(--t1)",
        }}>
          "{fs.notes}"
        </div>
      )}

      <Card title="What's next">
        <ol style={{ paddingLeft: 20, margin: 0 }}>
          <li style={{ padding: "8px 0", borderBottom: "0.5px solid var(--line)" }}>
            <div style={{ fontSize: 13 }}>Talk to <b>Nena</b> about Feb's $500 shortfall — was it a one-off or a sign?</div>
          </li>
          <li style={{ padding: "8px 0", borderBottom: "0.5px solid var(--line)" }}>
            <div style={{ fontSize: 13 }}>Get a list-price estimate from <b>Inmobiliaria Pacífico</b> (or whoever you trust).</div>
          </li>
          <li style={{ padding: "8px 0", borderBottom: "0.5px solid var(--line)" }}>
            <div style={{ fontSize: 13 }}>Compare net rental ROI vs. sale proceeds. Decide by <b>end of June</b>.</div>
          </li>
          <li style={{ padding: "8px 0" }}>
            <div style={{ fontSize: 13 }}>If selling, brief <b>Guillermo Salas</b> for the title work.</div>
          </li>
        </ol>
      </Card>

      <div style={{ marginTop: 16, display: "flex", gap: 10 }}>
        <button className="primary-btn">Request agent valuation</button>
        <button className="ghost-btn">List for sale</button>
        <button className="ghost-btn">Keep renting</button>
      </div>
    </div>
  );
}

Object.assign(window, { PropertyView, SinglePropRentStrip });
