// Mosa Casa — Contacts (soft cards)
const { useState: useStateC } = React;

function ContactCard({ c }) {
  const [open, setOpen] = useStateC(true);
  const [newQ, setNewQ] = useStateC("");
  const [questions, setQuestions] = useStateC(c.questions);

  const addQ = () => {
    const t = newQ.trim();
    if (!t) return;
    setQuestions([...questions, { id: `q-${Date.now()}`, text: t, priority: "med" }]);
    setNewQ("");
  };
  const toggleDone = (id) => {
    setQuestions(questions.map(q => q.id === id ? { ...q, done: !q.done } : q));
  };

  const pending = questions.filter(q => !q.done).length;
  const initials = c.name.split(" ").map(n => n[0]).slice(0, 2).join("");

  return (
    <article style={{
      background: "var(--bg2)",
      borderRadius: 20,
      boxShadow: "var(--shadow-sm)",
      border: "1px solid var(--line)",
      overflow: "hidden",
    }}>
      {/* Header */}
      <button
        onClick={() => setOpen(!open)}
        style={{
          display: "grid",
          gridTemplateColumns: "auto 1fr auto auto",
          gap: 16,
          alignItems: "center",
          padding: "20px 24px",
          width: "100%",
          textAlign: "left",
          background: "transparent",
          borderBottom: open ? "1px solid var(--line)" : "none",
        }}
      >
        <div style={{
          width: 48, height: 48, borderRadius: 50,
          background: `linear-gradient(135deg, oklch(0.72 0.10 ${c.hue}), oklch(0.50 0.12 ${c.hue}))`,
          display: "flex", alignItems: "center", justifyContent: "center",
          color: "#fff", fontWeight: 700, fontSize: 16,
        }}>{initials}</div>

        <div style={{ minWidth: 0 }}>
          <div style={{
            fontSize: 11, fontWeight: 600, letterSpacing: 0.6,
            color: "var(--t3)", textTransform: "uppercase", marginBottom: 3,
          }}>{c.role}</div>
          <div style={{ fontSize: 18, fontWeight: 700, color: "var(--t1)", letterSpacing: -0.2 }}>{c.name}</div>
          <div style={{ fontSize: 12.5, color: "var(--t2)", marginTop: 3, fontWeight: 500 }}>
            {c.firm} · {c.phone} · {c.email}
          </div>
        </div>

        <div style={{ textAlign: "right" }}>
          <div style={{
            fontSize: 11, fontWeight: 600, letterSpacing: 0.6,
            color: "var(--t3)", textTransform: "uppercase",
          }}>Pending</div>
          <div style={{
            fontSize: 24, fontWeight: 700, lineHeight: 1, marginTop: 4,
            color: pending > 0 ? "var(--t1)" : "var(--ok)",
            letterSpacing: -0.4,
          }}>{pending}</div>
        </div>

        <div style={{ fontSize: 14, color: "var(--t3)", padding: 4 }}>
          {open ? "▾" : "▸"}
        </div>
      </button>

      {/* Body */}
      {open && (
        <div style={{ padding: "8px 24px 20px" }}>
          {questions.length === 0 && (
            <div style={{ fontSize: 13, color: "var(--t3)", padding: "12px 0 4px" }}>
              No questions yet. Add one below.
            </div>
          )}
          <div>
            {questions.map((q, i) => {
              const tone = q.priority === "high" ? "danger" : q.priority === "med" ? "warn" : "muted";
              const toneBg = q.priority === "high" ? "var(--danger-soft)"
                           : q.priority === "med" ? "var(--warn-soft)"
                           : "var(--bg3)";
              const toneFg = q.priority === "high" ? "var(--danger)"
                           : q.priority === "med" ? "var(--warn)"
                           : "var(--t2)";
              return (
                <div key={q.id} style={{
                  display: "grid",
                  gridTemplateColumns: "auto 1fr auto",
                  gap: 14,
                  alignItems: "center",
                  padding: "14px 0",
                  borderBottom: i === questions.length - 1 ? "none" : "1px solid var(--line)",
                  opacity: q.done ? 0.5 : 1,
                }}>
                  <button
                    onClick={() => toggleDone(q.id)}
                    style={{
                      width: 22, height: 22, borderRadius: 7,
                      border: "1.5px solid " + (q.done ? "var(--primary)" : "var(--line2)"),
                      background: q.done ? "var(--primary)" : "transparent",
                      display: "flex", alignItems: "center", justifyContent: "center",
                      flexShrink: 0,
                      transition: "all 120ms",
                    }}>
                    {q.done && <span style={{ color: "#fff", fontSize: 13, lineHeight: 1 }}>✓</span>}
                  </button>
                  <div style={{
                    fontSize: 14, fontWeight: 500, color: "var(--t1)",
                    lineHeight: 1.4,
                    textDecoration: q.done ? "line-through" : "none",
                  }}>{q.text}</div>
                  <span style={{
                    fontSize: 11, fontWeight: 600,
                    padding: "4px 10px", borderRadius: 999,
                    background: toneBg, color: toneFg,
                    textTransform: "capitalize",
                  }}>{q.priority}</span>
                </div>
              );
            })}
          </div>

          {/* Add new question */}
          <div style={{
            display: "flex",
            gap: 10,
            marginTop: 16,
            paddingTop: 16,
            borderTop: "1px solid var(--line)",
          }}>
            <input
              value={newQ}
              onChange={(e) => setNewQ(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") addQ(); }}
              placeholder={`Add a question for ${c.name.split(" ")[0]}…`}
              style={{
                flex: 1,
                padding: "11px 16px",
                background: "var(--bg)",
                border: "1px solid var(--line2)",
                borderRadius: 12,
                fontSize: 13.5,
                color: "var(--t1)",
                outline: "none",
                fontFamily: "var(--sans)",
              }}
            />
            <button
              onClick={addQ}
              style={{
                padding: "11px 20px",
                background: "var(--primary)",
                color: "#fff",
                border: "none",
                borderRadius: 12,
                fontSize: 13,
                fontWeight: 600,
                cursor: "pointer",
              }}
            >Add</button>
          </div>
        </div>
      )}
    </article>
  );
}

function ContactsSection({ filterId }) {
  const { contacts } = window.CASA_ANA_DATA;
  const list = filterId ? contacts.filter(c => c.id === filterId) : contacts;
  const single = list.length === 1 ? list[0] : null;
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 40 }}>
      <section>
        <h1 style={{
          fontSize: 48, fontWeight: 700, lineHeight: 1.05,
          letterSpacing: -1, margin: 0, color: "var(--t1)",
        }}>{single ? single.role : "Contacts"}</h1>
        <div style={{ fontSize: 14.5, color: "var(--t2)", marginTop: 10, fontWeight: 500, maxWidth: 560 }}>
          {single
            ? `Questions for ${single.name}. Bring this list to your next call.`
            : "Park questions here as they come up, then bring the list to your next call."}
        </div>
      </section>

      <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
        {list.map(c => <ContactCard key={c.id} c={c} />)}
      </div>
    </div>
  );
}

Object.assign(window, { ContactsSection });
